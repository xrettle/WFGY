import CROOT.Adapters.StatementEquivalenceBridge

namespace CROOT

inductive RuntimeStage where
  | problemInput
  | questionIntake
  | sourceAuthority
  | judgmentCore
  | internalLedger
  | externalReviewLedger
  | formalizationTarget
  deriving DecidableEq, Repr

def requiredRuntimeOrder : List RuntimeStage :=
  [RuntimeStage.problemInput,
   RuntimeStage.questionIntake,
   RuntimeStage.sourceAuthority,
   RuntimeStage.judgmentCore,
   RuntimeStage.internalLedger,
   RuntimeStage.externalReviewLedger,
   RuntimeStage.formalizationTarget]

inductive AdapterPath where
  | adapterToSourceAuthority
  | adapterToExternalLedgerDirect
  | adapterToSourceMutation
  | adapterToCoreReview
  | adapterToInternalLedgerValidation
  deriving DecidableEq, Repr

def adapterPathAllowed (p : AdapterPath) : Bool :=
  match p with
  | AdapterPath.adapterToSourceAuthority => false
  | AdapterPath.adapterToExternalLedgerDirect => false
  | AdapterPath.adapterToSourceMutation => false
  | AdapterPath.adapterToCoreReview => true
  | AdapterPath.adapterToInternalLedgerValidation => true

theorem runtime_order_has_seven_stages :
    requiredRuntimeOrder.length = 7 := by
  rfl

theorem adapter_path_source_authority_blocked :
    adapterPathAllowed AdapterPath.adapterToSourceAuthority = false := by
  rfl

theorem adapter_path_external_direct_blocked :
    adapterPathAllowed AdapterPath.adapterToExternalLedgerDirect = false := by
  rfl

theorem adapter_path_source_mutation_blocked :
    adapterPathAllowed AdapterPath.adapterToSourceMutation = false := by
  rfl

theorem adapter_path_core_review_allowed :
    adapterPathAllowed AdapterPath.adapterToCoreReview = true := by
  rfl

theorem adapter_path_internal_validation_allowed :
    adapterPathAllowed AdapterPath.adapterToInternalLedgerValidation = true := by
  rfl

end CROOT
