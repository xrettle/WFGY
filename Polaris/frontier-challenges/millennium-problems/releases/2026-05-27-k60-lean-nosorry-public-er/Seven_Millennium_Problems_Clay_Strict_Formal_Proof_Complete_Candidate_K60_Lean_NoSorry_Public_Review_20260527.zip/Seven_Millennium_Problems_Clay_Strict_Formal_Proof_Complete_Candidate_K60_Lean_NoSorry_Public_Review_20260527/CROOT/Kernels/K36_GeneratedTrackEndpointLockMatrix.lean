import CROOT.Kernels.K35_TrackProjectionSyncMatrix

namespace CROOT

theorem generated_obligation_track_projection_head_lock :
    generatedObligationTrackProjection.head? = some Track.PNP := by
  simp [generated_obligation_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_obligation_track_projection_tail_lock :
    generatedObligationTrackProjection.getLast? = some Track.PC := by
  simp [generated_obligation_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_completion_track_projection_head_lock :
    generatedCompletionTrackProjection.head? = some Track.PNP := by
  simp [generated_completion_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_completion_track_projection_tail_lock :
    generatedCompletionTrackProjection.getLast? = some Track.PC := by
  simp [generated_completion_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_prototype_track_projection_head_lock :
    generatedPrototypeTrackProjection.head? = some Track.PNP := by
  simp [generated_prototype_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_prototype_track_projection_tail_lock :
    generatedPrototypeTrackProjection.getLast? = some Track.PC := by
  simp [generated_prototype_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_refinement_track_projection_head_lock :
    generatedRefinementTrackProjection.head? = some Track.PNP := by
  simp [generated_refinement_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

theorem generated_refinement_track_projection_tail_lock :
    generatedRefinementTrackProjection.getLast? = some Track.PC := by
  simp [generated_refinement_track_projection_eq_canonical,
    canonical_track_projection_eq_all_tracks, allTracks]

structure K36GeneratedTrackEndpointLockMatrix where
  obligationHeadLock : generatedObligationTrackProjection.head? = some Track.PNP
  obligationTailLock : generatedObligationTrackProjection.getLast? = some Track.PC
  completionHeadLock : generatedCompletionTrackProjection.head? = some Track.PNP
  completionTailLock : generatedCompletionTrackProjection.getLast? = some Track.PC
  prototypeHeadLock : generatedPrototypeTrackProjection.head? = some Track.PNP
  prototypeTailLock : generatedPrototypeTrackProjection.getLast? = some Track.PC
  refinementHeadLock : generatedRefinementTrackProjection.head? = some Track.PNP
  refinementTailLock : generatedRefinementTrackProjection.getLast? = some Track.PC

def k36_generated_track_endpoint_lock_matrix : K36GeneratedTrackEndpointLockMatrix :=
{
  obligationHeadLock := generated_obligation_track_projection_head_lock,
  obligationTailLock := generated_obligation_track_projection_tail_lock,
  completionHeadLock := generated_completion_track_projection_head_lock,
  completionTailLock := generated_completion_track_projection_tail_lock,
  prototypeHeadLock := generated_prototype_track_projection_head_lock,
  prototypeTailLock := generated_prototype_track_projection_tail_lock,
  refinementHeadLock := generated_refinement_track_projection_head_lock,
  refinementTailLock := generated_refinement_track_projection_tail_lock
}

end CROOT
