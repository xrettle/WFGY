import CROOT.Kernels.K50_UnifiedLaneRuntimeContract

namespace CROOT

structure K51UnifiedFastpathCertificate where
  trackEqCanonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection
  problemEqCanonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds
  statementEqContracts :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  domainEqCanonical :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  trackNodup :
    forall lane, (laneTrackProjection lane).Nodup
  problemNodup :
    forall lane, (laneProblemProjection lane).Nodup
  trackHeadLock :
    forall lane, (laneTrackProjection lane).head? = some Track.PNP
  trackTailLock :
    forall lane, (laneTrackProjection lane).getLast? = some Track.PC
  problemHeadLock :
    forall lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  problemTailLock :
    forall lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionAllAllowed :
    forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryAllOfficial :
    forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k51_unified_fastpath_certificate : K51UnifiedFastpathCertificate :=
{
  trackEqCanonical := k50_unified_lane_runtime_contract.trackEqCanonical,
  problemEqCanonical := k50_unified_lane_runtime_contract.problemEqCanonical,
  statementEqContracts := k50_unified_lane_runtime_contract.statementEqContracts,
  domainEqCanonical := k50_unified_lane_runtime_contract.domainEqCanonical,
  trackNodup := k50_unified_lane_runtime_contract.trackNodup,
  problemNodup := k50_unified_lane_runtime_contract.problemNodup,
  trackHeadLock := k50_unified_lane_runtime_contract.trackHeadLock,
  trackTailLock := k50_unified_lane_runtime_contract.trackTailLock,
  problemHeadLock := k50_unified_lane_runtime_contract.problemHeadLock,
  problemTailLock := k50_unified_lane_runtime_contract.problemTailLock,
  returnLockAllLocked := k50_unified_lane_runtime_contract.returnLockAllLocked,
  decisionAllAllowed := k50_unified_lane_runtime_contract.decisionAllAllowed,
  boundaryAllOfficial := k50_unified_lane_runtime_contract.boundaryAllOfficial,
  debtAllOpen := k50_unified_lane_runtime_contract.debtAllOpen
}

end CROOT
