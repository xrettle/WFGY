import CROOT.Kernels.K54_UnifiedCreatorFastpathCore

namespace CROOT

structure K55UnifiedCreatorAuditPortal where
  trackEqCanonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection
  problemEqCanonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds
  statementEqContracts :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  normalizedStatementEqAdapterContracts :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  domainEqCanonical :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  trackCountSeven :
    forall lane, (laneTrackProjection lane).length = 7
  problemCountSeven :
    forall lane, (laneProblemProjection lane).length = 7
  statementCountSeven :
    forall lane, (laneStatementProjection lane).length = 7
  domainCountSeven :
    forall lane, (laneDomainProjection lane).length = 7
  trackNodup :
    forall lane, (laneTrackProjection lane).Nodup
  problemNodup :
    forall lane, (laneProblemProjection lane).Nodup
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k55_unified_creator_audit_portal : K55UnifiedCreatorAuditPortal :=
{
  trackEqCanonical := by
    intro lane
    exact (k54_unified_creator_fastpath_core.trackInvariant lane).left,
  problemEqCanonical := by
    intro lane
    exact (k54_unified_creator_fastpath_core.problemInvariant lane).left,
  statementEqContracts := k54_unified_creator_fastpath_core.statementEqContracts,
  normalizedStatementEqAdapterContracts :=
    k54_unified_creator_fastpath_core.normalizedStatementEqAdapterContracts,
  domainEqCanonical := k54_unified_creator_fastpath_core.domainEqCanonical,
  trackCountSeven := k54_unified_creator_fastpath_core.trackCountSeven,
  problemCountSeven := k54_unified_creator_fastpath_core.problemCountSeven,
  statementCountSeven := k54_unified_creator_fastpath_core.statementCountSeven,
  domainCountSeven := k54_unified_creator_fastpath_core.domainCountSeven,
  trackNodup := by
    intro lane
    exact (k54_unified_creator_fastpath_core.trackInvariant lane).right.left,
  problemNodup := by
    intro lane
    exact (k54_unified_creator_fastpath_core.problemInvariant lane).right.left,
  returnLockAllLocked := k54_unified_creator_fastpath_core.returnLockAllLocked,
  debtAllOpen := k54_unified_creator_fastpath_core.debtAllOpen
}

end CROOT
