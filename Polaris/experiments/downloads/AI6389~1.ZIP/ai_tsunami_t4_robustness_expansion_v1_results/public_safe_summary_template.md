
# Public Safe Summary Template

Do not include packet schema, corruption manifest, judge rubric, or DDI repair details.

Trial: AI_TSUNAMI_T4_ROBUSTNESS_EXPANSION
Version: v1_single_file_colab
Case count: 96
Arms: A/B/C/D
Models: gpt-4.1, gpt-4.1-mini
Global level: L5_T4_ROBUSTNESS_EXPANSION_PASS

Safe metrics:
- C mean score
- Raw TokenRatio C/A
- Amortized TokenRatio C/A
- C minus D
- Failure signature match
- Leakage count

Claim boundary:
Scoped topology-conservation T4 Robustness Expansion only.
