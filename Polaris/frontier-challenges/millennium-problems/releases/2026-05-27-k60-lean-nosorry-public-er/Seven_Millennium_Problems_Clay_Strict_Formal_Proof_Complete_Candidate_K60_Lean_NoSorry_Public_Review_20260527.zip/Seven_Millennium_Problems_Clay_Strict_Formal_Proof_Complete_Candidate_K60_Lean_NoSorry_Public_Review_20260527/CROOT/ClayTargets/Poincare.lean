import CROOT.ClayTargets.Common

namespace CROOT

def poincareDomainCore : DomainCoreSignature :=
  {
    objectTag := "closed-simply-connected-3-manifold"
    operationTag := "geometric-flow-normalization-map"
    invariantTag := "sphere-homeomorphism-obligation"
  }

def poincareTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.poincare "official-clay-statement-boundary"

theorem poincare_target_problem :
    poincareTargetContract.problem = ProblemId.poincare := by
  rfl

theorem poincare_target_shape_valid :
    targetContractShapeValid poincareTargetContract := by
  constructor <;> decide

end CROOT
