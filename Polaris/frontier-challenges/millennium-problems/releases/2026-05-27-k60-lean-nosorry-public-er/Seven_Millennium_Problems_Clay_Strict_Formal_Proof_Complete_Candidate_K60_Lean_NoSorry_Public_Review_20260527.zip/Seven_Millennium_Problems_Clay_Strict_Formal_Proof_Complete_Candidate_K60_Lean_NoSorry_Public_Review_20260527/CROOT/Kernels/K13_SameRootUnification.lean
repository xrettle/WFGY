import CROOT.Generators.SameRootProjection

namespace CROOT

structure K13SameRootUnification where
  rootedCount : rootedSpecs.length = 7
  targetCount : generatedTargets.length = 7
  obligationCount : generatedObligations.length = 7
  laneCount : generatedCompletionLanes.length = 7
  prototypePairCount : generatedPrototypePair.length = 2
  fullPrototypeLaneCount : generatedFullPrototypeLanes.length = 7
  fullRefinementLaneCount : generatedFullRefinementLanes.length = 7
  pnpTargetAligned : (generatedTarget ProblemId.pnp).problem = ProblemId.pnp
  rhTargetAligned : (generatedTarget ProblemId.rh).problem = ProblemId.rh
  pnpObligationAligned : (generatedObligation ProblemId.pnp).problem = ProblemId.pnp
  rhObligationAligned : (generatedObligation ProblemId.rh).problem = ProblemId.rh

theorem k13_same_root_unification : K13SameRootUnification :=
{
  rootedCount := rooted_specs_length,
  targetCount := generated_targets_length,
  obligationCount := generated_obligations_length,
  laneCount := generated_completion_lanes_length,
  prototypePairCount := generated_prototype_pair_length,
  fullPrototypeLaneCount := generated_full_prototype_lanes_length,
  fullRefinementLaneCount := generated_full_refinement_lanes_length,
  pnpTargetAligned := generated_target_problem_alignment ProblemId.pnp,
  rhTargetAligned := generated_target_problem_alignment ProblemId.rh,
  pnpObligationAligned := generated_obligation_problem_alignment ProblemId.pnp,
  rhObligationAligned := generated_obligation_problem_alignment ProblemId.rh
}

end CROOT
