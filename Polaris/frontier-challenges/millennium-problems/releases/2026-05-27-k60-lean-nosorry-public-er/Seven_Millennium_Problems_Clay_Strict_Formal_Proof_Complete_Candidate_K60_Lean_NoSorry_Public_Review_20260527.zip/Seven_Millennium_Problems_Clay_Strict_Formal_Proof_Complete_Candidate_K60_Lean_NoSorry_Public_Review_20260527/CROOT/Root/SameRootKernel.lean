import CROOT.Core.ProblemSpec

namespace CROOT

structure SameRootToken where
  rootName : String
  rootVersion : Nat
  rootHashTag : String
  deriving DecidableEq, Repr

def canonicalSameRootToken : SameRootToken :=
  {
    rootName := "same-root-same-source",
    rootVersion := 3,
    rootHashTag := "root_v3_unified_projection"
  }

structure RootedProblem where
  spec : ProblemSpec
  root : SameRootToken
  deriving DecidableEq, Repr

def rootedSpec (p : ProblemId) : RootedProblem :=
  {
    spec := canonicalSpec p,
    root := canonicalSameRootToken
  }

def rootedSpecs : List RootedProblem :=
  [rootedSpec ProblemId.pnp,
   rootedSpec ProblemId.rh,
   rootedSpec ProblemId.bsd,
   rootedSpec ProblemId.hodge,
   rootedSpec ProblemId.navierStokes,
   rootedSpec ProblemId.yangMills,
   rootedSpec ProblemId.poincare]

theorem rooted_specs_length : rootedSpecs.length = 7 := by
  rfl

theorem rooted_spec_has_canonical_root (p : ProblemId) :
    (rootedSpec p).root = canonicalSameRootToken := by
  rfl

theorem rooted_spec_problem_alignment (p : ProblemId) :
    (rootedSpec p).spec.id = p := by
  cases p <;> rfl

theorem rooted_spec_track_alignment (p : ProblemId) :
    (rootedSpec p).spec.track = problemTrackOf p := by
  exact problem_track_alignment p

end CROOT
