import CROOT.Kernels.K29_ControlSurfaceSyncMatrix
import CROOT.Kernels.K16_RegistryProjectionClosure

namespace CROOT

theorem source_field_problem_projection_nodup :
    sourceFieldProblemProjection.Nodup := by
  simpa [source_field_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem generated_obligation_problem_projection_nodup :
    generatedObligationProblemProjection.Nodup := by
  simpa [generated_obligation_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem generated_completion_lane_problem_projection_nodup :
    generatedCompletionLaneProblemProjection.Nodup := by
  simpa [generated_completion_lane_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem source_field_problem_projection_count :
    sourceFieldProblemProjection.length = 7 := by
  simpa [source_field_problem_projection_eq_canonical] using canonical_problem_ids_length

theorem generated_obligation_problem_projection_count :
    generatedObligationProblemProjection.length = 7 := by
  simpa [generated_obligation_problem_projection_eq_canonical] using canonical_problem_ids_length

theorem generated_completion_lane_problem_projection_count :
    generatedCompletionLaneProblemProjection.length = 7 := by
  simpa [generated_completion_lane_problem_projection_eq_canonical] using canonical_problem_ids_length

theorem generated_prototype_problem_projection_count :
    generatedPrototypeProblemProjection.length = 7 := by
  simpa [generated_prototype_problem_projection_eq_canonical] using canonical_problem_ids_length

theorem generated_refinement_problem_projection_count :
    generatedRefinementProblemProjection.length = 7 := by
  simpa [generated_refinement_problem_projection_eq_canonical] using canonical_problem_ids_length

structure K30ProjectionNodupCountMatrix where
  sourceFieldProjectionNodup : sourceFieldProblemProjection.Nodup
  generatedObligationProjectionNodup : generatedObligationProblemProjection.Nodup
  generatedCompletionProjectionNodup : generatedCompletionLaneProblemProjection.Nodup
  generatedPrototypeProjectionNodup : generatedPrototypeProblemProjection.Nodup
  generatedRefinementProjectionNodup : generatedRefinementProblemProjection.Nodup
  sourceFieldProjectionCount : sourceFieldProblemProjection.length = 7
  generatedObligationProjectionCount : generatedObligationProblemProjection.length = 7
  generatedCompletionProjectionCount : generatedCompletionLaneProblemProjection.length = 7
  generatedPrototypeProjectionCount : generatedPrototypeProblemProjection.length = 7
  generatedRefinementProjectionCount : generatedRefinementProblemProjection.length = 7

def k30_projection_nodup_count_matrix : K30ProjectionNodupCountMatrix :=
{
  sourceFieldProjectionNodup := source_field_problem_projection_nodup,
  generatedObligationProjectionNodup := generated_obligation_problem_projection_nodup,
  generatedCompletionProjectionNodup := generated_completion_lane_problem_projection_nodup,
  generatedPrototypeProjectionNodup := generated_prototype_problem_projection_nodup,
  generatedRefinementProjectionNodup := generated_refinement_problem_projection_nodup,
  sourceFieldProjectionCount := source_field_problem_projection_count,
  generatedObligationProjectionCount := generated_obligation_problem_projection_count,
  generatedCompletionProjectionCount := generated_completion_lane_problem_projection_count,
  generatedPrototypeProjectionCount := generated_prototype_problem_projection_count,
  generatedRefinementProjectionCount := generated_refinement_problem_projection_count
}

end CROOT
