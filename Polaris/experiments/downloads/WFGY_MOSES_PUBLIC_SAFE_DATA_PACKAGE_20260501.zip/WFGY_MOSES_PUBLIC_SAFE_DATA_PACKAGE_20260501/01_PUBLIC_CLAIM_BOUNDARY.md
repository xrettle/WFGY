# Public Claim Boundary

## Allowed public claim

Moses T4 is closed as a composite internal robustness package for merge preparation, with T3/P2 as primary clean full API evidence and T4 represented by full pipeline execution plus targeted patch verifier aggregate pass.

## Safe wording

This public package contains aggregate stage metrics, public claim boundaries, and a public-safe composite verdict summary. The internal prompts, evaluator logic, raw output traces, case payloads, judge rows, evidence zips, and executable notebooks are intentionally not included.

## Not allowed

Do not claim independent full T4 v2 API pass.
Do not claim universal small-model superiority.
Do not claim the GPU myth is fully broken.
Do not claim the final merged proof is complete.
Do not claim that this public package is enough to reproduce the internal private experiment engine.

## Public interpretation

This is a public data summary package, not an implementation release.
