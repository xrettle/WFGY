import CROOT.Kernels.K22_RootTokenProjectionClosure

namespace CROOT

def rootedStatementPairs : List (ProblemId × String) :=
  rootedSpecs.map (fun rp => (rp.spec.id, rp.spec.statementTag))

def contractStatementPairs : List (ProblemId × String) :=
  canonicalStatementContracts.map (fun c => (c.problem, c.officialStatementTag))

theorem rooted_statement_pairs_eq_contract_pairs :
    rootedStatementPairs = contractStatementPairs := by
  simp [rootedStatementPairs, contractStatementPairs, rootedSpecs, rootedSpec, canonicalStatementContracts,
    canonicalStatementContract, canonicalSpec]

theorem rooted_statement_pairs_count :
    rootedStatementPairs.length = 7 := by
  simp [rootedStatementPairs, rootedSpecs]

structure K23StatementPairProjectionClosure where
  pairSync : rootedStatementPairs = contractStatementPairs
  pairCount : rootedStatementPairs.length = 7

def k23_statement_pair_projection_closure : K23StatementPairProjectionClosure :=
{
  pairSync := rooted_statement_pairs_eq_contract_pairs,
  pairCount := rooted_statement_pairs_count
}

end CROOT
