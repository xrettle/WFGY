import CROOT.ClayTargets.Common

namespace CROOT

def rhDomainCore : DomainCoreSignature :=
  {
    objectTag := "zeta-critical-strip"
    operationTag := "zero-localization-map"
    invariantTag := "critical-line-obligation"
  }

def rhTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.rh "official-clay-statement-boundary"

theorem rh_target_problem :
    rhTargetContract.problem = ProblemId.rh := by
  rfl

theorem rh_target_shape_valid :
    targetContractShapeValid rhTargetContract := by
  constructor <;> decide

end CROOT
