# Run This First

This package is a K60 public external-review toolkit.

1. Read `README.md`.
2. Read `CLAIM_CEILING_MACHINE_CHECK_STEP1.txt`.
3. Run the verification commands in `HOW_TO_VERIFY.md`.
4. Read `PUBLIC_TERMINOLOGY_MAP.txt` before interpreting older internal names such as `openDebt`.

Release boundary:
K60 architecture/audit envelope is the current public release. Final native theorem-object closure is the next stage.
