import CROOT.Kernels.K26_SharedProjectionSyncMatrix

namespace CROOT

def rootedStatementProjection : List String :=
  rootedStatementPairs.map Prod.snd

theorem rooted_statement_projection_eq_source_field :
    rootedStatementProjection = sourceFieldStatementTagProjection := by
  simp [rootedStatementProjection, rootedStatementPairs, sourceFieldStatementTagProjection, rootedSpecs]

theorem generated_obligation_statement_projection_eq_contracts :
    generatedObligationStatementProjection = statementTagProjectionFromContracts := by
  calc
    generatedObligationStatementProjection = sourceFieldStatementTagProjection :=
      generated_obligation_statement_projection_eq_source_field
    _ = statementTagProjectionFromContracts := source_field_statement_projection_eq_contracts

theorem rooted_statement_projection_eq_contracts :
    rootedStatementProjection = statementTagProjectionFromContracts := by
  calc
    rootedStatementProjection = sourceFieldStatementTagProjection :=
      rooted_statement_projection_eq_source_field
    _ = statementTagProjectionFromContracts := source_field_statement_projection_eq_contracts

theorem rooted_statement_projection_eq_specs :
    rootedStatementProjection = statementTagProjectionFromSpecs := by
  calc
    rootedStatementProjection = sourceFieldStatementTagProjection :=
      rooted_statement_projection_eq_source_field
    _ = statementTagProjectionFromSpecs := source_field_statement_projection_eq_specs

structure K27StatementProjectionSyncMatrix where
  rootedToSourceField : rootedStatementProjection = sourceFieldStatementTagProjection
  rootedToContracts : rootedStatementProjection = statementTagProjectionFromContracts
  rootedToSpecs : rootedStatementProjection = statementTagProjectionFromSpecs
  obligationsToContracts : generatedObligationStatementProjection = statementTagProjectionFromContracts

def k27_statement_projection_sync_matrix : K27StatementProjectionSyncMatrix :=
{
  rootedToSourceField := rooted_statement_projection_eq_source_field,
  rootedToContracts := rooted_statement_projection_eq_contracts,
  rootedToSpecs := rooted_statement_projection_eq_specs,
  obligationsToContracts := generated_obligation_statement_projection_eq_contracts
}

end CROOT
