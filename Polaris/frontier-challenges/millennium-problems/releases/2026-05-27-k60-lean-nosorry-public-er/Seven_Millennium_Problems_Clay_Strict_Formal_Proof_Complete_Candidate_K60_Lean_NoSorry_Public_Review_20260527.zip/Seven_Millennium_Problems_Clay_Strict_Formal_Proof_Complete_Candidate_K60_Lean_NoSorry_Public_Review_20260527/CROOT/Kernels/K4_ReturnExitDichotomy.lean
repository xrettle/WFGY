import CROOT.Core.Types

namespace CROOT

def classifyBranch (s : ResidualState) : Branch :=
  match s with
  | ResidualState.admissible => Branch.returnBranch
  | ResidualState.failure => Branch.exitBranch
  | ResidualState.laneExit => Branch.exitBranch
  | ResidualState.unknownEscalate => Branch.exitBranch

theorem K4_admissible_returns :
    classifyBranch ResidualState.admissible = Branch.returnBranch := by
  rfl

theorem K4_failure_exits :
    classifyBranch ResidualState.failure = Branch.exitBranch := by
  rfl

theorem K4_laneExit_exits :
    classifyBranch ResidualState.laneExit = Branch.exitBranch := by
  rfl

theorem K4_unknown_exits :
    classifyBranch ResidualState.unknownEscalate = Branch.exitBranch := by
  rfl

theorem K4_unknown_cannot_return :
    classifyBranch ResidualState.unknownEscalate ≠ Branch.returnBranch := by
  intro h
  cases h

theorem K4_return_exit_disjoint :
    Branch.returnBranch ≠ Branch.exitBranch := by
  intro h
  cases h

end CROOT
