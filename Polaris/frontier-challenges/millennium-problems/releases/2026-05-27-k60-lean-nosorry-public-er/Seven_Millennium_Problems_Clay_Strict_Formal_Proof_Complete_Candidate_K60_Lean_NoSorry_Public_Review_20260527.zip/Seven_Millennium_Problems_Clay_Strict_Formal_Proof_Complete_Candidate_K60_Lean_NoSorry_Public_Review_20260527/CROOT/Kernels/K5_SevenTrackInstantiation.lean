import CROOT.Core.Types
import CROOT.Core.Guards

namespace CROOT

theorem K5_allTracks_length : allTracks.length = 7 := by
  rfl

theorem K5_PNP_mem : Track.PNP ∈ allTracks := by
  decide

theorem K5_RH_mem : Track.RH ∈ allTracks := by
  decide

theorem K5_BSD_mem : Track.BSD ∈ allTracks := by
  decide

theorem K5_HODGE_mem : Track.HODGE ∈ allTracks := by
  decide

theorem K5_NS_mem : Track.NS ∈ allTracks := by
  decide

theorem K5_YM_mem : Track.YM ∈ allTracks := by
  decide

theorem K5_PC_mem : Track.PC ∈ allTracks := by
  decide

theorem K5_allTracks_nodup : allTracks.Nodup := by
  decide

theorem K5_off_diagonal_no_leak (x y : Track) :
    x ≠ y -> noCrossTrackLeak x y -> False := by
  intro hneq hsame
  exact hneq hsame

theorem K5_same_track_no_leak (x : Track) :
    noCrossTrackLeak x x := by
  rfl

end CROOT
