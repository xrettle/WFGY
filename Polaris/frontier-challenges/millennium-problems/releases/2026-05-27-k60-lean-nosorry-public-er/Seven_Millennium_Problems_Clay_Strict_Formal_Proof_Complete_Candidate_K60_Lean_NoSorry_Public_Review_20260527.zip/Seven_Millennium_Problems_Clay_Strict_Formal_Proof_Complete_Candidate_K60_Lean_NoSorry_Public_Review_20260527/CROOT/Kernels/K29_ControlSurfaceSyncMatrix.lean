import CROOT.Kernels.K28_NormalizedStatementSyncMatrix
import CROOT.Kernels.K17_TargetContractClosure

namespace CROOT

def generatedObligationReturnLockProjection : List ReturnLockStatus :=
  generatedObligations.map (fun o => o.returnLock)

def generatedObligationDecisionProjection : List ImportDecision :=
  generatedObligations.map (fun o => o.adapterDecision)

def generatedObligationDebtProjection : List TheoremDebtStatus :=
  generatedObligations.map (fun o => o.debtStatus)

theorem generated_obligation_return_lock_all_locked :
    generatedObligationReturnLockProjection = List.replicate 7 ReturnLockStatus.locked := by
  simp [generatedObligationReturnLockProjection, generatedObligations, generatedObligationFromRoot, rootedSpecs]

theorem generated_obligation_decision_all_allowed :
    generatedObligationDecisionProjection = List.replicate 7 ImportDecision.allowed := by
  simp [generatedObligationDecisionProjection, generatedObligations, generatedObligationFromRoot, rootedSpecs]

theorem generated_obligation_debt_all_open :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt := by
  simp [generatedObligationDebtProjection, generatedObligations, generatedObligationFromRoot, rootedSpecs]

theorem generated_manual_boundary_projection_sync :
    generatedBoundaryProjection = manualBoundaryProjection := by
  calc
    generatedBoundaryProjection = List.replicate 7 officialBoundaryTag :=
      generated_boundary_projection_official
    _ = manualBoundaryProjection := by
      symm
      exact manual_boundary_projection_official

theorem generated_boundary_projection_eq_registry_boundary :
    generatedBoundaryProjection = clayTargetRegistry.map (fun c => c.boundaryTag) := by
  simpa [manualBoundaryProjection] using generated_manual_boundary_projection_sync

structure K29ControlSurfaceSyncMatrix where
  generatedReturnLockAllLocked : generatedObligationReturnLockProjection = List.replicate 7 ReturnLockStatus.locked
  generatedDecisionAllAllowed : generatedObligationDecisionProjection = List.replicate 7 ImportDecision.allowed
  generatedDebtAllOpen : generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt
  generatedManualBoundarySync : generatedBoundaryProjection = manualBoundaryProjection
  generatedBoundaryEqRegistryBoundary :
    generatedBoundaryProjection = clayTargetRegistry.map (fun c => c.boundaryTag)

def k29_control_surface_sync_matrix : K29ControlSurfaceSyncMatrix :=
{
  generatedReturnLockAllLocked := generated_obligation_return_lock_all_locked,
  generatedDecisionAllAllowed := generated_obligation_decision_all_allowed,
  generatedDebtAllOpen := generated_obligation_debt_all_open,
  generatedManualBoundarySync := generated_manual_boundary_projection_sync,
  generatedBoundaryEqRegistryBoundary := generated_boundary_projection_eq_registry_boundary
}

end CROOT
