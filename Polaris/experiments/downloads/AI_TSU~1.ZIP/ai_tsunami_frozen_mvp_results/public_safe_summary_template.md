
# Public Safe Summary Template

This is a safe public summary template. Do not include packet schema, corruption recipes, judge rubric, P0/P1 role mapping, or DDI repair details.

Trial: AI_TSUNAMI_FROZEN_MVP_PRIMARY  
Case count: 48  
Arms: A/B/C/D  
Models: gpt-4.1 and gpt-4.1-mini  
Global level: L2_QUALITY_SEED  

Safe metrics:
- Candidate C mean score
- Raw TokenRatio C/A
- Amortized TokenRatio C/A
- C minus D
- Failure signature match
- Leakage count

Claim boundary:
Scoped topology-conservation MVP primary trial only. Not universal proof.
