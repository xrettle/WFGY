import CROOT.Core.ProblemSpec

namespace CROOT

structure DomainCoreSignature where
  objectTag : String
  operationTag : String
  invariantTag : String
  deriving DecidableEq, Repr

structure FormalizationTargetContract where
  problem : ProblemId
  statementTag : String
  domainTag : String
  boundaryTag : String
  deriving DecidableEq, Repr

def contractFromSpec (p : ProblemId) (boundary : String) : FormalizationTargetContract :=
  let spec := canonicalSpec p
  {
    problem := p
    statementTag := spec.statementTag
    domainTag := spec.domainTag
    boundaryTag := boundary
  }

def targetContractShapeValid (c : FormalizationTargetContract) : Prop :=
  c.statementTag.length > 0 /\
  c.domainTag.length > 0 /\
  c.boundaryTag.length > 0

end CROOT
