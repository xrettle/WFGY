import CROOT.Kernels.K55_UnifiedCreatorAuditPortal

namespace CROOT

structure K56UnifiedDualProjectionBridge where
  canonicalTrackProblemPair :
    (forall lane, laneTrackProjection lane = canonicalTrackProjection) /\
    (forall lane, laneProblemProjection lane = canonicalProblemIds)
  dualNodup :
    (forall lane, (laneTrackProjection lane).Nodup) /\
    (forall lane, (laneProblemProjection lane).Nodup)
  dualCountSeven :
    (forall lane, (laneTrackProjection lane).length = 7) /\
    (forall lane, (laneProblemProjection lane).length = 7)
  statementDomainSync :
    (forall lane, laneStatementProjection lane = statementTagProjectionFromContracts) /\
    (forall lane, laneDomainProjection lane = canonicalDomainTagProjection)
  normalizedStatementSync :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  returnLockAndDebt :
    (forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked) /\
    (generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt)

def k56_unified_dual_projection_bridge : K56UnifiedDualProjectionBridge :=
{
  canonicalTrackProblemPair := by
    exact And.intro
      k55_unified_creator_audit_portal.trackEqCanonical
      k55_unified_creator_audit_portal.problemEqCanonical,
  dualNodup := by
    exact And.intro
      k55_unified_creator_audit_portal.trackNodup
      k55_unified_creator_audit_portal.problemNodup,
  dualCountSeven := by
    exact And.intro
      k55_unified_creator_audit_portal.trackCountSeven
      k55_unified_creator_audit_portal.problemCountSeven,
  statementDomainSync := by
    exact And.intro
      k55_unified_creator_audit_portal.statementEqContracts
      k55_unified_creator_audit_portal.domainEqCanonical,
  normalizedStatementSync :=
    k55_unified_creator_audit_portal.normalizedStatementEqAdapterContracts,
  returnLockAndDebt := by
    exact And.intro
      k55_unified_creator_audit_portal.returnLockAllLocked
      k55_unified_creator_audit_portal.debtAllOpen
}

end CROOT
