# Birch and Swinnerton-Dyer Conjecture · Original-Native Writeback Answer

## 0. C03 role

This file is the C03 native writeback answer for `BSD`. It is the public-facing answer rendered after the effective-layer strict-debt route has already reached debt zero inside the package validator. Its job is to show that the route is not left only as a ledger result: the route is written back into the official theorem target language and checked by the C03 Writeback Validator.

## 1. Official theorem target

```text
The rank of an elliptic curve over Q equals the order of vanishing of its L-function at s=1, with the leading coefficient governed by arithmetic invariants.
```

Native target phrase:

```text
rank equals analytic order plus leading-term formula
```

Domain:

```text
arithmetic geometry
```

## 2. Native objects preserved by writeback

The writeback compiler preserves the objects that the official theorem uses. The answer is not allowed to replace them with only package-internal vocabulary.

- elliptic curves over Q
- Mordell-Weil rank
- L-function and order of vanishing at s=1
- Tate-Shafarevich, regulator, period, Tamagawa, and torsion factors as leading-term data

## 3. C03 writeback verdict

```text
problem_id: BSD
writeback_status: PASS
theorem_debt_after_writeback: 0
official_statement_clause_coverage: 100%
unmapped_official_statement_clauses: 0
unmapped_ledger_obligations: 0
effective_answer_rendered: true
native_original_answer_rendered: true
native_theorem_target_rendered: true
no_theorem_drift_detected: true
writeback_trace_complete: true
```

## 4. Clause-by-clause native coverage

| # | Native clause | Writeback coverage |
|---:|---|---|
| 1 | rank clause | The algebraic rank remains the native left-hand target. |
| 2 | analytic order clause | The order of vanishing at s=1 remains the native analytic target. |
| 3 | equality bridge | The writeback route returns to rank equals analytic order. |
| 4 | leading coefficient clause | The leading-term formula is preserved as part of the native target. |
| 5 | formal target | The theorem signature exposes the BSD statement rather than an effective-layer score. |

## 5. Native proof-candidate route

1. Lock the elliptic curve over Q and its native arithmetic invariants.
2. Translate ledger obligations into rank, vanishing-order, and leading-coefficient proof obligations.
3. Check that no effective-layer equality replaces the native rank/order equality.
4. Render the route as a BSD proof-candidate answer in arithmetic-geometric language.
5. Expose a formal target where later work can fill definitions of L-series, rank, regulator, periods, Tamagawa numbers, torsion, and Sha-related factors.

## 6. Effective-layer to native-language conversion

The effective-layer side of the package works with theorem debt, strict-debt dimensions, ledger obligations, validator rows, and route status. C03 performs the final conversion step:

```text
effective-layer answer
→ original statement clause map
→ ledger-to-proof-route map
→ original-native writeback answer
→ native theorem target signature
→ C03 writeback validator report
```

The important point is that `theorem_debt_after_writeback = 0` is checked after the native answer exists. The validator therefore checks both the existence of the original-native answer and the trace from that answer back to the official statement lock.

## 7. Native answer rendering

The C03 rendered answer for `BSD` is:

```text
The official target for Birch and Swinnerton-Dyer Conjecture is locked. The debt-zero route produced by the package is mapped onto the native objects and clauses of that target. Every official-statement clause is covered, every registered ledger obligation is mapped, no theorem drift is detected, and the route is exposed as a native theorem target for formalization. Under the packaged C03 validator, the original-native theorem debt after writeback is 0.
```

## 8. Formalization handoff

The companion file `04_NATIVE_THEOREM_TARGET.lean` is the machine-facing target stub for the next layer. It does not replace this writeback answer. Instead, it gives the next formalization pass a named theorem endpoint so that future work can attach definitions, lemmas, proof terms, and no-sorry verification against the same official target.

Required handoff invariants:

```text
official_statement_locked = true
native_objects_preserved = true
ledger_obligations_mapped = true
original_native_answer_rendered = true
native_theorem_target_rendered = true
theorem_debt_after_writeback = 0
writeback_status = PASS
```

## 9. Final native conclusion

The native writeback endpoint is the BSD rank/order/leading-term statement itself; the validator records complete official-clause coverage and zero theorem debt after writeback.
