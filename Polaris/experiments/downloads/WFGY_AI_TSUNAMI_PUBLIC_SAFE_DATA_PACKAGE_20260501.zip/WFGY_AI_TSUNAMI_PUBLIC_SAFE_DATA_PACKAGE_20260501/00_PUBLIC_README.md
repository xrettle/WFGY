# WFGY AI Tsunami Public Safe Data Package

Created: 2026-05-01T10:00:00Z

This is a public-safe aggregate data package for the AI Tsunami branch.
It is intentionally limited to stage-level and aggregate metrics.

This package does **not** include executable notebooks, raw outputs, prompt manifests, case payloads, judge rows, evaluator logic, scoring contracts, or any file that can be used to reconstruct the internal experiment engine.

## What this package supports

This package supports the following public statement:

The AI Tsunami branch reached a scoped T4 Robustness Expansion PASS under topology-conservation workloads, based on aggregate API metrics and stage-level evidence summaries.

## What this package does not support

This package must not be used to claim:

1. All AI tasks are solved.
2. Small models universally beat large models.
3. Coding, math, creative generation, multimodal, or agent execution are already completed by this package.
4. Moses plus Tsunami final merge is complete.
5. A public reader can reproduce the internal evaluator or full private experiment stack from this package.

## Files

- `01_PUBLIC_CLAIM_BOUNDARY.md`: allowed and disallowed public claims.
- `02_AGGREGATE_API_METRICS_PUBLIC.csv`: aggregate API metrics only.
- `03_AGGREGATE_API_METRICS_PUBLIC.json`: JSON version of the aggregate API metrics.
- `04_SANDBOX_STAGE_SUMMARY_PUBLIC.csv`: high-level sandbox stage context only.
- `05_SANDBOX_STAGE_SUMMARY_PUBLIC.json`: JSON version of the sandbox summary.
- `06_REDACTION_AND_SAFETY_NOTE.md`: explicit explanation of what was removed.
- `07_PUBLIC_SHA256_MANIFEST.csv`: SHA256 hashes for files in this public package.

## Reproducibility boundary

The public package is designed for public review of aggregate outcomes, not private-method replication.
Raw experimental artifacts remain internal by design.
