import CROOT.Kernels.K53_UnifiedInvariantCountBridge

namespace CROOT

structure K54UnifiedCreatorFastpathCore where
  trackInvariant :
    forall lane,
      laneTrackProjection lane = canonicalTrackProjection /\
      (laneTrackProjection lane).Nodup /\
      (laneTrackProjection lane).head? = some Track.PNP /\
      (laneTrackProjection lane).getLast? = some Track.PC
  problemInvariant :
    forall lane,
      laneProblemProjection lane = canonicalProblemIds /\
      (laneProblemProjection lane).Nodup /\
      (laneProblemProjection lane).head? = some ProblemId.pnp /\
      (laneProblemProjection lane).getLast? = some ProblemId.poincare
  statementEqContracts :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  normalizedStatementEqAdapterContracts :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  domainEqCanonical :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  trackCountSeven :
    forall lane, (laneTrackProjection lane).length = 7
  problemCountSeven :
    forall lane, (laneProblemProjection lane).length = 7
  statementCountSeven :
    forall lane, (laneStatementProjection lane).length = 7
  normalizedStatementCountSeven :
    forall lane, (laneNormalizedStatementProjection lane).length = 7
  domainCountSeven :
    forall lane, (laneDomainProjection lane).length = 7
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionAllAllowed :
    forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryAllOfficial :
    forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k54_unified_creator_fastpath_core : K54UnifiedCreatorFastpathCore :=
{
  trackInvariant := k52_unified_invariant_pack.trackInvariant,
  problemInvariant := k52_unified_invariant_pack.problemInvariant,
  statementEqContracts := k52_unified_invariant_pack.statementInvariant,
  normalizedStatementEqAdapterContracts :=
    k53_unified_invariant_count_bridge.normalizedStatementEqAdapterContracts,
  domainEqCanonical := k52_unified_invariant_pack.domainInvariant,
  trackCountSeven := k53_unified_invariant_count_bridge.trackCountSeven,
  problemCountSeven := k53_unified_invariant_count_bridge.problemCountSeven,
  statementCountSeven := k53_unified_invariant_count_bridge.statementCountSeven,
  normalizedStatementCountSeven := k53_unified_invariant_count_bridge.normalizedStatementCountSeven,
  domainCountSeven := k53_unified_invariant_count_bridge.domainCountSeven,
  returnLockAllLocked := k52_unified_invariant_pack.returnLockInvariant,
  decisionAllAllowed := k52_unified_invariant_pack.decisionInvariant,
  boundaryAllOfficial := k52_unified_invariant_pack.boundaryInvariant,
  debtAllOpen := k52_unified_invariant_pack.debtInvariant
}

end CROOT
