import CROOT.Kernels.K47_UnifiedProjectionAnchorKernel

namespace CROOT

structure K48UnifiedNodupEndpointKernel where
  trackLaneNodup :
    ∀ lane, (laneTrackProjection lane).Nodup
  problemLaneNodup :
    ∀ lane, (laneProblemProjection lane).Nodup
  trackLaneHeadLock :
    ∀ lane, (laneTrackProjection lane).head? = some Track.PNP
  trackLaneTailLock :
    ∀ lane, (laneTrackProjection lane).getLast? = some Track.PC
  problemLaneHeadLock :
    ∀ lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  problemLaneTailLock :
    ∀ lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare

def k48_unified_nodup_endpoint_kernel : K48UnifiedNodupEndpointKernel :=
{
  trackLaneNodup := lane_track_projection_nodup,
  problemLaneNodup := lane_problem_projection_nodup,
  trackLaneHeadLock := lane_track_projection_head_lock,
  trackLaneTailLock := lane_track_projection_tail_lock,
  problemLaneHeadLock := lane_problem_projection_head_lock,
  problemLaneTailLock := lane_problem_projection_tail_lock
}

end CROOT
