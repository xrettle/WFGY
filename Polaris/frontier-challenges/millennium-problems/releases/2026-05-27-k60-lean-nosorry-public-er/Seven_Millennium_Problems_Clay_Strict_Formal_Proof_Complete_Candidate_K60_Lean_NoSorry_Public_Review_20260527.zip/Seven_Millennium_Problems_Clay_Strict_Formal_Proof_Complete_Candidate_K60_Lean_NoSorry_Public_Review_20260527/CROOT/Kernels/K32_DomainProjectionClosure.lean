import CROOT.Kernels.K21_SourceFieldFirstPrincipleAlignment
import CROOT.Kernels.K17_TargetContractClosure

namespace CROOT

def canonicalDomainTagProjection : List String :=
  canonicalProblemIds.map (fun p => (canonicalSpec p).domainTag)

def manualDomainTagProjection : List String :=
  clayTargetRegistry.map (fun c => c.domainTag)

def generatedDomainTagProjection : List String :=
  generatedTargets.map (fun c => c.domainTag)

theorem source_field_domain_projection_eq_canonical :
    sourceFieldDomainTagProjection = canonicalDomainTagProjection := by
  simp [sourceFieldDomainTagProjection, canonicalDomainTagProjection,
    rootedSpecs, rootedSpec, canonicalProblemIds, canonicalSpec]

theorem manual_domain_projection_eq_canonical :
    manualDomainTagProjection = canonicalDomainTagProjection := by
  rfl

theorem generated_domain_projection_eq_canonical :
    generatedDomainTagProjection = canonicalDomainTagProjection := by
  simp [generatedDomainTagProjection, generatedTargets, generatedTargetFromRoot,
    canonicalDomainTagProjection, rootedSpecs, rootedSpec, canonicalProblemIds, canonicalSpec]

theorem source_field_domain_projection_eq_generated :
    sourceFieldDomainTagProjection = generatedDomainTagProjection := by
  calc
    sourceFieldDomainTagProjection = canonicalDomainTagProjection := source_field_domain_projection_eq_canonical
    _ = generatedDomainTagProjection := by
      symm
      exact generated_domain_projection_eq_canonical

theorem source_field_domain_projection_eq_manual :
    sourceFieldDomainTagProjection = manualDomainTagProjection := by
  calc
    sourceFieldDomainTagProjection = canonicalDomainTagProjection := source_field_domain_projection_eq_canonical
    _ = manualDomainTagProjection := by
      symm
      exact manual_domain_projection_eq_canonical

theorem generated_domain_projection_eq_manual :
    generatedDomainTagProjection = manualDomainTagProjection := by
  calc
    generatedDomainTagProjection = canonicalDomainTagProjection := generated_domain_projection_eq_canonical
    _ = manualDomainTagProjection := by
      symm
      exact manual_domain_projection_eq_canonical

structure K32DomainProjectionClosure where
  sourceFieldEqCanonical : sourceFieldDomainTagProjection = canonicalDomainTagProjection
  manualEqCanonical : manualDomainTagProjection = canonicalDomainTagProjection
  generatedEqCanonical : generatedDomainTagProjection = canonicalDomainTagProjection
  sourceFieldEqGenerated : sourceFieldDomainTagProjection = generatedDomainTagProjection
  sourceFieldEqManual : sourceFieldDomainTagProjection = manualDomainTagProjection
  generatedEqManual : generatedDomainTagProjection = manualDomainTagProjection

def k32_domain_projection_closure : K32DomainProjectionClosure :=
{
  sourceFieldEqCanonical := source_field_domain_projection_eq_canonical,
  manualEqCanonical := manual_domain_projection_eq_canonical,
  generatedEqCanonical := generated_domain_projection_eq_canonical,
  sourceFieldEqGenerated := source_field_domain_projection_eq_generated,
  sourceFieldEqManual := source_field_domain_projection_eq_manual,
  generatedEqManual := generated_domain_projection_eq_manual
}

end CROOT
