import CROOT.ClayTargets.CompletionLane

namespace CROOT

structure K12CompletionLaneReadiness where
  laneCount : allCompletionLanes.length = 7
  pnpLane : laneShapeValid (completionLaneOf ProblemId.pnp)
  rhLane : laneShapeValid (completionLaneOf ProblemId.rh)
  bsdLane : laneShapeValid (completionLaneOf ProblemId.bsd)
  hodgeLane : laneShapeValid (completionLaneOf ProblemId.hodge)
  nsLane : laneShapeValid (completionLaneOf ProblemId.navierStokes)
  ymLane : laneShapeValid (completionLaneOf ProblemId.yangMills)
  pcLane : laneShapeValid (completionLaneOf ProblemId.poincare)

theorem k12_completion_lane_readiness : K12CompletionLaneReadiness :=
{
  laneCount := all_completion_lanes_length,
  pnpLane := completion_lane_shape_valid ProblemId.pnp,
  rhLane := completion_lane_shape_valid ProblemId.rh,
  bsdLane := completion_lane_shape_valid ProblemId.bsd,
  hodgeLane := completion_lane_shape_valid ProblemId.hodge,
  nsLane := completion_lane_shape_valid ProblemId.navierStokes,
  ymLane := completion_lane_shape_valid ProblemId.yangMills,
  pcLane := completion_lane_shape_valid ProblemId.poincare
}

end CROOT
