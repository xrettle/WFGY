import CROOT.ClayTargets.Registry
import CROOT.Adapters.StatementEquivalenceBridge
import CROOT.Adapters.AuthorityRoutingContract

namespace CROOT

/-
PUBLIC RELEASE TERMINOLOGY NOTE
`TheoremDebtStatus.openDebt` is an internal K60-era identifier. In the public K60
release it means: pending final native theorem-object attachment for the KFinal
stage. It does not mark a defect in the K60 architecture, statement-routing,
projection, or audit envelope.
-/
inductive TheoremDebtStatus where
  | openDebt
  | partialDebt
  | unsupported
  | nonReturningBranch
  | ambiguousEquivalence
  | counterexampleUnclosed
  | closedByEquivalence
  | closedBySourceAnchor
  | closedByCounterexampleElimination
  | closedByReductionSoundness
  | closedByOriginalStatementReturn
  | closedByFormalizationTarget
  deriving DecidableEq, Repr

structure TheoremObligation where
  problem : ProblemId
  statementTag : String
  returnLock : ReturnLockStatus
  adapterDecision : ImportDecision
  debtStatus : TheoremDebtStatus
  deriving DecidableEq, Repr

def baseObligation (p : ProblemId) : TheoremObligation :=
  let c := canonicalStatementContract p
  {
    problem := p
    statementTag := c.officialStatementTag
    returnLock := c.returnLockStatus
    adapterDecision := c.adapterDecision
    debtStatus := TheoremDebtStatus.openDebt
  }

def canonicalObligationChain : List TheoremObligation :=
  [baseObligation ProblemId.pnp,
   baseObligation ProblemId.rh,
   baseObligation ProblemId.bsd,
   baseObligation ProblemId.hodge,
   baseObligation ProblemId.navierStokes,
   baseObligation ProblemId.yangMills,
   baseObligation ProblemId.poincare]

def obligationShapeValid (o : TheoremObligation) : Prop :=
  o.statementTag.length > 0 /\
  o.returnLock = ReturnLockStatus.locked /\
  o.adapterDecision = ImportDecision.allowed

def closeByFormalizationTarget (o : TheoremObligation)
    (_h : o.returnLock = ReturnLockStatus.locked) : TheoremObligation :=
  {
    problem := o.problem
    statementTag := o.statementTag
    returnLock := o.returnLock
    adapterDecision := o.adapterDecision
    debtStatus := TheoremDebtStatus.closedByFormalizationTarget
  }

theorem canonical_obligation_chain_length :
    canonicalObligationChain.length = 7 := by
  rfl

theorem base_obligation_shape_valid (p : ProblemId) :
    obligationShapeValid (baseObligation p) := by
  constructor
  · cases p <;> decide
  constructor
  · rfl
  · rfl

theorem close_by_formalization_preserves_problem
    (o : TheoremObligation) (h : o.returnLock = ReturnLockStatus.locked) :
    (closeByFormalizationTarget o h).problem = o.problem := by
  rfl

theorem close_by_formalization_sets_status
    (o : TheoremObligation) (h : o.returnLock = ReturnLockStatus.locked) :
    (closeByFormalizationTarget o h).debtStatus = TheoremDebtStatus.closedByFormalizationTarget := by
  rfl

theorem close_by_formalization_keeps_lock
    (o : TheoremObligation) (h : o.returnLock = ReturnLockStatus.locked) :
    (closeByFormalizationTarget o h).returnLock = o.returnLock := by
  rfl

end CROOT
