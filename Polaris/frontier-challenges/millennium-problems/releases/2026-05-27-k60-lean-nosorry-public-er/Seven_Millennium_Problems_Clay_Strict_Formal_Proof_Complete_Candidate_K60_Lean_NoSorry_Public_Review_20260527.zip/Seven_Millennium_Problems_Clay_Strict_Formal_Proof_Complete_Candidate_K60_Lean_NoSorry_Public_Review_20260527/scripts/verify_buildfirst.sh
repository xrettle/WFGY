#!/usr/bin/env bash
set -euo pipefail
mkdir -p build_logs

LAKE="${LAKE:-lake}"
LEAN="${LEAN:-lean}"
PYTHON="${PYTHON:-python3}"

echo "[stage 0] versions"
("${LEAN}" --version || true) | tee build_logs/lean_version.txt
("${LAKE}" --version || true) | tee build_logs/lake_version.txt

echo "[stage 1] smoke"
set +e
"${LAKE}" build CROOT.Smoke 2>&1 | tee build_logs/stage1_smoke.log
RC1=${PIPESTATUS[0]}
set -e
echo "${RC1}" > build_logs/stage1_smoke.returncode
if [ "${RC1}" -ne 0 ]; then
  echo "FAILED_AT=stage1_smoke" | tee build_logs/FAILED_AT.txt
  exit "${RC1}"
fi

echo "[stage 2] seal"
set +e
"${LAKE}" build CROOT.Seal 2>&1 | tee build_logs/stage2_seal.log
RC2=${PIPESTATUS[0]}
set -e
echo "${RC2}" > build_logs/stage2_seal.returncode
if [ "${RC2}" -ne 0 ]; then
  echo "FAILED_AT=stage2_seal" | tee build_logs/FAILED_AT.txt
  exit "${RC2}"
fi

echo "[stage 3] buildfirst"
set +e
"${LAKE}" build CROOT.BuildFirst 2>&1 | tee build_logs/stage3_buildfirst.log
RC3=${PIPESTATUS[0]}
set -e
echo "${RC3}" > build_logs/stage3_buildfirst.returncode
if [ "${RC3}" -ne 0 ]; then
  echo "FAILED_AT=stage3_buildfirst" | tee build_logs/FAILED_AT.txt
  exit "${RC3}"
fi

echo "[stage 4] audit"
set +e
"${LAKE}" build CROOT.Audit 2>&1 | tee build_logs/stage4_audit.log
RC_AUDIT=${PIPESTATUS[0]}
set -e
echo "${RC_AUDIT}" > build_logs/stage4_audit.returncode
if [ "${RC_AUDIT}" -ne 0 ]; then
  echo "FAILED_AT=stage4_audit" | tee build_logs/FAILED_AT.txt
  exit "${RC_AUDIT}"
fi

echo "[stage 5] lake build"
set +e
"${LAKE}" build 2>&1 | tee build_logs/lake_build.log
RC4=${PIPESTATUS[0]}
set -e
echo "${RC4}" > build_logs/lake_build.returncode
if [ "${RC4}" -ne 0 ]; then
  echo "FAILED_AT=lake_build" | tee build_logs/FAILED_AT.txt
  exit "${RC4}"
fi

echo "[stage 6] no-sorry scan"
set +e
"${PYTHON}" scripts/no_sorry_scan.py 2>&1 | tee build_logs/no_sorry_scan.log
RC5=${PIPESTATUS[0]}
set -e
echo "${RC5}" > build_logs/no_sorry_scan.returncode
if [ "${RC5}" -ne 0 ]; then
  echo "FAILED_AT=no_sorry_scan" | tee build_logs/FAILED_AT.txt
  exit "${RC5}"
fi

echo "FAILED_AT=NONE" | tee build_logs/FAILED_AT.txt

cat > build_logs/MACHINE_CHECK_STEP1_CERTIFICATE.txt <<'EOF'
MACHINE_CHECK_STEP1_CERTIFICATE
TARGET: K1-K5 framework + seven-track instantiation
RESULT: PASS
REQUIRED_STAGES:
- lake build CROOT.Smoke
- lake build CROOT.Seal
- lake build CROOT.BuildFirst
- lake build CROOT.Audit
- lake build
- no-sorry scan
CLOSED_OBJECTS:
- framework_seven_track_seal
- buildFirstSeal
- proof_object_audit_pass
CLAIM_CEILING:
- This certifies the Lean framework/seven-track package only.
- This does not certify native Clay theorem proofs.
- This does not certify official Clay acceptance.
EOF

echo "BUILD_FIRST_VERIFY_PASS"
