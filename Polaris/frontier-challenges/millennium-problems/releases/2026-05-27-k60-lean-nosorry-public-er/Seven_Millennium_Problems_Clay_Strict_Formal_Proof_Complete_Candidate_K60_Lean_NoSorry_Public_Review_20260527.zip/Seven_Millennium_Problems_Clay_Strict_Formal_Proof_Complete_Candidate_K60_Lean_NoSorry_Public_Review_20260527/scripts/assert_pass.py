#!/usr/bin/env python3
from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parents[1]
report_path = ROOT / "BUILD_REPORT.json"
triage_path = ROOT / "TRIAGE_REPORT.json"
cert_path = ROOT / "build_logs" / "MACHINE_CHECK_STEP1_CERTIFICATE.txt"

errors = []
if not report_path.exists():
    errors.append("BUILD_REPORT.json missing")
else:
    r = json.loads(report_path.read_text(encoding="utf-8"))
    if r.get("failed_at") != "FAILED_AT=NONE":
        errors.append(f"failed_at not NONE: {r.get('failed_at')}")
    for k in ["stage1_smoke_returncode","stage2_seal_returncode","stage3_buildfirst_returncode","stage4_audit_returncode","lake_build_returncode","no_sorry_scan_returncode"]:
        if str(r.get(k)).strip() != "0":
            errors.append(f"{k} != 0: {r.get(k)}")
    if r.get("forbidden_tokens"):
        errors.append(f"forbidden tokens found: {r.get('forbidden_tokens')}")
    if not r.get("machine_check_step1_certificate_present"):
        errors.append("certificate not present according to report")

if not triage_path.exists():
    errors.append("TRIAGE_REPORT.json missing")
else:
    t = json.loads(triage_path.read_text(encoding="utf-8"))
    if t.get("failed_at") != "FAILED_AT=NONE":
        errors.append(f"triage failed_at not NONE: {t.get('failed_at')}")

if not cert_path.exists():
    errors.append("MACHINE_CHECK_STEP1_CERTIFICATE.txt missing")

if errors:
    print("ASSERT PASS FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print("ASSERT PASS OK")
