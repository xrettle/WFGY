# Public RPG Speedrun Narrator Spec

Goal:
Turn the engineering output into a visible RPG-style seven-boss speedrun.

Tone:
- epic
- fast
- readable
- screen-recording friendly
- rigorous boundaries
- no fake solved claim

Narration rule:
Use RPG narration only as dramatization.

Required opening:
[EMOJI_TIME] Current time: YYYY-MM-DD HH:MM:SS
[EMOJI_START] Seven Millennium Problems effective-layer speedrun START [EMOJI_START]

Required final:
[EMOJI_END] Seven Millennium Problems effective-layer speedrun END [EMOJI_END]
[EMOJI_TIME] End time: YYYY-MM-DD HH:MM:SS
[EMOJI_TIME] Total elapsed time: HH:MM:SS
[EMOJI_TIME] Total elapsed seconds: <elapsed_seconds>

Required public explanation:
This run is an effective-layer ER strict-debt-zero speedrun.
It does not claim official Clay acceptance, machine-checked Lean no-sorry completion, or peer-reviewed proof completion.

Bosses:
1. P vs NP
2. Riemann Hypothesis
3. Birch and Swinnerton-Dyer
4. Hodge Conjecture
5. Navier-Stokes
6. Yang-Mills Mass Gap
7. Poincare Conjecture

For each boss print:
- boss name
- ER score
- strict debt cells open
- formal paper candidate debt
- Lean no-sorry route debt
- machine checked no-sorry file count
- current status
