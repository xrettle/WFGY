import CROOT.Kernels.K57_UnifiedAuditFastpathSeal
import CROOT.Kernels.K54_UnifiedCreatorFastpathCore

namespace CROOT

structure K58UnifiedAuditControlSeal where
  trackCanonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection
  problemCanonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds
  trackNodup :
    forall lane, (laneTrackProjection lane).Nodup
  problemNodup :
    forall lane, (laneProblemProjection lane).Nodup
  trackCountSeven :
    forall lane, (laneTrackProjection lane).length = 7
  problemCountSeven :
    forall lane, (laneProblemProjection lane).length = 7
  trackHeadLock :
    forall lane, (laneTrackProjection lane).head? = some Track.PNP
  trackTailLock :
    forall lane, (laneTrackProjection lane).getLast? = some Track.PC
  problemHeadLock :
    forall lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  problemTailLock :
    forall lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare
  statementSync :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  domainSync :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  normalizedStatementSync :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionAllAllowed :
    forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryAllOfficial :
    forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k58_unified_audit_control_seal : K58UnifiedAuditControlSeal :=
{
  trackCanonical := k57_unified_audit_fastpath_seal.trackCanonical,
  problemCanonical := k57_unified_audit_fastpath_seal.problemCanonical,
  trackNodup := k57_unified_audit_fastpath_seal.trackNodup,
  problemNodup := k57_unified_audit_fastpath_seal.problemNodup,
  trackCountSeven := k57_unified_audit_fastpath_seal.trackCountSeven,
  problemCountSeven := k57_unified_audit_fastpath_seal.problemCountSeven,
  trackHeadLock := by
    intro lane
    exact (k54_unified_creator_fastpath_core.trackInvariant lane).right.right.left,
  trackTailLock := by
    intro lane
    exact (k54_unified_creator_fastpath_core.trackInvariant lane).right.right.right,
  problemHeadLock := by
    intro lane
    exact (k54_unified_creator_fastpath_core.problemInvariant lane).right.right.left,
  problemTailLock := by
    intro lane
    exact (k54_unified_creator_fastpath_core.problemInvariant lane).right.right.right,
  statementSync := k57_unified_audit_fastpath_seal.statementSync,
  domainSync := k57_unified_audit_fastpath_seal.domainSync,
  normalizedStatementSync := k57_unified_audit_fastpath_seal.normalizedStatementSync,
  returnLockAllLocked := k57_unified_audit_fastpath_seal.returnLockAllLocked,
  decisionAllAllowed := k54_unified_creator_fastpath_core.decisionAllAllowed,
  boundaryAllOfficial := k54_unified_creator_fastpath_core.boundaryAllOfficial,
  debtAllOpen := k57_unified_audit_fastpath_seal.debtAllOpen
}

end CROOT
