import CROOT.Kernels.K10_ProofCapsuleContract

namespace CROOT

structure ReplayInput where
  problem : ProblemId
  seed : Nat
  payloadHash : Nat
  deriving DecidableEq, Repr

structure ReplayOutput where
  problem : ProblemId
  transcriptHash : Nat
  deriving DecidableEq, Repr

def problemCode (p : ProblemId) : Nat :=
  match p with
  | ProblemId.pnp => 11
  | ProblemId.rh => 13
  | ProblemId.bsd => 17
  | ProblemId.hodge => 19
  | ProblemId.navierStokes => 23
  | ProblemId.yangMills => 29
  | ProblemId.poincare => 31

def replayEngine (input : ReplayInput) : ReplayOutput :=
  {
    problem := input.problem,
    transcriptHash := input.seed + input.payloadHash + problemCode input.problem
  }

theorem replay_engine_deterministic (x y : ReplayInput) :
    x = y -> replayEngine x = replayEngine y := by
  intro h
  cases h
  rfl

theorem replay_preserves_problem (input : ReplayInput) :
    (replayEngine input).problem = input.problem := by
  rfl

structure K11ReplayDeterminism where
  deterministic : forall x y : ReplayInput, x = y -> replayEngine x = replayEngine y
  preservesProblem : forall input : ReplayInput, (replayEngine input).problem = input.problem

theorem k11_replay_determinism : K11ReplayDeterminism :=
{
  deterministic := replay_engine_deterministic,
  preservesProblem := replay_preserves_problem
}

end CROOT
