import CROOT.Kernels.K33_TrackProjectionClosure

namespace CROOT

theorem canonical_track_projection_head_lock :
    canonicalTrackProjection.head? = some Track.PNP := by
  simp [canonical_track_projection_eq_all_tracks, allTracks]

theorem canonical_track_projection_tail_lock :
    canonicalTrackProjection.getLast? = some Track.PC := by
  simp [canonical_track_projection_eq_all_tracks, allTracks]

theorem source_field_track_projection_head_lock :
    sourceFieldTrackProjection.head? = some Track.PNP := by
  simp [source_field_track_projection_eq_all_tracks, allTracks]

theorem source_field_track_projection_tail_lock :
    sourceFieldTrackProjection.getLast? = some Track.PC := by
  simp [source_field_track_projection_eq_all_tracks, allTracks]

theorem manual_track_projection_head_lock :
    manualTrackProjection.head? = some Track.PNP := by
  simp [manual_track_projection_eq_all_tracks, allTracks]

theorem manual_track_projection_tail_lock :
    manualTrackProjection.getLast? = some Track.PC := by
  simp [manual_track_projection_eq_all_tracks, allTracks]

theorem generated_track_projection_head_lock :
    generatedTrackProjection.head? = some Track.PNP := by
  simp [generated_track_projection_eq_all_tracks, allTracks]

theorem generated_track_projection_tail_lock :
    generatedTrackProjection.getLast? = some Track.PC := by
  simp [generated_track_projection_eq_all_tracks, allTracks]

structure K34TrackEndpointLockMatrix where
  canonicalHeadLock : canonicalTrackProjection.head? = some Track.PNP
  canonicalTailLock : canonicalTrackProjection.getLast? = some Track.PC
  sourceFieldHeadLock : sourceFieldTrackProjection.head? = some Track.PNP
  sourceFieldTailLock : sourceFieldTrackProjection.getLast? = some Track.PC
  manualHeadLock : manualTrackProjection.head? = some Track.PNP
  manualTailLock : manualTrackProjection.getLast? = some Track.PC
  generatedHeadLock : generatedTrackProjection.head? = some Track.PNP
  generatedTailLock : generatedTrackProjection.getLast? = some Track.PC

def k34_track_endpoint_lock_matrix : K34TrackEndpointLockMatrix :=
{
  canonicalHeadLock := canonical_track_projection_head_lock,
  canonicalTailLock := canonical_track_projection_tail_lock,
  sourceFieldHeadLock := source_field_track_projection_head_lock,
  sourceFieldTailLock := source_field_track_projection_tail_lock,
  manualHeadLock := manual_track_projection_head_lock,
  manualTailLock := manual_track_projection_tail_lock,
  generatedHeadLock := generated_track_projection_head_lock,
  generatedTailLock := generated_track_projection_tail_lock
}

end CROOT
