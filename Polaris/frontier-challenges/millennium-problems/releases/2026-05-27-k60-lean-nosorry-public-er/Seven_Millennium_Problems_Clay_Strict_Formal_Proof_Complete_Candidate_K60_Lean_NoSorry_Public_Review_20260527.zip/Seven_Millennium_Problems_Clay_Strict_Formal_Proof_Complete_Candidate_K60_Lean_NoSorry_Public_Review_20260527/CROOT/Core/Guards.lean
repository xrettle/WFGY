import CROOT.Core.Types

namespace CROOT

def isConclusionMarker (m : Marker) : Bool :=
  match m with
  | Marker.conclusionLike => true
  | Marker.neutral => false
  | Marker.successLike => false

def isSuccessMarker (m : Marker) : Bool :=
  match m with
  | Marker.successLike => true
  | Marker.neutral => false
  | Marker.conclusionLike => false

def isOfficialBoundary (b : Boundary) : Bool :=
  match b with
  | Boundary.official => true
  | Boundary.outside => false

def noConclusionGuard (a : Atom) : Prop :=
  isConclusionMarker a.marker = false

def noSuccessGuard (a : Atom) : Prop :=
  isSuccessMarker a.marker = false

def officialBoundaryGuard (a : Atom) : Prop :=
  isOfficialBoundary a.boundary = true

def noCrossTrackLeak (source target : Track) : Prop :=
  source = target

def routeAtom (a : Atom) : Route :=
  match a.boundary with
  | Boundary.official => Route.carrier a
  | Boundary.outside => Route.blocker a ObstructionClass.vocabulary

theorem carrier_preserves_atom (a b : Atom) :
    routeAtom a = Route.carrier b -> b = a := by
  cases a with
  | mk tr bd mr rid oc =>
    cases bd
    · intro h
      cases h
      rfl
    · intro h
      cases h

theorem carrier_preserves_track (a b : Atom) :
    routeAtom a = Route.carrier b -> b.track = a.track := by
  intro h
  have hb : b = a := carrier_preserves_atom a b h
  rw [hb]

theorem carrier_preserves_boundary (a b : Atom) :
    routeAtom a = Route.carrier b -> b.boundary = a.boundary := by
  intro h
  have hb : b = a := carrier_preserves_atom a b h
  rw [hb]

theorem carrier_preserves_marker (a b : Atom) :
    routeAtom a = Route.carrier b -> b.marker = a.marker := by
  intro h
  have hb : b = a := carrier_preserves_atom a b h
  rw [hb]

end CROOT
