
# AI Tsunami Frozen MVP Primary v3 Blackfan Audit

Generated UTC: 2026-05-01T06:31:56.718458Z

## Verdict

Global level: `L5_FROZEN_MVP_PRIMARY_PASS`
Global pass: `True`

## Claim boundary

Scoped topology-conservation Frozen MVP Primary only.
Not universal proof.
Not GPU myth broken.
Not one-shot killer final proof.

## Key metrics

- Expected outputs: 192
- Actual outputs: 192
- API error count: 0
- Parse pass rate: 1.0
- A mean: 0.85
- B mean: 0.975
- C mean: 0.9375
- D mean: 0.25625
- C minus A: 0.08750000000000002
- Retention C/B: 0.9615384615384616
- C case pass rate at score >= 0.75: 1.0
- C min score observed: 0.75
- Retention champagne target: 0.97
- Raw TokenRatio C/A: 0.23207865953581727
- Amortized TokenRatio C/A: 0.17405899465186295
- C minus D: 0.68125
- FailureSignatureMatch: 1.0
- LeakageCount: 0
- Worst unit: A001
- Worst unit C score: 0.9166666666666666

## Gates

{
  "output_complete": true,
  "parse_pass": true,
  "c_mean_quality": true,
  "c_case_pass_rate": true,
  "retention_c_b": true,
  "raw_token_ratio": true,
  "amortized_token_ratio": true,
  "c_minus_d": true,
  "failure_signature": true,
  "leakage": true,
  "worst_unit": true
}

## Rule

No DDI may overwrite this verdict.
If failed, create a new frozen trial version.
