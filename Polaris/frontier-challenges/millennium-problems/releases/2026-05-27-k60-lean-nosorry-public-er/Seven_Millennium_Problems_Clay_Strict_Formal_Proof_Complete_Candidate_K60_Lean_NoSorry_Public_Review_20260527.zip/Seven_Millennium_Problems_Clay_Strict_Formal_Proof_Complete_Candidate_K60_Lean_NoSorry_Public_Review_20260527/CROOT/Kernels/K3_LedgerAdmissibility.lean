import CROOT.Core.Types
import CROOT.Core.Guards
import CROOT.Core.Ledger

namespace CROOT

def transportEntry (e : LedgerEntry) : Option LedgerEntry :=
  match e.atom.boundary, e.atom.marker with
  | Boundary.official, Marker.neutral => some e
  | Boundary.official, Marker.conclusionLike => none
  | Boundary.official, Marker.successLike => none
  | Boundary.outside, _ => none

theorem K3_transport_official_neutral_some
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.official, marker := Marker.neutral, residualId := rid, obstructionClass := oc }
    } =
    some {
      key := key,
      atom := { track := track, boundary := Boundary.official, marker := Marker.neutral, residualId := rid, obstructionClass := oc }
    } := by
  rfl

theorem K3_transport_conclusion_none
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.official, marker := Marker.conclusionLike, residualId := rid, obstructionClass := oc }
    } = none := by
  rfl

theorem K3_transport_success_none
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.official, marker := Marker.successLike, residualId := rid, obstructionClass := oc }
    } = none := by
  rfl

theorem K3_transport_outside_neutral_none
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.outside, marker := Marker.neutral, residualId := rid, obstructionClass := oc }
    } = none := by
  rfl

theorem K3_transport_outside_conclusion_none
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.outside, marker := Marker.conclusionLike, residualId := rid, obstructionClass := oc }
    } = none := by
  rfl

theorem K3_transport_outside_success_none
    (key : LedgerKey) (track : Track) (rid : ResidualId) (oc : ObstructionClass) :
    transportEntry {
      key := key,
      atom := { track := track, boundary := Boundary.outside, marker := Marker.successLike, residualId := rid, obstructionClass := oc }
    } = none := by
  rfl

theorem K3_merge_left (x y : LedgerEntry) :
    mergeIfSameKey x y = x :=
  merge_left x y

theorem K3_admissible_has_official (e : LedgerEntry) :
    admissibleLedgerEntry e -> officialBoundaryGuard e.atom := by
  intro h
  exact h.left

theorem K3_admissible_has_no_conclusion (e : LedgerEntry) :
    admissibleLedgerEntry e -> noConclusionGuard e.atom := by
  intro h
  exact h.right.left

theorem K3_admissible_has_no_success (e : LedgerEntry) :
    admissibleLedgerEntry e -> noSuccessGuard e.atom := by
  intro h
  exact h.right.right

end CROOT
