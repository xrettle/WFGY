
# AI Tsunami T3 Internal Scale v1 Blackfan Audit

Generated UTC: 2026-05-01T06:55:20.619346Z

## Verdict

Global level: `L5_T3_INTERNAL_SCALE_PASS`
Global pass: `True`

## Claim boundary

Scoped topology-conservation T3 Internal Scale only.
Not universal proof.
Not GPU myth broken.
Not one-shot killer final proof.

## Key metrics

- Expected outputs: 320
- Actual outputs: 320
- API error count: 0
- Parse pass rate: 1.0
- A mean: 0.885
- B mean: 0.975
- C mean: 0.9349999999999999
- D mean: 0.25125
- C minus A: 0.04999999999999993
- Retention C/B: 0.9589743589743589
- C case pass rate at score >= 0.75: 1.0
- C min score observed: 0.75
- Retention champagne target: 0.95
- Raw TokenRatio C/A: 0.22059858516234357
- Amortized TokenRatio C/A: 0.16544893887175768
- C minus D: 0.68375
- FailureSignatureMatch: 1.0
- LeakageCount: 0
- Worst unit: A003
- Worst unit C score: 0.9

## Gates

{
  "output_complete": true,
  "parse_pass": true,
  "c_mean_quality": true,
  "c_case_pass_rate": true,
  "retention_c_b": true,
  "raw_token_ratio": true,
  "amortized_token_ratio": true,
  "c_minus_d": true,
  "failure_signature": true,
  "leakage": true,
  "worst_unit": true
}

## Rule

No DDI may overwrite this verdict.
If failed, create a new frozen trial version.
