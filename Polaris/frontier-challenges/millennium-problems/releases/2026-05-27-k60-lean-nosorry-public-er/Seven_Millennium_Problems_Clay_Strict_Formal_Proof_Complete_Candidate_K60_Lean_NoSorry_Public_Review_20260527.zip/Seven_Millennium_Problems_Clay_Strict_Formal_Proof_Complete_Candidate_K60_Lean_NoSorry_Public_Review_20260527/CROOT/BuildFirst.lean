import CROOT.Seal

namespace CROOT

/-
BuildFirst is the first machine-check target.
If this file typechecks, the framework seal object exists in Lean.
-/

def buildFirstSeal : FrameworkSevenTrackSeal :=
  framework_seven_track_seal

theorem buildFirst_has_kernel :
    buildFirstSeal.kernel = kernel_bundle_verified := by
  rfl

theorem buildFirst_has_seven :
    buildFirstSeal.seven = seven_track_instantiation_verified := by
  rfl

theorem buildFirst_exact_seven :
    buildFirstSeal.seven.exactSeven = K5_allTracks_length := by
  rfl

end CROOT
