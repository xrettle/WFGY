import CROOT.Seal
import CROOT.Kernels.K12_StrictFormalSealEnvelope

namespace CROOT

structure K12BundleVerified where
  k1ToK5Seal : FrameworkSevenTrackSeal
  k6ToK12Seal : K12StrictFormalSealEnvelope

theorem k12_bundle_verified : K12BundleVerified :=
{
  k1ToK5Seal := framework_seven_track_seal,
  k6ToK12Seal := k12_strict_formal_seal_envelope
}

theorem k12_bundle_has_framework :
    k12_bundle_verified.k1ToK5Seal = framework_seven_track_seal := by
  rfl

theorem k12_bundle_has_capsule_count :
    canonicalCapsules.length = 7 := by
  exact k12_bundle_verified.k6ToK12Seal.k10.capsuleCount

theorem k12_bundle_has_obligation_count :
    canonicalObligationChain.length = 7 := by
  exact k12_bundle_verified.k6ToK12Seal.k11Obligation.chainCount

theorem k12_bundle_has_completion_lane_count :
    allCompletionLanes.length = 7 := by
  exact k12_bundle_verified.k6ToK12Seal.k12Lane.laneCount

theorem k12_bundle_has_prototype_pair_count :
    prototypePair.length = 2 := by
  exact k12_bundle_verified.k6ToK12Seal.k12PrototypePair.pairCount

end CROOT
