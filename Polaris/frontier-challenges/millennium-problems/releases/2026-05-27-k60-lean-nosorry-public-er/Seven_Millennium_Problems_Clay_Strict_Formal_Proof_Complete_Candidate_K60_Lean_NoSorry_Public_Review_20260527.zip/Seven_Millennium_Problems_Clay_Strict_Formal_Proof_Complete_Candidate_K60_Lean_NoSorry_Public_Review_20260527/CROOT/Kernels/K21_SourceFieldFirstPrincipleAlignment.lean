import CROOT.Kernels.K20_StatementTagProjectionClosure
import CROOT.Root.SameRootKernel

namespace CROOT

def sourceFieldProblemProjection : List ProblemId :=
  rootedSpecs.map (fun rp => rp.spec.id)

def sourceFieldStatementTagProjection : List String :=
  rootedSpecs.map (fun rp => rp.spec.statementTag)

def sourceFieldDomainTagProjection : List String :=
  rootedSpecs.map (fun rp => rp.spec.domainTag)

theorem source_field_problem_projection_eq_canonical :
    sourceFieldProblemProjection = canonicalProblemIds := by
  simp [sourceFieldProblemProjection, rootedSpecs, rootedSpec, canonicalProblemIds, canonicalSpec]

theorem source_field_statement_projection_eq_specs :
    sourceFieldStatementTagProjection = statementTagProjectionFromSpecs := by
  rfl

theorem source_field_statement_projection_eq_contracts :
    sourceFieldStatementTagProjection = statementTagProjectionFromContracts := by
  simpa [statement_tag_projection_contracts_eq_specs] using source_field_statement_projection_eq_specs

theorem source_field_domain_projection_length :
    sourceFieldDomainTagProjection.length = 7 := by
  simp [sourceFieldDomainTagProjection, rootedSpecs]

structure K21SourceFieldFirstPrincipleAlignment where
  problemSync : sourceFieldProblemProjection = canonicalProblemIds
  statementSyncToSpecs : sourceFieldStatementTagProjection = statementTagProjectionFromSpecs
  statementSyncToContracts : sourceFieldStatementTagProjection = statementTagProjectionFromContracts
  domainProjectionCount : sourceFieldDomainTagProjection.length = 7

def k21_source_field_first_principle_alignment : K21SourceFieldFirstPrincipleAlignment :=
{
  problemSync := source_field_problem_projection_eq_canonical,
  statementSyncToSpecs := source_field_statement_projection_eq_specs,
  statementSyncToContracts := source_field_statement_projection_eq_contracts,
  domainProjectionCount := source_field_domain_projection_length
}

end CROOT
