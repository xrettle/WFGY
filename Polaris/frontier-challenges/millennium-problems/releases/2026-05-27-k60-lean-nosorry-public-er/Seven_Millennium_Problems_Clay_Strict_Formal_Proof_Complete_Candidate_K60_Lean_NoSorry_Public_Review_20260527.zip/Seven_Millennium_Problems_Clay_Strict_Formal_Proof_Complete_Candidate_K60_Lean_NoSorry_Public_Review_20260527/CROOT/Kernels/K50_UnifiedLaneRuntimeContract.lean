import CROOT.Kernels.K49_SharedLaneProofSkeleton

namespace CROOT

structure K50UnifiedLaneRuntimeContract where
  trackEqCanonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection
  problemEqCanonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds
  statementEqContracts :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  normalizedStatementEqAdapterContracts :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  domainEqCanonical :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  trackCountSeven :
    forall lane, (laneTrackProjection lane).length = 7
  problemCountSeven :
    forall lane, (laneProblemProjection lane).length = 7
  statementCountSeven :
    forall lane, (laneStatementProjection lane).length = 7
  normalizedStatementCountSeven :
    forall lane, (laneNormalizedStatementProjection lane).length = 7
  domainCountSeven :
    forall lane, (laneDomainProjection lane).length = 7
  trackNodup :
    forall lane, (laneTrackProjection lane).Nodup
  problemNodup :
    forall lane, (laneProblemProjection lane).Nodup
  trackHeadLock :
    forall lane, (laneTrackProjection lane).head? = some Track.PNP
  trackTailLock :
    forall lane, (laneTrackProjection lane).getLast? = some Track.PC
  problemHeadLock :
    forall lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  problemTailLock :
    forall lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionAllAllowed :
    forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryAllOfficial :
    forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k50_unified_lane_runtime_contract : K50UnifiedLaneRuntimeContract :=
{
  trackEqCanonical := track_lane_core_skeleton.eqCanonical,
  problemEqCanonical := problem_lane_core_skeleton.eqCanonical,
  statementEqContracts := statement_lane_core_skeleton.eqCanonical,
  normalizedStatementEqAdapterContracts := normalized_statement_lane_core_skeleton.eqCanonical,
  domainEqCanonical := domain_lane_core_skeleton.eqCanonical,
  trackCountSeven := track_lane_core_skeleton.countSeven,
  problemCountSeven := problem_lane_core_skeleton.countSeven,
  statementCountSeven := statement_lane_core_skeleton.countSeven,
  normalizedStatementCountSeven := normalized_statement_lane_core_skeleton.countSeven,
  domainCountSeven := domain_lane_core_skeleton.countSeven,
  trackNodup := track_lane_core_skeleton.nodup,
  problemNodup := problem_lane_core_skeleton.nodup,
  trackHeadLock := track_lane_endpoint_lock_skeleton.headLock,
  trackTailLock := track_lane_endpoint_lock_skeleton.tailLock,
  problemHeadLock := problem_lane_endpoint_lock_skeleton.headLock,
  problemTailLock := problem_lane_endpoint_lock_skeleton.tailLock,
  returnLockAllLocked := lane_return_lock_all_locked,
  decisionAllAllowed := lane_decision_all_allowed,
  boundaryAllOfficial := lane_boundary_all_official,
  debtAllOpen := generated_obligation_debt_all_open
}

end CROOT
