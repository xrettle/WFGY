import CROOT.Kernels.K24_ObligationProjectionClosure

namespace CROOT

def generatedCompletionLaneProblemProjection : List ProblemId :=
  generatedCompletionLanes.map (fun lane => lane.problem)

def generatedCompletionLaneMilestoneCountProjection : List Nat :=
  generatedCompletionLanes.map (fun lane => lane.milestones.length)

theorem generated_completion_lanes_eq_canonical :
    generatedCompletionLanes = allCompletionLanes := by
  simp [generatedCompletionLanes, generatedCompletionLaneFromRoot, rootedSpecs, rootedSpec,
    allCompletionLanes, completionLaneOf]
  decide

theorem generated_completion_lane_problem_projection_eq_canonical :
    generatedCompletionLaneProblemProjection = canonicalProblemIds := by
  simp [generatedCompletionLaneProblemProjection, generatedCompletionLanes,
    generatedCompletionLaneFromRoot, rootedSpecs, rootedSpec, canonicalProblemIds]
  decide

theorem generated_completion_lane_milestone_count_uniform :
    generatedCompletionLaneMilestoneCountProjection = List.replicate 7 5 := by
  simp [generatedCompletionLaneMilestoneCountProjection, generatedCompletionLanes,
    generatedCompletionLaneFromRoot, rootedSpecs, rootedSpec, canonicalMilestones]

structure K25CompletionLaneProjectionClosure where
  completionLanesEqCanonical : generatedCompletionLanes = allCompletionLanes
  problemProjectionEqCanonical : generatedCompletionLaneProblemProjection = canonicalProblemIds
  milestoneCountUniform : generatedCompletionLaneMilestoneCountProjection = List.replicate 7 5

def k25_completion_lane_projection_closure : K25CompletionLaneProjectionClosure :=
{
  completionLanesEqCanonical := generated_completion_lanes_eq_canonical,
  problemProjectionEqCanonical := generated_completion_lane_problem_projection_eq_canonical,
  milestoneCountUniform := generated_completion_lane_milestone_count_uniform
}

end CROOT
