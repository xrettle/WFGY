# Formal Proof Repo Link Slot

The package inspection found no repo URL in the local Effective-Layer/Seven artifacts available in this session.

Leave this slot for the project owner:

FORMAL_PROOF_REPO_LINK=<INSERT_REPO_LINK_HERE>

Rules:
- Do not invent a repo URL.
- If a repo URL is provided later, write it here and in the public visible summary.
- The repo link should point to the separate Formal Proof Complete / No-Sorry endpoint.
