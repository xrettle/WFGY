import CROOT.ClayTargets.PrototypeTheoremLane

namespace CROOT

structure K14FullPrototypeLaneSymmetry where
  fullLaneCount : fullPrototypeLanes.length = 7
  pnpValid : prototypeLaneShapeValid pnpPrototypeTheoremLane
  rhValid : prototypeLaneShapeValid rhPrototypeTheoremLane
  bsdValid : prototypeLaneShapeValid bsdPrototypeTheoremLane
  hodgeValid : prototypeLaneShapeValid hodgePrototypeTheoremLane
  nsValid : prototypeLaneShapeValid nsPrototypeTheoremLane
  ymValid : prototypeLaneShapeValid ymPrototypeTheoremLane
  pcValid : prototypeLaneShapeValid pcPrototypeTheoremLane

theorem k14_full_prototype_lane_symmetry : K14FullPrototypeLaneSymmetry :=
{
  fullLaneCount := full_prototype_lanes_length,
  pnpValid := pnp_prototype_shape_valid,
  rhValid := rh_prototype_shape_valid,
  bsdValid := bsd_prototype_shape_valid,
  hodgeValid := hodge_prototype_shape_valid,
  nsValid := ns_prototype_shape_valid,
  ymValid := ym_prototype_shape_valid,
  pcValid := pc_prototype_shape_valid
}

end CROOT
