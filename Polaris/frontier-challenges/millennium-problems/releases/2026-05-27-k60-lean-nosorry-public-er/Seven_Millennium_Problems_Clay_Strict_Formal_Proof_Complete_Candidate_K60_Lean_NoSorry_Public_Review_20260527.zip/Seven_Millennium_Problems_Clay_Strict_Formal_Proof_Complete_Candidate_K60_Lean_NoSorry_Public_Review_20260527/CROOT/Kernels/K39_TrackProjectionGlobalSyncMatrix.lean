import CROOT.Kernels.K38_CoreTrackProjectionNodupCountMatrix

namespace CROOT

theorem source_field_track_projection_eq_generated_obligation :
    sourceFieldTrackProjection = generatedObligationTrackProjection := by
  calc
    sourceFieldTrackProjection = canonicalTrackProjection := source_field_track_projection_eq_canonical
    _ = generatedObligationTrackProjection := by
      symm
      exact generated_obligation_track_projection_eq_canonical

theorem manual_track_projection_eq_generated_obligation :
    manualTrackProjection = generatedObligationTrackProjection := by
  calc
    manualTrackProjection = canonicalTrackProjection := manual_track_projection_eq_canonical
    _ = generatedObligationTrackProjection := by
      symm
      exact generated_obligation_track_projection_eq_canonical

theorem generated_track_projection_eq_generated_obligation :
    generatedTrackProjection = generatedObligationTrackProjection := by
  calc
    generatedTrackProjection = canonicalTrackProjection := generated_track_projection_eq_canonical
    _ = generatedObligationTrackProjection := by
      symm
      exact generated_obligation_track_projection_eq_canonical

theorem source_field_track_projection_eq_generated_completion :
    sourceFieldTrackProjection = generatedCompletionTrackProjection := by
  calc
    sourceFieldTrackProjection = generatedObligationTrackProjection :=
      source_field_track_projection_eq_generated_obligation
    _ = generatedCompletionTrackProjection := obligation_completion_track_projection_sync

theorem source_field_track_projection_eq_generated_prototype :
    sourceFieldTrackProjection = generatedPrototypeTrackProjection := by
  calc
    sourceFieldTrackProjection = generatedObligationTrackProjection :=
      source_field_track_projection_eq_generated_obligation
    _ = generatedPrototypeTrackProjection := obligation_prototype_track_projection_sync

theorem source_field_track_projection_eq_generated_refinement :
    sourceFieldTrackProjection = generatedRefinementTrackProjection := by
  calc
    sourceFieldTrackProjection = generatedObligationTrackProjection :=
      source_field_track_projection_eq_generated_obligation
    _ = generatedRefinementTrackProjection := obligation_refinement_track_projection_sync

structure K39TrackProjectionGlobalSyncMatrix where
  sourceFieldToObligation :
    sourceFieldTrackProjection = generatedObligationTrackProjection
  manualToObligation :
    manualTrackProjection = generatedObligationTrackProjection
  generatedToObligation :
    generatedTrackProjection = generatedObligationTrackProjection
  sourceFieldToCompletion :
    sourceFieldTrackProjection = generatedCompletionTrackProjection
  sourceFieldToPrototype :
    sourceFieldTrackProjection = generatedPrototypeTrackProjection
  sourceFieldToRefinement :
    sourceFieldTrackProjection = generatedRefinementTrackProjection

def k39_track_projection_global_sync_matrix : K39TrackProjectionGlobalSyncMatrix :=
{
  sourceFieldToObligation := source_field_track_projection_eq_generated_obligation,
  manualToObligation := manual_track_projection_eq_generated_obligation,
  generatedToObligation := generated_track_projection_eq_generated_obligation,
  sourceFieldToCompletion := source_field_track_projection_eq_generated_completion,
  sourceFieldToPrototype := source_field_track_projection_eq_generated_prototype,
  sourceFieldToRefinement := source_field_track_projection_eq_generated_refinement
}

end CROOT
