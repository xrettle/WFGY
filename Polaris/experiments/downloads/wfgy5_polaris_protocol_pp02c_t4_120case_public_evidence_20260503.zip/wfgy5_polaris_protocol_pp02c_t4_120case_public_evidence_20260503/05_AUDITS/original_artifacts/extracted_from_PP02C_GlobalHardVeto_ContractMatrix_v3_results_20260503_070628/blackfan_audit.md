Global Hard Veto Contract Matrix v3: strict schema and exact enum validation.
