import CROOT.Kernels.K19_AdapterDrivenContractClosure

namespace CROOT

def statementTagProjectionFromContracts : List String :=
  canonicalStatementContracts.map (fun c => c.officialStatementTag)

def statementTagProjectionFromSpecs : List String :=
  canonicalProblemIds.map (fun p => (canonicalSpec p).statementTag)

def adapterTagProjectionFromContracts : List String :=
  canonicalStatementContracts.map (fun c => c.adapterStatementTag)

def adapterTagProjectionFromSpecs : List String :=
  statementTagProjectionFromSpecs.map normalizeStatementText

theorem statement_tag_projection_contracts_eq_specs :
    statementTagProjectionFromContracts = statementTagProjectionFromSpecs := by
  rfl

theorem adapter_tag_projection_contracts_eq_specs :
    adapterTagProjectionFromContracts = adapterTagProjectionFromSpecs := by
  rfl

theorem adapter_tag_projection_contracts_eq_normalized_official :
    adapterTagProjectionFromContracts = statementTagProjectionFromContracts.map normalizeStatementText := by
  rfl

structure K20StatementTagProjectionClosure where
  statementTagSync : statementTagProjectionFromContracts = statementTagProjectionFromSpecs
  adapterTagSync : adapterTagProjectionFromContracts = adapterTagProjectionFromSpecs
  adapterIsNormalizedOfficial :
    adapterTagProjectionFromContracts = statementTagProjectionFromContracts.map normalizeStatementText

def k20_statement_tag_projection_closure : K20StatementTagProjectionClosure :=
{
  statementTagSync := statement_tag_projection_contracts_eq_specs,
  adapterTagSync := adapter_tag_projection_contracts_eq_specs,
  adapterIsNormalizedOfficial := adapter_tag_projection_contracts_eq_normalized_official
}

end CROOT
