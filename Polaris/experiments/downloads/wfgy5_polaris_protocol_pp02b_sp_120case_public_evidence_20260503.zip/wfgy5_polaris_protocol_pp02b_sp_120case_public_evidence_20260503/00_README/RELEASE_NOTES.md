# Release Notes

Release: WFGY 5.0 Polaris Protocol public evidence package

Branch: PP02B

Package title: PP02B SP Math 120 Case Public Evidence Package

Date label: 20260503

Public package changes:
- Converted the source experiment archive into a standardized public evidence package.
- Preserved raw outputs, parsed outputs, verdicts, metrics, audits, and result evidence.
- Removed execution notebooks from the public package.
- Expanded nested zip artifacts into visible folder structures where needed.
- Regenerated SHA256 manifests and file inventories.
- Added public README, reproducibility note, and claim boundary note.
