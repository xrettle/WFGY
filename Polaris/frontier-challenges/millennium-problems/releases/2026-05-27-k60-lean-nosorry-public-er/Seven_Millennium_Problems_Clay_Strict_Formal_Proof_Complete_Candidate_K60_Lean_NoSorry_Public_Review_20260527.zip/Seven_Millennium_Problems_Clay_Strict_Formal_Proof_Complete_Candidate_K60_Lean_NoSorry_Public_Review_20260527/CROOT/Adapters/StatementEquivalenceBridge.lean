import CROOT.Core.ProblemSpec
import CROOT.Adapters.MathematicalStatementAdapter

namespace CROOT

inductive ReturnLockStatus where
  | locked
  | nonReturning
  | unsupported
  deriving DecidableEq, Repr

inductive EquivalenceObligationStatus where
  | pendingProof
  | closedBySourceAnchor
  | rejected
  deriving DecidableEq, Repr

structure StatementEquivalenceContract where
  problem : ProblemId
  officialStatementTag : String
  adapterStatementTag : String
  returnLockStatus : ReturnLockStatus
  obligationStatus : EquivalenceObligationStatus
  adapterDecision : ImportDecision
  deriving DecidableEq, Repr

def canonicalStatementContract (p : ProblemId) : StatementEquivalenceContract :=
  let spec := canonicalSpec p
  {
    problem := p
    officialStatementTag := spec.statementTag
    adapterStatementTag := normalizeStatementText spec.statementTag
    returnLockStatus := ReturnLockStatus.locked
    obligationStatus := EquivalenceObligationStatus.pendingProof
    adapterDecision := ImportDecision.allowed
  }

def canonicalStatementContracts : List StatementEquivalenceContract :=
  [canonicalStatementContract ProblemId.pnp,
   canonicalStatementContract ProblemId.rh,
   canonicalStatementContract ProblemId.bsd,
   canonicalStatementContract ProblemId.hodge,
   canonicalStatementContract ProblemId.navierStokes,
   canonicalStatementContract ProblemId.yangMills,
   canonicalStatementContract ProblemId.poincare]

def contractShapeValid (c : StatementEquivalenceContract) : Prop :=
  c.returnLockStatus = ReturnLockStatus.locked /\
  c.adapterStatementTag = normalizeStatementText c.officialStatementTag /\
  c.problem = c.problem

theorem canonical_statement_contract_shape_valid (p : ProblemId) :
    contractShapeValid (canonicalStatementContract p) := by
  constructor
  · rfl
  constructor
  · rfl
  · rfl

theorem canonical_statement_contracts_length : canonicalStatementContracts.length = 7 := by
  rfl

theorem canonical_statement_contract_problem_alignment (p : ProblemId) :
    (canonicalStatementContract p).problem = p := by
  rfl

end CROOT
