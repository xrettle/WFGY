import CROOT.ClayTargets.Common

namespace CROOT

def yangMillsDomainCore : DomainCoreSignature :=
  {
    objectTag := "quantum-yang-mills-field-family"
    operationTag := "spectrum-gap-evaluation-map"
    invariantTag := "positive-mass-gap-obligation"
  }

def yangMillsTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.yangMills "official-clay-statement-boundary"

theorem yang_mills_target_problem :
    yangMillsTargetContract.problem = ProblemId.yangMills := by
  rfl

theorem yang_mills_target_shape_valid :
    targetContractShapeValid yangMillsTargetContract := by
  constructor <;> decide

end CROOT
