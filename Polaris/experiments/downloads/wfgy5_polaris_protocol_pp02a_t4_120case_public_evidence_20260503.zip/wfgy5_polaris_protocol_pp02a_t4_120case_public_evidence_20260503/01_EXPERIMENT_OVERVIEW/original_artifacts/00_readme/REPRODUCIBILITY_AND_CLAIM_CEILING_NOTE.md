# Reproducibility and Claim-Ceiling Note

Created at: 2026-05-02T13:50:11+00:00

This package contains a successful PP02A T4 120-case v5 API result.

The result is reproducible in the sense that the package includes:
- the Colab reproduction workflow used to run the experiment
- original result zip
- raw outputs
- parsed outputs
- judge rows
- case-level C/D signal table
- domain summary
- final score summary
- manifest
- hashes

Future reruns may not produce byte-identical results because API model behavior can change over time.

Correct interpretation:
```text
This is a preserved successful API run under the PP02A T4 structured C/D benchmark contract.
```

Incorrect interpretation:
```text
This permanently proves all future reruns will pass identically.
```
