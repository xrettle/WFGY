import CROOT.Kernels.K31_ProjectionEndpointLockMatrix

namespace CROOT

inductive ProblemProjectionLane where
  | statementContract
  | sourceField
  | manualTarget
  | manualPrototype
  | manualRefinement
  | generatedObligation
  | generatedCompletion
  | generatedPrototype
  | generatedRefinement
deriving DecidableEq, Repr

def laneProblemProjection : ProblemProjectionLane → List ProblemId
  | .statementContract => statementContractProblemProjection
  | .sourceField => sourceFieldProblemProjection
  | .manualTarget => manualTargetProblemProjection
  | .manualPrototype => manualPrototypeProblemProjection
  | .manualRefinement => manualRefinementProblemProjection
  | .generatedObligation => generatedObligationProblemProjection
  | .generatedCompletion => generatedCompletionLaneProblemProjection
  | .generatedPrototype => generatedPrototypeProblemProjection
  | .generatedRefinement => generatedRefinementProblemProjection

theorem lane_problem_projection_eq_canonical :
    ∀ lane, laneProblemProjection lane = canonicalProblemIds
  | .statementContract => statement_contract_problem_projection_eq_canonical
  | .sourceField => source_field_problem_projection_eq_canonical
  | .manualTarget => manual_target_problem_projection_eq_canonical
  | .manualPrototype => manual_prototype_problem_projection_eq_canonical
  | .manualRefinement => manual_refinement_problem_projection_eq_canonical
  | .generatedObligation => generated_obligation_problem_projection_eq_canonical
  | .generatedCompletion => generated_completion_lane_problem_projection_eq_canonical
  | .generatedPrototype => generated_prototype_problem_projection_eq_canonical
  | .generatedRefinement => generated_refinement_problem_projection_eq_canonical

theorem lane_problem_projection_length :
    ∀ lane, (laneProblemProjection lane).length = 7 := by
  intro lane
  calc
    (laneProblemProjection lane).length = canonicalProblemIds.length := by
      simpa [lane_problem_projection_eq_canonical lane]
    _ = 7 := canonical_problem_ids_length

theorem lane_problem_projection_nodup :
    ∀ lane, (laneProblemProjection lane).Nodup := by
  intro lane
  simpa [lane_problem_projection_eq_canonical lane] using canonical_problem_ids_nodup

theorem lane_problem_projection_head_lock :
    ∀ lane, (laneProblemProjection lane).head? = some ProblemId.pnp := by
  intro lane
  calc
    (laneProblemProjection lane).head? = canonicalProblemIds.head? := by
      simpa [lane_problem_projection_eq_canonical lane]
    _ = some ProblemId.pnp := by
      simp [canonicalProblemIds]

theorem lane_problem_projection_tail_lock :
    ∀ lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare := by
  intro lane
  calc
    (laneProblemProjection lane).getLast? = canonicalProblemIds.getLast? := by
      simpa [lane_problem_projection_eq_canonical lane]
    _ = some ProblemId.poincare := by
      simp [canonicalProblemIds]

structure K41UnifiedProblemProjectionKernel where
  laneEqCanonical : ∀ lane, laneProblemProjection lane = canonicalProblemIds
  laneCountSeven : ∀ lane, (laneProblemProjection lane).length = 7
  laneNodup : ∀ lane, (laneProblemProjection lane).Nodup
  laneHeadLock : ∀ lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  laneTailLock : ∀ lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare

def k41_unified_problem_projection_kernel : K41UnifiedProblemProjectionKernel :=
{
  laneEqCanonical := lane_problem_projection_eq_canonical,
  laneCountSeven := lane_problem_projection_length,
  laneNodup := lane_problem_projection_nodup,
  laneHeadLock := lane_problem_projection_head_lock,
  laneTailLock := lane_problem_projection_tail_lock
}

end CROOT
