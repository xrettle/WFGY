import CROOT.Core.ProblemSpec
import CROOT.ClayTargets.Registry
import CROOT.ClayTargets.PrototypeTheoremLane
import CROOT.ClayTargets.TheoremTermRefinement
import CROOT.Generators.SameRootProjection

namespace CROOT

def manualTargetProblemProjection : List ProblemId :=
  clayTargetRegistry.map (fun c => c.problem)

def manualPrototypeProblemProjection : List ProblemId :=
  fullPrototypeLanes.map (fun lane => lane.problem)

def manualRefinementProblemProjection : List ProblemId :=
  fullRefinementLanes.map (fun lane => lane.problem)

def generatedPrototypeProblemProjection : List ProblemId :=
  generatedFullPrototypeLanes.map (fun lane => lane.problem)

def generatedRefinementProblemProjection : List ProblemId :=
  generatedFullRefinementLanes.map (fun lane => lane.problem)

theorem manual_target_problem_projection_eq_canonical :
    manualTargetProblemProjection = canonicalProblemIds := by
  rfl

theorem manual_prototype_problem_projection_eq_canonical :
    manualPrototypeProblemProjection = canonicalProblemIds := by
  rfl

theorem manual_refinement_problem_projection_eq_canonical :
    manualRefinementProblemProjection = canonicalProblemIds := by
  simpa [manualRefinementProblemProjection, fullRefinementLanes,
    manualPrototypeProblemProjection, refinementLaneFromPrototype]
    using manual_prototype_problem_projection_eq_canonical

theorem rooted_specs_problem_projection_eq_canonical :
    rootedSpecs.map (fun rp => rp.spec.id) = canonicalProblemIds := by
  simp [rootedSpecs, rootedSpec, canonicalProblemIds, canonicalSpec]

theorem generated_prototype_problem_projection_eq_canonical :
    generatedPrototypeProblemProjection = canonicalProblemIds := by
  simpa [generatedPrototypeProblemProjection, generatedFullPrototypeLanes,
    generatedPrototypeLaneFromRoot]
    using rooted_specs_problem_projection_eq_canonical

theorem generated_refinement_problem_projection_eq_canonical :
    generatedRefinementProblemProjection = canonicalProblemIds := by
  simpa [generatedRefinementProblemProjection, generatedFullRefinementLanes,
    generatedRefinementLaneFromRoot]
    using rooted_specs_problem_projection_eq_canonical

theorem manual_target_problem_projection_nodup :
    manualTargetProblemProjection.Nodup := by
  simpa [manual_target_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem manual_prototype_problem_projection_nodup :
    manualPrototypeProblemProjection.Nodup := by
  simpa [manual_prototype_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem manual_refinement_problem_projection_nodup :
    manualRefinementProblemProjection.Nodup := by
  simpa [manual_refinement_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem generated_prototype_problem_projection_nodup :
    generatedPrototypeProblemProjection.Nodup := by
  simpa [generated_prototype_problem_projection_eq_canonical] using canonical_problem_ids_nodup

theorem generated_refinement_problem_projection_nodup :
    generatedRefinementProblemProjection.Nodup := by
  simpa [generated_refinement_problem_projection_eq_canonical] using canonical_problem_ids_nodup

structure K16RegistryProjectionClosure where
  canonicalCount : canonicalProblemIds.length = 7
  manualTargetEqCanonical : manualTargetProblemProjection = canonicalProblemIds
  manualPrototypeEqCanonical : manualPrototypeProblemProjection = canonicalProblemIds
  manualRefinementEqCanonical : manualRefinementProblemProjection = canonicalProblemIds
  generatedPrototypeEqCanonical : generatedPrototypeProblemProjection = canonicalProblemIds
  generatedRefinementEqCanonical : generatedRefinementProblemProjection = canonicalProblemIds
  manualTargetNodup : manualTargetProblemProjection.Nodup
  manualPrototypeNodup : manualPrototypeProblemProjection.Nodup
  manualRefinementNodup : manualRefinementProblemProjection.Nodup
  generatedPrototypeNodup : generatedPrototypeProblemProjection.Nodup
  generatedRefinementNodup : generatedRefinementProblemProjection.Nodup

theorem k16_registry_projection_closure : K16RegistryProjectionClosure :=
{
  canonicalCount := canonical_problem_ids_length,
  manualTargetEqCanonical := manual_target_problem_projection_eq_canonical,
  manualPrototypeEqCanonical := manual_prototype_problem_projection_eq_canonical,
  manualRefinementEqCanonical := manual_refinement_problem_projection_eq_canonical,
  generatedPrototypeEqCanonical := generated_prototype_problem_projection_eq_canonical,
  generatedRefinementEqCanonical := generated_refinement_problem_projection_eq_canonical,
  manualTargetNodup := manual_target_problem_projection_nodup,
  manualPrototypeNodup := manual_prototype_problem_projection_nodup,
  manualRefinementNodup := manual_refinement_problem_projection_nodup,
  generatedPrototypeNodup := generated_prototype_problem_projection_nodup,
  generatedRefinementNodup := generated_refinement_problem_projection_nodup
}

end CROOT
