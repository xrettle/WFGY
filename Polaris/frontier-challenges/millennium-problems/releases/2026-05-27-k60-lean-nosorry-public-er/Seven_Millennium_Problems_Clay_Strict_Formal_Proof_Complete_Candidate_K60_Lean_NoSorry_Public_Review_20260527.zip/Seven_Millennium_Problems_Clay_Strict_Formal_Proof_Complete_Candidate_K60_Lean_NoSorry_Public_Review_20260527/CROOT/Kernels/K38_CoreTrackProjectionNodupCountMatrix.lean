import CROOT.Kernels.K37_GeneratedTrackProjectionNodupCountMatrix

namespace CROOT

theorem source_field_track_projection_length :
    sourceFieldTrackProjection.length = 7 := by
  calc
    sourceFieldTrackProjection.length = canonicalTrackProjection.length := by
      simpa [source_field_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem manual_track_projection_length :
    manualTrackProjection.length = 7 := by
  calc
    manualTrackProjection.length = canonicalTrackProjection.length := by
      simpa [manual_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem generated_track_projection_length :
    generatedTrackProjection.length = 7 := by
  calc
    generatedTrackProjection.length = canonicalTrackProjection.length := by
      simpa [generated_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem source_field_track_projection_nodup :
    sourceFieldTrackProjection.Nodup := by
  simpa [source_field_track_projection_eq_canonical] using canonical_track_projection_nodup

theorem manual_track_projection_nodup :
    manualTrackProjection.Nodup := by
  simpa [manual_track_projection_eq_canonical] using canonical_track_projection_nodup

theorem generated_track_projection_nodup :
    generatedTrackProjection.Nodup := by
  simpa [generated_track_projection_eq_canonical] using canonical_track_projection_nodup

structure K38CoreTrackProjectionNodupCountMatrix where
  sourceFieldCount : sourceFieldTrackProjection.length = 7
  manualCount : manualTrackProjection.length = 7
  generatedCount : generatedTrackProjection.length = 7
  sourceFieldNodup : sourceFieldTrackProjection.Nodup
  manualNodup : manualTrackProjection.Nodup
  generatedNodup : generatedTrackProjection.Nodup

def k38_core_track_projection_nodup_count_matrix :
    K38CoreTrackProjectionNodupCountMatrix :=
{
  sourceFieldCount := source_field_track_projection_length,
  manualCount := manual_track_projection_length,
  generatedCount := generated_track_projection_length,
  sourceFieldNodup := source_field_track_projection_nodup,
  manualNodup := manual_track_projection_nodup,
  generatedNodup := generated_track_projection_nodup
}

end CROOT
