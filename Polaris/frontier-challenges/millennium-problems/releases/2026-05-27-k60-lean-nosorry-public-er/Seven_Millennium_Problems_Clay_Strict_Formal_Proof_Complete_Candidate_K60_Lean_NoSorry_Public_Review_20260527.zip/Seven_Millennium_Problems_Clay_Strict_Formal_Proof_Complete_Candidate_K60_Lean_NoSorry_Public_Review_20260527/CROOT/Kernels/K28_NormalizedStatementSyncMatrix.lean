import CROOT.Kernels.K27_StatementProjectionSyncMatrix

namespace CROOT

def rootedNormalizedStatementProjection : List String :=
  rootedStatementProjection.map normalizeStatementText

def obligationNormalizedStatementProjection : List String :=
  generatedObligationStatementProjection.map normalizeStatementText

theorem rooted_normalized_statement_eq_adapter_contracts :
    rootedNormalizedStatementProjection = adapterTagProjectionFromContracts := by
  calc
    rootedNormalizedStatementProjection = statementTagProjectionFromContracts.map normalizeStatementText := by
      simp [rootedNormalizedStatementProjection, rooted_statement_projection_eq_contracts]
    _ = adapterTagProjectionFromContracts := by
      symm
      exact adapter_tag_projection_contracts_eq_normalized_official

theorem rooted_normalized_statement_eq_adapter_specs :
    rootedNormalizedStatementProjection = adapterTagProjectionFromSpecs := by
  calc
    rootedNormalizedStatementProjection = statementTagProjectionFromSpecs.map normalizeStatementText := by
      simp [rootedNormalizedStatementProjection, rooted_statement_projection_eq_specs]
    _ = adapterTagProjectionFromSpecs := by
      rfl

theorem obligation_normalized_statement_eq_adapter_contracts :
    obligationNormalizedStatementProjection = adapterTagProjectionFromContracts := by
  calc
    obligationNormalizedStatementProjection = statementTagProjectionFromContracts.map normalizeStatementText := by
      simp [obligationNormalizedStatementProjection, generated_obligation_statement_projection_eq_contracts]
    _ = adapterTagProjectionFromContracts := by
      symm
      exact adapter_tag_projection_contracts_eq_normalized_official

theorem rooted_obligation_normalized_statement_sync :
    rootedNormalizedStatementProjection = obligationNormalizedStatementProjection := by
  calc
    rootedNormalizedStatementProjection = adapterTagProjectionFromContracts :=
      rooted_normalized_statement_eq_adapter_contracts
    _ = obligationNormalizedStatementProjection := by
      symm
      exact obligation_normalized_statement_eq_adapter_contracts

structure K28NormalizedStatementSyncMatrix where
  rootedToAdapterContracts : rootedNormalizedStatementProjection = adapterTagProjectionFromContracts
  rootedToAdapterSpecs : rootedNormalizedStatementProjection = adapterTagProjectionFromSpecs
  obligationsToAdapterContracts : obligationNormalizedStatementProjection = adapterTagProjectionFromContracts
  rootedObligationsNormalizedSync :
    rootedNormalizedStatementProjection = obligationNormalizedStatementProjection

def k28_normalized_statement_sync_matrix : K28NormalizedStatementSyncMatrix :=
{
  rootedToAdapterContracts := rooted_normalized_statement_eq_adapter_contracts,
  rootedToAdapterSpecs := rooted_normalized_statement_eq_adapter_specs,
  obligationsToAdapterContracts := obligation_normalized_statement_eq_adapter_contracts,
  rootedObligationsNormalizedSync := rooted_obligation_normalized_statement_sync
}

end CROOT
