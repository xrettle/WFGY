# Public Sanitization Report

Removed from the public package:
- `01_COLAB_FINAL/`
- `.ipynb` notebook
- notebook readme
- nested evidence ZIP duplicates
- ramp-up evidence ZIPs
- sandbox implementation/reference ZIPs
- original manifests that referenced removed files
- config files and prompt/case files that could expose non-public internals

Retained:
- final result and claim-ceiling notes
- final 216-call all-pass table
- final evidence summaries
- parser records
- raw outputs
- scorer and transport traces
- final verdict
- regenerated public hash manifest
