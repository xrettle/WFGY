import CROOT.ClayTargets.PvsNP
import CROOT.ClayTargets.RiemannHypothesis
import CROOT.ClayTargets.BSD
import CROOT.ClayTargets.Hodge
import CROOT.ClayTargets.NavierStokes
import CROOT.ClayTargets.YangMills
import CROOT.ClayTargets.Poincare
import CROOT.ClayTargets.CompletionLane

namespace CROOT

inductive PrototypeLaneStatus where
  | contractClosed
  | dependencyClosed
  | obligationClosed
  | theoremTermScaffoldClosed
  deriving DecidableEq, Repr

structure PrototypeTheoremLane where
  problem : ProblemId
  target : FormalizationTargetContract
  completionLane : ProblemCompletionLane
  statusTrace : List PrototypeLaneStatus
  deriving DecidableEq, Repr

def canonicalPrototypeStatuses : List PrototypeLaneStatus :=
  [PrototypeLaneStatus.contractClosed,
   PrototypeLaneStatus.dependencyClosed,
   PrototypeLaneStatus.obligationClosed,
   PrototypeLaneStatus.theoremTermScaffoldClosed]

def pnpPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.pnp,
    target := pnpTargetContract,
    completionLane := completionLaneOf ProblemId.pnp,
    statusTrace := canonicalPrototypeStatuses
  }

def rhPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.rh,
    target := rhTargetContract,
    completionLane := completionLaneOf ProblemId.rh,
    statusTrace := canonicalPrototypeStatuses
  }

def bsdPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.bsd,
    target := bsdTargetContract,
    completionLane := completionLaneOf ProblemId.bsd,
    statusTrace := canonicalPrototypeStatuses
  }

def hodgePrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.hodge,
    target := hodgeTargetContract,
    completionLane := completionLaneOf ProblemId.hodge,
    statusTrace := canonicalPrototypeStatuses
  }

def nsPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.navierStokes,
    target := navierStokesTargetContract,
    completionLane := completionLaneOf ProblemId.navierStokes,
    statusTrace := canonicalPrototypeStatuses
  }

def ymPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.yangMills,
    target := yangMillsTargetContract,
    completionLane := completionLaneOf ProblemId.yangMills,
    statusTrace := canonicalPrototypeStatuses
  }

def pcPrototypeTheoremLane : PrototypeTheoremLane :=
  {
    problem := ProblemId.poincare,
    target := poincareTargetContract,
    completionLane := completionLaneOf ProblemId.poincare,
    statusTrace := canonicalPrototypeStatuses
  }

def prototypePair : List PrototypeTheoremLane :=
  [pnpPrototypeTheoremLane, rhPrototypeTheoremLane]

def fullPrototypeLanes : List PrototypeTheoremLane :=
  [pnpPrototypeTheoremLane,
   rhPrototypeTheoremLane,
   bsdPrototypeTheoremLane,
   hodgePrototypeTheoremLane,
   nsPrototypeTheoremLane,
   ymPrototypeTheoremLane,
   pcPrototypeTheoremLane]

def prototypeLaneShapeValid (lane : PrototypeTheoremLane) : Prop :=
  lane.statusTrace.length = 4 /\
  lane.statusTrace.Nodup /\
  lane.completionLane.milestones.length = 5

theorem canonical_prototype_statuses_length : canonicalPrototypeStatuses.length = 4 := by
  rfl

theorem canonical_prototype_statuses_nodup : canonicalPrototypeStatuses.Nodup := by
  decide

theorem pnp_prototype_problem :
    pnpPrototypeTheoremLane.problem = ProblemId.pnp := by
  rfl

theorem rh_prototype_problem :
    rhPrototypeTheoremLane.problem = ProblemId.rh := by
  rfl

theorem pnp_prototype_shape_valid :
    prototypeLaneShapeValid pnpPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem rh_prototype_shape_valid :
    prototypeLaneShapeValid rhPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem bsd_prototype_shape_valid :
    prototypeLaneShapeValid bsdPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem hodge_prototype_shape_valid :
    prototypeLaneShapeValid hodgePrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem ns_prototype_shape_valid :
    prototypeLaneShapeValid nsPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem ym_prototype_shape_valid :
    prototypeLaneShapeValid ymPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem pc_prototype_shape_valid :
    prototypeLaneShapeValid pcPrototypeTheoremLane := by
  constructor
  · exact canonical_prototype_statuses_length
  constructor
  · exact canonical_prototype_statuses_nodup
  · exact canonical_milestones_length

theorem prototype_pair_length : prototypePair.length = 2 := by
  rfl

theorem full_prototype_lanes_length : fullPrototypeLanes.length = 7 := by
  rfl

end CROOT
