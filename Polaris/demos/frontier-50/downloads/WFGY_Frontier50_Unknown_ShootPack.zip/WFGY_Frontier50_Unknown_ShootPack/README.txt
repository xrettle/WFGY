WFGY FRONTIER-50 UNKNOWN SHOOT PACK

This is the public sample pack for WFGY 5.0 — Fifth-Dimension Engine.

Purpose:
- Provide 50 non-Millennium, century-level unknown frontier problems.
- Shoot each problem into a topic-specific WFGY route-answer candidate.
- Provide English materials for users, reviewers, and AI-assisted inspection.

Main command:
shoot + 50 century-level problems

Scope:
- These are answer candidates / route answers.
- They are presented as the answer direction produced by WFGY-style route generation.
- This pack does not claim final proof closure for all 50 problems.
- Proof, empirical validation, or formal closure remains a later step.
