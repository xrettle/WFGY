# Public Claim Boundary

Branch: PP02C

This package supports public inspection of experiment artifacts.

Allowed public claims:
- Raw outputs are preserved where available.
- Parsed outputs are preserved where available.
- Verdict and metric tables are preserved where available.
- Execution notebooks are excluded from the public package.
- Unreleased core mathematical source files are excluded from the public package.
- SHA256 manifests are regenerated for this public package.

Not claimed by this package:
- This package does not include the full implementation source.
- This package does not include unreleased core mathematical source files.
- This package does not embed execution notebooks.
