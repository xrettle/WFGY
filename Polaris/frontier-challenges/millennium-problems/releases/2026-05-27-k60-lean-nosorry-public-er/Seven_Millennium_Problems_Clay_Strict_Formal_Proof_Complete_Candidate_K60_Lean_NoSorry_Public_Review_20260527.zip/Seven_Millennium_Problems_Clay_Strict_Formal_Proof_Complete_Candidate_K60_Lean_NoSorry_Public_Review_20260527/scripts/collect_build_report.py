#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, re

ROOT = Path(__file__).resolve().parents[1]
logs = ROOT / "build_logs"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def read_text(name: str):
    p = logs / name
    return p.read_text(encoding="utf-8", errors="ignore").strip() if p.exists() else None

report = {
    "has_build_logs": logs.exists(),
    "failed_at": read_text("FAILED_AT.txt"),
    "stage1_smoke_returncode": read_text("stage1_smoke.returncode"),
    "stage2_seal_returncode": read_text("stage2_seal.returncode"),
    "stage3_buildfirst_returncode": read_text("stage3_buildfirst.returncode"),
    "stage4_audit_returncode": read_text("stage4_audit.returncode"),
    "lake_build_returncode": read_text("lake_build.returncode"),
    "no_sorry_scan_returncode": read_text("no_sorry_scan.returncode"),
    "machine_check_step1_certificate_present": (logs / "MACHINE_CHECK_STEP1_CERTIFICATE.txt").exists(),
    "closed_objects": [
        "framework_seven_track_seal",
        "buildFirstSeal",
        "proof_object_audit_pass",
        "k12_bundle_verified",
        "k12_architecture_audit_pass",
        "k13_same_root_unification",
        "k14_full_prototype_lane_symmetry",
        "k15_theorem_term_refinement_readiness",
        "k16_registry_projection_closure",
        "k17_target_contract_closure",
        "k18_statement_equivalence_hard_lock",
        "k19_adapter_driven_contract_closure",
        "k20_statement_tag_projection_closure",
        "k21_source_field_first_principle_alignment",
        "k22_root_token_projection_closure",
        "k23_statement_pair_projection_closure",
        "k24_obligation_projection_closure",
        "k25_completion_lane_projection_closure",
        "k26_shared_projection_sync_matrix",
        "k27_statement_projection_sync_matrix",
        "k28_normalized_statement_sync_matrix",
        "k29_control_surface_sync_matrix",
        "k30_projection_nodup_count_matrix",
        "k31_projection_endpoint_lock_matrix",
        "k32_domain_projection_closure",
        "k33_track_projection_closure",
        "k34_track_endpoint_lock_matrix",
        "k35_track_projection_sync_matrix",
        "k36_generated_track_endpoint_lock_matrix",
        "k37_generated_track_projection_nodup_count_matrix",
        "k38_core_track_projection_nodup_count_matrix",
        "k39_track_projection_global_sync_matrix",
        "k40_unified_track_projection_kernel",
        "k41_unified_problem_projection_kernel",
        "k42_unified_statement_projection_kernel",
        "k43_unified_domain_projection_kernel",
        "k44_unified_control_surface_kernel",
        "k45_unified_seven_count_kernel",
        "k46_unified_endpoint_lock_kernel",
        "k47_unified_projection_anchor_kernel",
        "k48_unified_nodup_endpoint_kernel",
        "k49_shared_lane_proof_skeleton",
        "k50_unified_lane_runtime_contract",
        "k51_unified_fastpath_certificate",
        "k52_unified_invariant_pack",
        "k53_unified_invariant_count_bridge",
        "k54_unified_creator_fastpath_core",
        "k55_unified_creator_audit_portal",
        "k56_unified_dual_projection_bridge",
        "k57_unified_audit_fastpath_seal",
        "k58_unified_audit_control_seal",
        "k59_unified_creator_hardening_seal",
        "k60_unified_creator_acceleration_portal",
        "creator_grade_bundle_verified",
        "creator_grade_audit_pass"
    ],
    "forbidden_tokens": [],
    "files": [],
}

for path in ROOT.rglob("*.lean"):
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_block = False
    for i, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith("/-"):
            in_block = True
        if in_block:
            if "-/" in s:
                in_block = False
            continue
        if s.startswith("--"):
            continue
        if re.search(r"\b(sorry|admit|axiom|constant)\b", line):
            report["forbidden_tokens"].append({
                "file": str(path.relative_to(ROOT)),
                "line": i,
                "content": line.strip()
            })

for path in sorted(ROOT.rglob("*")):
    if path.is_file() and ".lake" not in path.parts:
        report["files"].append({
            "path": str(path.relative_to(ROOT)),
            "size": path.stat().st_size,
            "sha256": sha256(path)
        })

out = ROOT / "BUILD_REPORT.json"
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
