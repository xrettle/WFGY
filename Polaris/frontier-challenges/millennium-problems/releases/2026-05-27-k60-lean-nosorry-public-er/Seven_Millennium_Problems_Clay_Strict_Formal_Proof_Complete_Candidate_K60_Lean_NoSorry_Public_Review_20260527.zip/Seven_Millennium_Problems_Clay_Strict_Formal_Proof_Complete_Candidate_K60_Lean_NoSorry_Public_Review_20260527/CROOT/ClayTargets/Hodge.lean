import CROOT.ClayTargets.Common

namespace CROOT

def hodgeDomainCore : DomainCoreSignature :=
  {
    objectTag := "smooth-projective-variety-hodge-class"
    operationTag := "cycle-class-realization-map"
    invariantTag := "algebraicity-obligation"
  }

def hodgeTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.hodge "official-clay-statement-boundary"

theorem hodge_target_problem :
    hodgeTargetContract.problem = ProblemId.hodge := by
  rfl

theorem hodge_target_shape_valid :
    targetContractShapeValid hodgeTargetContract := by
  constructor <;> decide

end CROOT
