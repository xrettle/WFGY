# PP02D-B R9 API-only FINAL 216 Evidence

Run ID: PP02D_B_R9_FINAL_216_20260504T153340Z

This zip is evidence sediment, not proof or closure.

Required GREEN:
- transport pass 216/216
- parse pass 216/216
- certificate exact 216/216
- arena valid-set 54/54
- valid recall 108/108
- invalid rejection 108/108
- parser rescue 0
- semantic fallback 0

Verdict:
```json
{
  "run_id": "PP02D_B_R9_FINAL_216_20260504T153340Z",
  "run_type": "API_ONLY_FINAL_216",
  "artifact_role": "API_EVIDENCE_ZIP_NOT_PROOF",
  "model": "gpt-5.2",
  "api_calls": "216/216",
  "transport_pass": "216/216",
  "transport_fail": 0,
  "parse_pass": "216/216",
  "parse_fail": 0,
  "parser_rescue": 0,
  "semantic_fallback_count": 0,
  "certificate_exact": "216/216",
  "arena_valid_set_match": "54/54",
  "valid_recall": "108/108",
  "invalid_rejection": "108/108",
  "run_disposition": "GREEN",
  "claim_ceiling": "API_216_EVIDENCE_ONLY_NOT_GLOBAL_PROOF"
}
```
