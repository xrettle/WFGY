# Redaction and Safety Note

This package was created from an internal handoff archive and then aggressively sanitized for public release.

## Removed categories

The following categories were excluded:

1. All Colab notebooks and executable notebooks.
2. All raw result zip files.
3. All prompt manifests.
4. All raw model outputs.
5. All parsed output traces.
6. All case payloads and case-level payload records.
7. All judge rows and scorer-level rows.
8. All evaluator implementation details.
9. All internal case identifiers, unit identifiers, and detailed failure-surface records.
10. Any file that could allow a reader to reconstruct prompt generation, evaluator behavior, or private scoring contracts.

## Included categories

Only aggregate metrics, stage summaries, public claim boundaries, and public package hashes are included.

## Release policy

This package is safe for public sharing as a result summary. It is not an open implementation bundle.
