import CROOT.Kernels.K46_UnifiedEndpointLockKernel

namespace CROOT

structure K47UnifiedProjectionAnchorKernel where
  trackLaneEqCanonical :
    ∀ lane, laneTrackProjection lane = canonicalTrackProjection
  problemLaneEqCanonical :
    ∀ lane, laneProblemProjection lane = canonicalProblemIds
  statementLaneEqContracts :
    ∀ lane, laneStatementProjection lane = statementTagProjectionFromContracts
  normalizedStatementLaneEqAdapterContracts :
    ∀ lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  domainLaneEqCanonical :
    ∀ lane, laneDomainProjection lane = canonicalDomainTagProjection
  returnLockLaneAllLocked :
    ∀ lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionLaneAllAllowed :
    ∀ lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryLaneAllOfficial :
    ∀ lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k47_unified_projection_anchor_kernel : K47UnifiedProjectionAnchorKernel :=
{
  trackLaneEqCanonical := lane_track_projection_eq_canonical,
  problemLaneEqCanonical := lane_problem_projection_eq_canonical,
  statementLaneEqContracts := lane_statement_projection_eq_contracts,
  normalizedStatementLaneEqAdapterContracts :=
    lane_normalized_statement_projection_eq_adapter_contracts,
  domainLaneEqCanonical := lane_domain_projection_eq_canonical,
  returnLockLaneAllLocked := lane_return_lock_all_locked,
  decisionLaneAllAllowed := lane_decision_all_allowed,
  boundaryLaneAllOfficial := lane_boundary_all_official,
  debtAllOpen := generated_obligation_debt_all_open
}

end CROOT
