# PP02A T4 120 Cases Universe Champagne Evidence Package

Created at: 2026-05-02T13:46:04+00:00

## 1. Final verdict

The PP02A T4 120 cases v5 API run passed the Universe Champagne standard defined for this branch.

Final verdict:

```text
SEAL_PASS
```

This is a real API-result evidence package, not only a sandbox projection.

## 2. Scope

This run used:

| Item | Value |
|---|---:|
| Total prompts | 240 |
| C/D case pairs | 120 |
| Domains | 6 |
| API error count | 0 |
| Parser failure count | 0 |
| Parse success rate | 1.0 |
| Integrated Delta CD | 0.4517 |
| Total weak rows | 0 |
| Seal domain count | 6 / 6 |
| Dominant or better domain count | 6 / 6 |
| Release or better domain count | 6 / 6 |
| T4 system score | 100.0 |
| OVER100 internal score | 125.0 |

## 3. Gates

| Gate | Result |
|---|---|
| Validity gate | True |
| Release gate | True |
| Dominant gate | True |
| Seal gate | True |

All final gates passed.

## 4. Domain summary

| domain_id   | domain_name                                 | domain_kind            |   case_count |   Delta_CD |   weak_rows |   true_weak_rows |   negative_rows |   min_delta |   expected_failure_match_proxy | domain_verdict   |
|:------------|:--------------------------------------------|:-----------------------|-------------:|-----------:|------------:|-----------------:|----------------:|------------:|-------------------------------:|:-----------------|
| T4-A        | Agent/Coding Hybrid Passed Module           | passed_module_api_seal |           16 |     0.4449 |           0 |                0 |               0 |       0.406 |                              1 | SEAL_PASS        |
| T4-CODEX    | Coding Extended Seal Domain                 | new_seed_domain        |           22 |     0.4441 |           0 |                0 |               0 |       0.335 |                              1 | SEAL_PASS        |
| T4-CREATIVE | Creative Constraint Seal Domain             | new_seed_domain        |           18 |     0.4728 |           0 |                0 |               0 |       0.378 |                              1 | SEAL_PASS        |
| T4-MATH     | Math Seal Domain                            | new_seed_domain        |           20 |     0.4694 |           0 |                0 |               0 |       0.388 |                              1 | SEAL_PASS        |
| T4-MULTI    | Multimodal OCR Visual Grounding Seal Domain | new_seed_domain        |           22 |     0.4268 |           0 |                0 |               0 |       0.322 |                              1 | SEAL_PASS        |
| T4-X        | Cross Domain Integration Gate               | new_seed_domain        |           22 |     0.4524 |           0 |                0 |               0 |       0.315 |                              1 | SEAL_PASS        |

## 5. Lowest case signals

The lowest case signal is still far above the weak-row boundary.

| domain_id   | case_id      | family                  | case_type   |   C_score |   D_score |   C_minus_D | C_parse_method   | D_parse_method   | verdict   |
|:------------|:-------------|:------------------------|:------------|----------:|----------:|------------:|:-----------------|:-----------------|:----------|
| T4-X        | X-020        | RawOutputPreservation   | cross       |     0.765 |     0.45  |       0.315 | json             | json             | PASS      |
| T4-MULTI    | MULTI-015    | MapLegend               | multi       |     0.782 |     0.46  |       0.322 | json             | json             | PASS      |
| T4-MULTI    | MULTI-010    | ColorSeriesMapping      | multi       |     0.782 |     0.45  |       0.332 | json             | json             | PASS      |
| T4-CODEX    | CODEX-010    | ConfigVsCodePath        | code        |     0.72  |     0.385 |       0.335 | json             | json             | PASS      |
| T4-MULTI    | MULTI-012    | HandwrittenText         | multi       |     0.816 |     0.47  |       0.346 | json             | json             | PASS      |
| T4-MULTI    | MULTI-022    | ImageCaptionConflict    | multi       |     0.782 |     0.425 |       0.357 | json             | json             | PASS      |
| T4-CREATIVE | CREATIVE-009 | POVConsistency          | creative    |     0.858 |     0.48  |       0.378 | json             | json             | PASS      |
| T4-MULTI    | MULTI-020    | TableHeaderAmbiguity    | multi       |     0.874 |     0.49  |       0.384 | json             | json             | PASS      |
| T4-CODEX    | CODEX-013    | SerializationBoundary   | code        |     0.811 |     0.425 |       0.386 | json             | json             | PASS      |
| T4-CODEX    | CODEX-006    | ForbiddenRegion         | code        |     0.811 |     0.425 |       0.386 | json             | json             | PASS      |
| T4-CODEX    | CODEX-001    | MultiFileCausality      | code        |     0.857 |     0.47  |       0.387 | json             | json             | PASS      |
| T4-MATH     | MATH-008     | LimitBoundary           | math        |     0.858 |     0.47  |       0.388 | json             | json             | PASS      |
| T4-X        | X-019        | FailureOriginAccounting | cross       |     0.811 |     0.415 |       0.396 | json             | json             | PASS      |
| T4-X        | X-013        | ParserLedgerIntegrity   | cross       |     0.811 |     0.415 |       0.396 | json             | json             | PASS      |
| T4-MATH     | MATH-013     | InequalityDirection     | math        |     0.858 |     0.46  |       0.398 | json             | json             | PASS      |
| T4-MULTI    | MULTI-019    | ScreenshotUIState       | multi       |     0.862 |     0.46  |       0.402 | json             | json             | PASS      |
| T4-MULTI    | MULTI-014    | DiagramArrowDirection   | multi       |     0.862 |     0.46  |       0.402 | json             | json             | PASS      |
| T4-MULTI    | MULTI-016    | BeforeAfterPanel        | multi       |     0.862 |     0.46  |       0.402 | json             | json             | PASS      |
| T4-MULTI    | MULTI-017    | MultiObjectCounting     | multi       |     0.862 |     0.46  |       0.402 | json             | json             | PASS      |
| T4-MULTI    | MULTI-018    | VisualNegation          | multi       |     0.862 |     0.46  |       0.402 | json             | json             | PASS      |

## 6. What the experiment proves

This experiment shows that, under the PP02A T4 structured C/D evaluation design, the model passed a 120-case, 240-prompt, six-domain API run with:

```text
api_error_count = 0
parser_fail_count = 0
parse_success_rate = 1.0
total_weak_rows = 0
seal_domain_count = 6 / 6
final_verdict = SEAL_PASS
```

It verifies that this T4 configuration can process structured domain contracts, produce parseable JSON outputs, maintain C/D separation, and pass the integrated domain gates for this benchmark package.

## 7. What should not be claimed

This result must not be overstated.

Do not claim:
- universal small model superiority
- all AI tasks solved
- full native image understanding benchmark
- all future domains completed
- permanent or universal proof beyond this experiment scope

Safe claim:
```text
PP02A T4 120-case API run reached SEAL_PASS:
240 prompts, 120 C/D case pairs, 6 domains, 0 API errors, 0 parser failures, parse success rate 1.0, 0 weak rows, 6/6 domains sealed, integrated Delta_CD = 0.4517.
```

## 8. Reproducibility contents

This package includes:

| Folder | Content |
|---|---|
| 01_colab_notebook | The Colab reproduction workflow used to run the API candidate |
| 02_final_api_results | The original result zip and extracted result files |
| 03_parsed_tables | Domain and case-level CSV summaries |
| 04_hashes_and_manifest | Hashes, package manifest, and development package if available |
| 05_blackfan_audit | Strict self-audit |
| 06_previous_near_pass_reference | Previous v4 near-pass reference if available |

## 9. Main artifacts and SHA256

```json
{
  "colab_notebook": {
    "internal_execution_notebook_excluded_from_public_release": "664200e233229e47024e193acc8e8def549bfdd34bb01f2cb19601a0f20a3ff9"
  },
  "final_result_zip": {
    "PP02A_T4_120_CASES_V5_LEGENDGROUNDING_LOCK_API_CANDIDATE_RESULTS.zip": "1dd1a4e1d0032b5bb7a4449edb89638999331500e183fc24fd78e3055eacc34a"
  },
  "development_package": {
    "PP02A_T4_120_CASES_V5_LEGENDGROUNDING_LOCK_PACKAGE.zip": "cd3bd9e4352e51884be769970857799ded0d1c533dd5a4732e3ecb2fabf4854d"
  },
  "previous_near_pass_reference": {
    "PP02A_T4_120_CASES_V4_CODEX_FLOOR_AMPLIFIER_API_CANDIDATE_RESULTS.zip": "fed4ea9f21ca74e2dd3523f46e87e64370392c592e3160962556c0e8ce39a5d8"
  }
}
```

## 10. Final statement

Under the PP02A T4 120-case benchmark contract used in this branch, the final v5 run passes the Universe Champagne standard.

The correct final label is:

```text
PP02A T4 120 Cases v5 · Universe Champagne SEAL_PASS
```
