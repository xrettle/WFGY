import CROOT.Kernels.K39_TrackProjectionGlobalSyncMatrix

namespace CROOT

inductive TrackProjectionLane where
  | sourceField
  | manual
  | generated
  | obligation
  | completion
  | prototype
  | refinement
deriving DecidableEq, Repr

def laneTrackProjection : TrackProjectionLane → List Track
  | .sourceField => sourceFieldTrackProjection
  | .manual => manualTrackProjection
  | .generated => generatedTrackProjection
  | .obligation => generatedObligationTrackProjection
  | .completion => generatedCompletionTrackProjection
  | .prototype => generatedPrototypeTrackProjection
  | .refinement => generatedRefinementTrackProjection

theorem lane_track_projection_eq_canonical :
    ∀ lane, laneTrackProjection lane = canonicalTrackProjection
  | .sourceField => source_field_track_projection_eq_canonical
  | .manual => manual_track_projection_eq_canonical
  | .generated => generated_track_projection_eq_canonical
  | .obligation => generated_obligation_track_projection_eq_canonical
  | .completion => generated_completion_track_projection_eq_canonical
  | .prototype => generated_prototype_track_projection_eq_canonical
  | .refinement => generated_refinement_track_projection_eq_canonical

theorem lane_track_projection_length :
    ∀ lane, (laneTrackProjection lane).length = 7 := by
  intro lane
  calc
    (laneTrackProjection lane).length = canonicalTrackProjection.length := by
      simpa [lane_track_projection_eq_canonical lane]
    _ = 7 := canonical_track_projection_length

theorem lane_track_projection_nodup :
    ∀ lane, (laneTrackProjection lane).Nodup := by
  intro lane
  simpa [lane_track_projection_eq_canonical lane] using canonical_track_projection_nodup

theorem lane_track_projection_head_lock :
    ∀ lane, (laneTrackProjection lane).head? = some Track.PNP := by
  intro lane
  calc
    (laneTrackProjection lane).head? = canonicalTrackProjection.head? := by
      simpa [lane_track_projection_eq_canonical lane]
    _ = some Track.PNP := canonical_track_projection_head_lock

theorem lane_track_projection_tail_lock :
    ∀ lane, (laneTrackProjection lane).getLast? = some Track.PC := by
  intro lane
  calc
    (laneTrackProjection lane).getLast? = canonicalTrackProjection.getLast? := by
      simpa [lane_track_projection_eq_canonical lane]
    _ = some Track.PC := canonical_track_projection_tail_lock

structure K40UnifiedTrackProjectionKernel where
  laneEqCanonical : ∀ lane, laneTrackProjection lane = canonicalTrackProjection
  laneCountSeven : ∀ lane, (laneTrackProjection lane).length = 7
  laneNodup : ∀ lane, (laneTrackProjection lane).Nodup
  laneHeadLock : ∀ lane, (laneTrackProjection lane).head? = some Track.PNP
  laneTailLock : ∀ lane, (laneTrackProjection lane).getLast? = some Track.PC

def k40_unified_track_projection_kernel : K40UnifiedTrackProjectionKernel :=
{
  laneEqCanonical := lane_track_projection_eq_canonical,
  laneCountSeven := lane_track_projection_length,
  laneNodup := lane_track_projection_nodup,
  laneHeadLock := lane_track_projection_head_lock,
  laneTailLock := lane_track_projection_tail_lock
}

end CROOT
