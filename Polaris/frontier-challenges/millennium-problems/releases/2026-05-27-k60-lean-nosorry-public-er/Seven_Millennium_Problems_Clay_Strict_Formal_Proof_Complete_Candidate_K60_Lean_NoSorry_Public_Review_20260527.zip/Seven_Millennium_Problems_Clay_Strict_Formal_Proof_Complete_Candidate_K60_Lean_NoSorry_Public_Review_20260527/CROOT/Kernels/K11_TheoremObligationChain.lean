import CROOT.ClayTargets.ObligationChain

namespace CROOT

structure K11TheoremObligationChain where
  chainCount : canonicalObligationChain.length = 7
  pnpShape : obligationShapeValid (baseObligation ProblemId.pnp)
  rhShape : obligationShapeValid (baseObligation ProblemId.rh)
  bsdShape : obligationShapeValid (baseObligation ProblemId.bsd)
  hodgeShape : obligationShapeValid (baseObligation ProblemId.hodge)
  nsShape : obligationShapeValid (baseObligation ProblemId.navierStokes)
  ymShape : obligationShapeValid (baseObligation ProblemId.yangMills)
  pcShape : obligationShapeValid (baseObligation ProblemId.poincare)

theorem k11_theorem_obligation_chain : K11TheoremObligationChain :=
{
  chainCount := canonical_obligation_chain_length,
  pnpShape := base_obligation_shape_valid ProblemId.pnp,
  rhShape := base_obligation_shape_valid ProblemId.rh,
  bsdShape := base_obligation_shape_valid ProblemId.bsd,
  hodgeShape := base_obligation_shape_valid ProblemId.hodge,
  nsShape := base_obligation_shape_valid ProblemId.navierStokes,
  ymShape := base_obligation_shape_valid ProblemId.yangMills,
  pcShape := base_obligation_shape_valid ProblemId.poincare
}

end CROOT
