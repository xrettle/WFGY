# v1.1 Changelog

v1.1 keeps the original final evidence unchanged and adds review material.

## Added

- `00_BLACKFAN_REVIEW_V1_1.md`
- `00_ZAI_ALIGNMENT_AND_LIMITS.md`
- `00_ZAI_ALIGNMENT_TABLE.csv`
- `00_REVIEWER_ONE_PAGE.md`
- `00_API_FINAL_216_ALL_PASS_TABLE.csv`
- `02_FINAL_EVIDENCE_EXTRACTED_FULL_FOR_REVIEW/`

## Changed

- Package manifest and root hash regenerated.

## Not changed

- Final 216 evidence zip.
- Notebook artifact excluded from the public evidence ZIP.
- Final verdict numbers.
- Claim ceiling.
