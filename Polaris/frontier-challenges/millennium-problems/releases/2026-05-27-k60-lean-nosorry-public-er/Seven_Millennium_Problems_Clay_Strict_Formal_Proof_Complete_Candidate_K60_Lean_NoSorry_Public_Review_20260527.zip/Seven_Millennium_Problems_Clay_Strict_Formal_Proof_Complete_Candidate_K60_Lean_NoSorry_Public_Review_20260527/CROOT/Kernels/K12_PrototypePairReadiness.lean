import CROOT.ClayTargets.PrototypeTheoremLane

namespace CROOT

structure K12PrototypePairReadiness where
  pairCount : prototypePair.length = 2
  pnpReady : prototypeLaneShapeValid pnpPrototypeTheoremLane
  rhReady : prototypeLaneShapeValid rhPrototypeTheoremLane

theorem k12_prototype_pair_readiness : K12PrototypePairReadiness :=
{
  pairCount := prototype_pair_length,
  pnpReady := pnp_prototype_shape_valid,
  rhReady := rh_prototype_shape_valid
}

end CROOT
