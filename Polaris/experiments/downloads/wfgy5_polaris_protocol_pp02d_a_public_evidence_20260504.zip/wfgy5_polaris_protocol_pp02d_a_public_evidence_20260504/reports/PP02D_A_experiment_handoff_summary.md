# PP02D_A Experiment Handoff Summary

WFGY 5.0 Polaris Protocol  
Repository: https://github.com/onestardao/WFGY

## Verdict

PP02D_A is successful within its intended claim boundary.

It validates a strict sharded API structured-output pipeline. It does not yet validate whether the same approach improves real question-answering accuracy on natural QA tasks. That second question is exactly what PP02D_C should test next.

## Source artifact

Original uploaded package:

```text
PP02D_A_API_FULL_216_SHARDED_GREEN_PP02D_A_API_MVP_20260504T150642Z.zip
```

Underlying run id:

```text
PP02D_A_API_MVP_20260504T150642Z
```

Visible handoff alias used in this package:

```text
PP02D_A
```

## What was completed

The run completed a full 216-fixture structured API validation in 6 shards.
Each shard contained 36 fixtures.

The validated families were:

```text
F1_SRC
F2_REPO
F3_AUTH
F4_DIS
F5_CEIL
F6_ROOT
```

The experiment checked whether the model could preserve primitive evidence observations across strict JSON contracts, parser validation, semantic citation checks, support closure checks, counterfactual pairs, and poison rejection tests.

## Main results

| Metric | Result |
|---|---:|
| API run mode | FULL_216_SHARDED |
| Fixture count | 216 |
| Shard count | 6 |
| API exceptions | 0 |
| Shard parse failures | 0 |
| Parse failures | 0 |
| Fixture pass count | 216/216 |
| Semantic citation checks | 1944/1944 |
| Aggregate support union checks | 216/216 |
| Total support closure | 2160/2160 |
| Citation pass | 1944/1944 |
| Forbidden evidence used | 0 |
| Hard zero count | 0 |
| Counterfactual pairs | 180/180 |
| DeltaHitScore | 1.0 |
| StabilityScore | 1.0 |
| CounterfactualScore | 1.0 |
| Final API verdict | GREEN |

## Preflight and poison results

| Check | Result |
|---|---:|
| Sandbox pass A | GREEN |
| Sandbox pass B | GREEN |
| Poison rejection | 12/12 |
| Schema budget pass | True |
| Schema budget limit | 1000 |
| Max shard enum total | 468 |
| Token preflight green | True |

## Package integrity

| Check | Result |
|---|---:|
| Zip file count | 24 |
| Artifact manifest count | 24 |
| Hash manifest count | 22 |
| Zip self-check pass | True |
| Missing artifact rows | 0 |
| Extra artifact rows | 0 |
| Hash mismatches | 0 |

## What happened during the process

1. The work moved from small sandbox validation toward a full sharded API run.
2. The full run was capped at 216 fixtures so it could remain aligned with the other validation window.
3. The 216 fixtures were split into 6 strict structured-output family shards.
4. The preflight gate passed twice in sandbox mode, labeled pass A and pass B.
5. The API run completed all 6 shards without API exceptions.
6. The parser accepted the valid raw shard outputs and rejected malformed or poisoned cases.
7. The merge step produced aggregate score files, public evidence packets, raw API records, parse traces, and integrity manifests.
8. The final package self-check passed, with no manifest mismatches or hash mismatches under the stated policy.
9. A later ZAI review correctly pointed out that this proves structural pipeline reliability, but does not yet prove real QA improvement on tasks where a base model may answer incorrectly.

## Correct claim boundary

Safe claim:

```text
PP02D_A validates that the Polaris structured-output API pipeline can preserve primitive evidence states across 216 sharded fixtures with strict parser, poison rejection, counterfactual, support closure, and package integrity checks.
```

Do not claim yet:

```text
PP02D_A proves real QA accuracy improvement.
PP02D_A proves the model understands all tasks better.
PP02D_A proves final answer quality on Natural Questions or HotpotQA style tasks.
```

## Why PP02D_C is the correct next step

ZAI's concern is not about the cleanliness of the package. The concern is about whether the experiment measures genuine answer quality or only structured contract preservation.

PP02D_C should reuse the PP02D_A pipeline, but replace the synthetic structured fixtures with real QA tasks.

Recommended PP02D_C shape:

| Component | Recommendation |
|---|---|
| Cases | 20 to 30 |
| Source type | Natural Questions or HotpotQA style QA |
| Baseline | Raw context answer |
| Test arm | Polaris compact/topology contract answer |
| Scoring | answer correctness, evidence grounding, wrong-source use, hallucination, claim ceiling, token use |
| Success target | Better answer quality or lower wrong-source/hallucination at lower or controlled token cost |

## Bottom line

PP02D_A is complete and green for structural pipeline validation.

PP02D_C is needed for ZAI-aligned real QA validation.
