import CROOT.Kernels.K25_CompletionLaneProjectionClosure
import CROOT.Kernels.K21_SourceFieldFirstPrincipleAlignment
import CROOT.Kernels.K16_RegistryProjectionClosure

namespace CROOT

theorem source_field_projection_head_lock :
    sourceFieldProblemProjection.head? = some ProblemId.pnp := by
  simp [source_field_problem_projection_eq_canonical, canonicalProblemIds]

theorem source_field_projection_tail_lock :
    sourceFieldProblemProjection.getLast? = some ProblemId.poincare := by
  simp [source_field_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_obligation_projection_head_lock :
    generatedObligationProblemProjection.head? = some ProblemId.pnp := by
  simp [generated_obligation_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_obligation_projection_tail_lock :
    generatedObligationProblemProjection.getLast? = some ProblemId.poincare := by
  simp [generated_obligation_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_completion_projection_head_lock :
    generatedCompletionLaneProblemProjection.head? = some ProblemId.pnp := by
  simp [generated_completion_lane_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_completion_projection_tail_lock :
    generatedCompletionLaneProblemProjection.getLast? = some ProblemId.poincare := by
  simp [generated_completion_lane_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_prototype_projection_head_lock :
    generatedPrototypeProblemProjection.head? = some ProblemId.pnp := by
  simp [generated_prototype_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_prototype_projection_tail_lock :
    generatedPrototypeProblemProjection.getLast? = some ProblemId.poincare := by
  simp [generated_prototype_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_refinement_projection_head_lock :
    generatedRefinementProblemProjection.head? = some ProblemId.pnp := by
  simp [generated_refinement_problem_projection_eq_canonical, canonicalProblemIds]

theorem generated_refinement_projection_tail_lock :
    generatedRefinementProblemProjection.getLast? = some ProblemId.poincare := by
  simp [generated_refinement_problem_projection_eq_canonical, canonicalProblemIds]

structure K31ProjectionEndpointLockMatrix where
  sourceFieldHeadLocked : sourceFieldProblemProjection.head? = some ProblemId.pnp
  sourceFieldTailLocked : sourceFieldProblemProjection.getLast? = some ProblemId.poincare
  generatedObligationHeadLocked : generatedObligationProblemProjection.head? = some ProblemId.pnp
  generatedObligationTailLocked : generatedObligationProblemProjection.getLast? = some ProblemId.poincare
  generatedCompletionHeadLocked : generatedCompletionLaneProblemProjection.head? = some ProblemId.pnp
  generatedCompletionTailLocked : generatedCompletionLaneProblemProjection.getLast? = some ProblemId.poincare
  generatedPrototypeHeadLocked : generatedPrototypeProblemProjection.head? = some ProblemId.pnp
  generatedPrototypeTailLocked : generatedPrototypeProblemProjection.getLast? = some ProblemId.poincare
  generatedRefinementHeadLocked : generatedRefinementProblemProjection.head? = some ProblemId.pnp
  generatedRefinementTailLocked : generatedRefinementProblemProjection.getLast? = some ProblemId.poincare

def k31_projection_endpoint_lock_matrix : K31ProjectionEndpointLockMatrix :=
{
  sourceFieldHeadLocked := source_field_projection_head_lock,
  sourceFieldTailLocked := source_field_projection_tail_lock,
  generatedObligationHeadLocked := generated_obligation_projection_head_lock,
  generatedObligationTailLocked := generated_obligation_projection_tail_lock,
  generatedCompletionHeadLocked := generated_completion_projection_head_lock,
  generatedCompletionTailLocked := generated_completion_projection_tail_lock,
  generatedPrototypeHeadLocked := generated_prototype_projection_head_lock,
  generatedPrototypeTailLocked := generated_prototype_projection_tail_lock,
  generatedRefinementHeadLocked := generated_refinement_projection_head_lock,
  generatedRefinementTailLocked := generated_refinement_projection_tail_lock
}

end CROOT
