# Public Normalization Notes for PP02D_C

This public package was rebuilt from:

`DD02C_ZAI_EXACT_PUBLIC_QA_NONINFERIORITY_V2_20260504T181623Z_EVIDENCE.zip`

## Corrections applied

1. External package identity normalized from `DD02C` to `PP02D_C`.
2. Source files named `*_full_30.*` were renamed to `*_full100.*` because the artifact contains:
   - 100 public case manifest rows
   - 400 raw output rows
   - 400 parser/scorer rows
   - a `full100_model_ladder` verdict stage
3. Source prompt bodies were removed.
4. Compact-selection trace internals were removed.
5. Empty smoke placeholder output files were removed.
6. The source hash manifest was replaced with `hash_manifest_public.csv`.

## Evidence-integrity note

Internal `DD02C_*` case IDs and raw model JSON bodies were not rewritten because doing so would invalidate the recorded `raw_output_sha256` values.

The public archive filename and public README use `PP02D_C`.
