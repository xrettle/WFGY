# PP02D_A Public Evidence Package

This package is the public evidence version of the PP02D_A 216-fixture sharded API stability branch.

It keeps inspectable result data: score summaries, parsed outputs, raw API records, sandbox A/B result tables, poison-rejection checks, run attempt ledgers, and public integrity records.

Public boundary:
- Full core mathematics is not included.
- Colab / notebook files are not included.
- Internal system prompts and next-window prompts are not included.
- Private hash manifests and compiler-spec artifacts are not included.
- This package supports bounded PP02D_A evidence only; it is not a universal benchmark proof.

