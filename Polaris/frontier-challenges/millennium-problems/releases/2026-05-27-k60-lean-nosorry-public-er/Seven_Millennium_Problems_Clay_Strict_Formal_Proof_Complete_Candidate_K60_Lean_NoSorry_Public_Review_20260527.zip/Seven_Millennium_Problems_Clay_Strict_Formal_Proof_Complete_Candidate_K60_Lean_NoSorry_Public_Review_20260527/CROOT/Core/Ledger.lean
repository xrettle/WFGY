import CROOT.Core.Types
import CROOT.Core.Guards

namespace CROOT

structure LedgerKey where
  track : Track
  residualId : ResidualId
  obstructionClass : ObstructionClass
  deriving DecidableEq, Repr

structure LedgerEntry where
  key : LedgerKey
  atom : Atom
  deriving DecidableEq, Repr

def keyOfAtom (a : Atom) : LedgerKey :=
  { track := a.track, residualId := a.residualId, obstructionClass := a.obstructionClass }

def mergeIfSameKey (x y : LedgerEntry) : LedgerEntry :=
  x

theorem merge_left (x y : LedgerEntry) :
    mergeIfSameKey x y = x := by
  rfl

def admissibleLedgerEntry (e : LedgerEntry) : Prop :=
  officialBoundaryGuard e.atom ∧ noConclusionGuard e.atom ∧ noSuccessGuard e.atom

end CROOT
