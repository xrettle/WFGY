#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
bad = []
patterns = [
    r"\bsorry\b",
    r"\badmit\b",
    r"\baxiom\b",
    r"\bconstant\b",
]

for path in ROOT.rglob("*.lean"):
    text = path.read_text(encoding="utf-8", errors="ignore")
    in_block_comment = False
    for i, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith("/-"):
            in_block_comment = True
        if in_block_comment:
            if "-/" in s:
                in_block_comment = False
            continue
        if s.startswith("--"):
            continue
        for pat in patterns:
            if re.search(pat, line):
                bad.append((str(path.relative_to(ROOT)), i, pat, line.strip()))

if bad:
    print("NO-SORRY SCAN FAILED")
    for item in bad:
        print(f"{item[0]}:{item[1]} pattern={item[2]} line={item[3]}")
    sys.exit(1)

print("NO-SORRY SCAN PASS")
