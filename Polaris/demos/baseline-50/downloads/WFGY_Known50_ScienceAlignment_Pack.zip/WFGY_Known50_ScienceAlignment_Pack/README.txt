WFGY KNOWN-50 SCIENCE ALIGNMENT PACK

Question-first known-answer calibration pack for WFGY 5.0 — Fifth-Dimension Engine.

Purpose:
- 50 known science and math questions.
- Question-only inputs are separated from the answer key.
- WFGY-style shoot outputs are provided.
- Outputs are compared against known truth anchors.

Main command:
shoot + 50 known science and math questions

Comparison:
Known-50 checks truth alignment.
Unknown-50 opens frontier answer candidates.
Seven Millennium Problems show the peak.
