import CROOT.Kernels.K28_NormalizedStatementSyncMatrix

namespace CROOT

inductive StatementProjectionLane where
  | contracts
  | specs
  | sourceField
  | rooted
  | obligations
deriving DecidableEq, Repr

def laneStatementProjection : StatementProjectionLane → List String
  | .contracts => statementTagProjectionFromContracts
  | .specs => statementTagProjectionFromSpecs
  | .sourceField => sourceFieldStatementTagProjection
  | .rooted => rootedStatementProjection
  | .obligations => generatedObligationStatementProjection

theorem lane_statement_projection_eq_contracts :
    ∀ lane, laneStatementProjection lane = statementTagProjectionFromContracts
  | .contracts => rfl
  | .specs => by
      symm
      exact statement_tag_projection_contracts_eq_specs
  | .sourceField => source_field_statement_projection_eq_contracts
  | .rooted => rooted_statement_projection_eq_contracts
  | .obligations => generated_obligation_statement_projection_eq_contracts

theorem lane_statement_projection_length :
    ∀ lane, (laneStatementProjection lane).length = 7 := by
  intro lane
  calc
    (laneStatementProjection lane).length = statementTagProjectionFromContracts.length := by
      simpa [lane_statement_projection_eq_contracts lane]
    _ = 7 := by
      simpa [statementTagProjectionFromContracts] using canonical_statement_contracts_length

inductive NormalizedStatementProjectionLane where
  | adapterContracts
  | adapterSpecs
  | rootedNormalized
  | obligationsNormalized
deriving DecidableEq, Repr

def laneNormalizedStatementProjection : NormalizedStatementProjectionLane → List String
  | .adapterContracts => adapterTagProjectionFromContracts
  | .adapterSpecs => adapterTagProjectionFromSpecs
  | .rootedNormalized => rootedNormalizedStatementProjection
  | .obligationsNormalized => obligationNormalizedStatementProjection

theorem lane_normalized_statement_projection_eq_adapter_contracts :
    ∀ lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  | .adapterContracts => rfl
  | .adapterSpecs => by
      symm
      exact adapter_tag_projection_contracts_eq_specs
  | .rootedNormalized => rooted_normalized_statement_eq_adapter_contracts
  | .obligationsNormalized => obligation_normalized_statement_eq_adapter_contracts

theorem lane_normalized_statement_projection_length :
    ∀ lane, (laneNormalizedStatementProjection lane).length = 7 := by
  intro lane
  calc
    (laneNormalizedStatementProjection lane).length = adapterTagProjectionFromContracts.length := by
      simpa [lane_normalized_statement_projection_eq_adapter_contracts lane]
    _ = 7 := by
      simpa [adapterTagProjectionFromContracts] using canonical_statement_contracts_length

structure K42UnifiedStatementProjectionKernel where
  laneToContracts : ∀ lane, laneStatementProjection lane = statementTagProjectionFromContracts
  laneCountSeven : ∀ lane, (laneStatementProjection lane).length = 7
  normalizedLaneToAdapterContracts :
    ∀ lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  normalizedLaneCountSeven : ∀ lane, (laneNormalizedStatementProjection lane).length = 7

def k42_unified_statement_projection_kernel : K42UnifiedStatementProjectionKernel :=
{
  laneToContracts := lane_statement_projection_eq_contracts,
  laneCountSeven := lane_statement_projection_length,
  normalizedLaneToAdapterContracts := lane_normalized_statement_projection_eq_adapter_contracts,
  normalizedLaneCountSeven := lane_normalized_statement_projection_length
}

end CROOT
