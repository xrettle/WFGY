# WFGY Moses Public Safe Data Package

Created: 2026-05-01T10:00:00Z

This is a public-safe aggregate data package for the Moses branch.
It is intentionally limited to stage-level and aggregate metrics.

This package does **not** include executable notebooks, raw evidence zips, prompt manifests, case payloads, raw outputs, parsed outputs, judge rows, evaluator logic, scoring contracts, or detailed failure-surface records.

## What this package supports

This package supports the following public statement:

The Moses branch reached T4 composite closure for merge preparation, with primary clean full API evidence at T3/P2 and T4 composite evidence represented as full T4 v1 pipeline execution plus targeted patch mini verifier aggregate pass.

## What this package does not support

This package must not be used to claim:

1. Independent full T4 v2 API pass.
2. GPU myth fully broken.
3. Final one-shot-killer merge proof complete.
4. Universal small-model superiority.
5. A public reader can reconstruct the internal evaluator or private experiment stack from this package.

## Files

- `01_PUBLIC_CLAIM_BOUNDARY.md`: allowed and disallowed public claims.
- `02_AGGREGATE_STAGE_METRICS_PUBLIC.csv`: aggregate stage metrics only.
- `03_AGGREGATE_STAGE_METRICS_PUBLIC.json`: JSON version of the aggregate stage metrics.
- `04_PUBLIC_COMPOSITE_VERDICT.json`: public-safe composite verdict summary.
- `05_REDACTION_AND_SAFETY_NOTE.md`: explicit explanation of what was removed.
- `06_PUBLIC_SHA256_MANIFEST.csv`: SHA256 hashes for files in this public package.

## Reproducibility boundary

The public package is designed for public review of aggregate outcomes, not private-method replication.
Raw experimental artifacts remain internal by design.
