
# Public Safe Summary Template

Do not include packet schema, corruption manifest, judge rubric, or DDI repair details.

Trial: AI_TSUNAMI_T3_INTERNAL_SCALE
Version: v1_1_single_file_colab
Case count: 80
Arms: A/B/C/D
Models: gpt-4.1, gpt-4.1-mini
Global level: L5_T3_INTERNAL_SCALE_PASS

Safe metrics:
- C mean score
- Raw TokenRatio C/A
- Amortized TokenRatio C/A
- C minus D
- Failure signature match
- Leakage count

Claim boundary:
Scoped topology-conservation T3 Internal Scale only.
