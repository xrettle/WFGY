import CROOT.Kernels.K48_UnifiedNodupEndpointKernel

namespace CROOT

structure LaneEqCountSkeleton (Lane : Type) (α : Type) (projection : Lane → List α) (canonical : List α) where
  eqCanonical : forall lane, projection lane = canonical
  countSeven : forall lane, (projection lane).length = 7

structure LaneEqCountNodupSkeleton (Lane : Type) (α : Type) (projection : Lane → List α) (canonical : List α) where
  eqCanonical : forall lane, projection lane = canonical
  countSeven : forall lane, (projection lane).length = 7
  nodup : forall lane, (projection lane).Nodup

structure LaneEndpointLockSkeleton
    (Lane : Type) (α : Type) (projection : Lane → List α) (headValue tailValue : α) where
  headLock : forall lane, (projection lane).head? = some headValue
  tailLock : forall lane, (projection lane).getLast? = some tailValue

def track_lane_core_skeleton :
    LaneEqCountNodupSkeleton
      TrackProjectionLane Track laneTrackProjection canonicalTrackProjection :=
{
  eqCanonical := lane_track_projection_eq_canonical,
  countSeven := lane_track_projection_length,
  nodup := lane_track_projection_nodup
}

def problem_lane_core_skeleton :
    LaneEqCountNodupSkeleton
      ProblemProjectionLane ProblemId laneProblemProjection canonicalProblemIds :=
{
  eqCanonical := lane_problem_projection_eq_canonical,
  countSeven := lane_problem_projection_length,
  nodup := lane_problem_projection_nodup
}

def statement_lane_core_skeleton :
    LaneEqCountSkeleton
      StatementProjectionLane String laneStatementProjection statementTagProjectionFromContracts :=
{
  eqCanonical := lane_statement_projection_eq_contracts,
  countSeven := lane_statement_projection_length
}

def normalized_statement_lane_core_skeleton :
    LaneEqCountSkeleton
      NormalizedStatementProjectionLane String laneNormalizedStatementProjection adapterTagProjectionFromContracts :=
{
  eqCanonical := lane_normalized_statement_projection_eq_adapter_contracts,
  countSeven := lane_normalized_statement_projection_length
}

def domain_lane_core_skeleton :
    LaneEqCountSkeleton
      DomainProjectionLane String laneDomainProjection canonicalDomainTagProjection :=
{
  eqCanonical := lane_domain_projection_eq_canonical,
  countSeven := lane_domain_projection_length
}

def track_lane_endpoint_lock_skeleton :
    LaneEndpointLockSkeleton TrackProjectionLane Track laneTrackProjection Track.PNP Track.PC :=
{
  headLock := lane_track_projection_head_lock,
  tailLock := lane_track_projection_tail_lock
}

def problem_lane_endpoint_lock_skeleton :
    LaneEndpointLockSkeleton ProblemProjectionLane ProblemId laneProblemProjection ProblemId.pnp ProblemId.poincare :=
{
  headLock := lane_problem_projection_head_lock,
  tailLock := lane_problem_projection_tail_lock
}

structure K49SharedLaneProofSkeleton where
  trackCore :
    LaneEqCountNodupSkeleton
      TrackProjectionLane Track laneTrackProjection canonicalTrackProjection
  problemCore :
    LaneEqCountNodupSkeleton
      ProblemProjectionLane ProblemId laneProblemProjection canonicalProblemIds
  statementCore :
    LaneEqCountSkeleton
      StatementProjectionLane String laneStatementProjection statementTagProjectionFromContracts
  normalizedStatementCore :
    LaneEqCountSkeleton
      NormalizedStatementProjectionLane String laneNormalizedStatementProjection adapterTagProjectionFromContracts
  domainCore :
    LaneEqCountSkeleton
      DomainProjectionLane String laneDomainProjection canonicalDomainTagProjection
  trackEndpoint :
    LaneEndpointLockSkeleton TrackProjectionLane Track laneTrackProjection Track.PNP Track.PC
  problemEndpoint :
    LaneEndpointLockSkeleton ProblemProjectionLane ProblemId laneProblemProjection ProblemId.pnp ProblemId.poincare

def k49_shared_lane_proof_skeleton : K49SharedLaneProofSkeleton :=
{
  trackCore := track_lane_core_skeleton,
  problemCore := problem_lane_core_skeleton,
  statementCore := statement_lane_core_skeleton,
  normalizedStatementCore := normalized_statement_lane_core_skeleton,
  domainCore := domain_lane_core_skeleton,
  trackEndpoint := track_lane_endpoint_lock_skeleton,
  problemEndpoint := problem_lane_endpoint_lock_skeleton
}

end CROOT
