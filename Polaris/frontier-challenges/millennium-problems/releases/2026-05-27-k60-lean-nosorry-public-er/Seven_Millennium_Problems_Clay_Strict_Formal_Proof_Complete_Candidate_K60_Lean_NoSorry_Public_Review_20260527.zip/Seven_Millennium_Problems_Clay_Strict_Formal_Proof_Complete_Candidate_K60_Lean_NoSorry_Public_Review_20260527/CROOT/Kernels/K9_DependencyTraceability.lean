import CROOT.Kernels.K8_AssumptionFirewall
import CROOT.Adapters.AuthorityRoutingContract

namespace CROOT

structure DependencyRecord where
  problem : ProblemId
  sourceModule : String
  importClass : ImportClass
  decision : ImportDecision
  deriving DecidableEq, Repr

def mkDependencyRecord (p : ProblemId) (moduleName : String) (cls : ImportClass) : DependencyRecord :=
  {
    problem := p,
    sourceModule := moduleName,
    importClass := cls,
    decision := decideImport cls
  }

def canonicalDependencyTrace : List DependencyRecord :=
  [mkDependencyRecord ProblemId.pnp "Complexity.Core" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.rh "Zeta.Analytic" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.bsd "Elliptic.Basic" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.hodge "Cohomology.Core" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.navierStokes "PDE.FunctionSpace" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.yangMills "GaugeTheory.Core" ImportClass.safeBackground,
   mkDependencyRecord ProblemId.poincare "Manifold.Basic" ImportClass.safeBackground]

def dependencyDecisionMatchesImportClass (r : DependencyRecord) : Prop :=
  r.decision = decideImport r.importClass

theorem mk_dependency_record_is_consistent (p : ProblemId) (m : String) (cls : ImportClass) :
    dependencyDecisionMatchesImportClass (mkDependencyRecord p m cls) := by
  rfl

theorem canonical_dependency_trace_length : canonicalDependencyTrace.length = 7 := by
  rfl

structure K9DependencyTraceability where
  traceLength : canonicalDependencyTrace.length = 7
  runtimeOrderLength : requiredRuntimeOrder.length = 7
  directBlocked : decideImport ImportClass.directTarget = ImportDecision.blocked
  solvedBlocked : decideImport ImportClass.solvedRoute = ImportDecision.blocked
  knownBlocked : decideImport ImportClass.knownEquivalent = ImportDecision.blocked
  unknownEscalated : decideImport ImportClass.unknownEquivalent = ImportDecision.escalated
  safeAllowed : decideImport ImportClass.safeBackground = ImportDecision.allowed
  adapterToSourceAuthorityBlocked : adapterPathAllowed AdapterPath.adapterToSourceAuthority = false
  adapterToExternalDirectBlocked : adapterPathAllowed AdapterPath.adapterToExternalLedgerDirect = false
  adapterToSourceMutationBlocked : adapterPathAllowed AdapterPath.adapterToSourceMutation = false
  adapterToCoreReviewAllowed : adapterPathAllowed AdapterPath.adapterToCoreReview = true
  adapterToInternalValidationAllowed : adapterPathAllowed AdapterPath.adapterToInternalLedgerValidation = true

theorem k9_dependency_traceability : K9DependencyTraceability :=
{
  traceLength := canonical_dependency_trace_length,
  runtimeOrderLength := runtime_order_has_seven_stages,
  directBlocked := K2_direct_blocked,
  solvedBlocked := K2_solved_blocked,
  knownBlocked := K2_equivalent_blocked,
  unknownEscalated := K2_unknown_escalates,
  safeAllowed := K2_safe_background_allowed,
  adapterToSourceAuthorityBlocked := adapter_path_source_authority_blocked,
  adapterToExternalDirectBlocked := adapter_path_external_direct_blocked,
  adapterToSourceMutationBlocked := adapter_path_source_mutation_blocked,
  adapterToCoreReviewAllowed := adapter_path_core_review_allowed,
  adapterToInternalValidationAllowed := adapter_path_internal_validation_allowed
}

end CROOT
