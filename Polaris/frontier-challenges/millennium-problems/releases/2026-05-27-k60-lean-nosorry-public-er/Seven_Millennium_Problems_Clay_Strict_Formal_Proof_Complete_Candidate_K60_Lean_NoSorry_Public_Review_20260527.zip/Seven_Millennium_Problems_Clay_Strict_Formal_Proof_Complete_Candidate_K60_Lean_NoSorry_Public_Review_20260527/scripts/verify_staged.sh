#!/usr/bin/env bash
set -euo pipefail
mkdir -p build_logs

echo "[stage 0] versions"
(lean --version || true) | tee build_logs/lean_version.txt
(lake --version || true) | tee build_logs/lake_version.txt

echo "[stage 1] smoke"
set +e
lean CROOT/Smoke.lean 2>&1 | tee build_logs/stage1_smoke.log
RC1=${PIPESTATUS[0]}
set -e
echo "${RC1}" > build_logs/stage1_smoke.returncode
if [ "${RC1}" -ne 0 ]; then exit "${RC1}"; fi

echo "[stage 2] seal"
set +e
lean CROOT/Seal.lean 2>&1 | tee build_logs/stage2_seal.log
RCSEAL=${PIPESTATUS[0]}
set -e
echo "${RCSEAL}" > build_logs/stage2_seal.returncode
if [ "${RCSEAL}" -ne 0 ]; then exit "${RCSEAL}"; fi

echo "[stage 3] lake build"
set +e
lake build 2>&1 | tee build_logs/lake_build.log
RC2=${PIPESTATUS[0]}
set -e
echo "${RC2}" > build_logs/lake_build.returncode
if [ "${RC2}" -ne 0 ]; then exit "${RC2}"; fi

echo "[stage 4] no-sorry scan"
python3 scripts/no_sorry_scan.py | tee build_logs/no_sorry_scan.log

echo "VERIFY STAGED PASS"
