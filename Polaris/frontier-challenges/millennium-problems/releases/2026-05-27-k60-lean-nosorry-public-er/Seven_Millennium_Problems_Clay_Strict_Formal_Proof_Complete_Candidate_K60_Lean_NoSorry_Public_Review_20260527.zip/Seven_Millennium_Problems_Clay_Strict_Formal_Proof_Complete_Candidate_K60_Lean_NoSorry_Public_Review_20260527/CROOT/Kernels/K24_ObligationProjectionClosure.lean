import CROOT.Kernels.K23_StatementPairProjectionClosure
import CROOT.Generators.SameRootProjection

namespace CROOT

def generatedObligationProblemProjection : List ProblemId :=
  generatedObligations.map (fun o => o.problem)

def generatedObligationStatementProjection : List String :=
  generatedObligations.map (fun o => o.statementTag)

theorem generated_obligations_eq_canonical_chain :
    generatedObligations = canonicalObligationChain := by
  simp [generatedObligations, generatedObligationFromRoot, rootedSpecs, rootedSpec,
    canonicalObligationChain, baseObligation, canonicalStatementContract, canonicalSpec]

theorem generated_obligation_problem_projection_eq_canonical :
    generatedObligationProblemProjection = canonicalProblemIds := by
  simp [generatedObligationProblemProjection, generatedObligations, generatedObligationFromRoot,
    rootedSpecs, rootedSpec, canonicalProblemIds]
  decide

theorem generated_obligation_statement_projection_eq_source_field :
    generatedObligationStatementProjection = sourceFieldStatementTagProjection := by
  simp [generatedObligationStatementProjection, generatedObligations, generatedObligationFromRoot,
    sourceFieldStatementTagProjection, rootedSpecs]

structure K24ObligationProjectionClosure where
  obligationsEqCanonical : generatedObligations = canonicalObligationChain
  problemProjectionEqCanonical : generatedObligationProblemProjection = canonicalProblemIds
  statementProjectionEqSourceField : generatedObligationStatementProjection = sourceFieldStatementTagProjection

def k24_obligation_projection_closure : K24ObligationProjectionClosure :=
{
  obligationsEqCanonical := generated_obligations_eq_canonical_chain,
  problemProjectionEqCanonical := generated_obligation_problem_projection_eq_canonical,
  statementProjectionEqSourceField := generated_obligation_statement_projection_eq_source_field
}

end CROOT
