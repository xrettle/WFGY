# Riemann Hypothesis · Official Statement Lock

## Problem ID

```text
RH
```

## Domain

```text
Analytic number theory
```

## Official theorem target

```text
Every nontrivial zero of the Riemann zeta function has real part 1/2.
```

## Native target phrase

```text
critical-line zero statement
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
