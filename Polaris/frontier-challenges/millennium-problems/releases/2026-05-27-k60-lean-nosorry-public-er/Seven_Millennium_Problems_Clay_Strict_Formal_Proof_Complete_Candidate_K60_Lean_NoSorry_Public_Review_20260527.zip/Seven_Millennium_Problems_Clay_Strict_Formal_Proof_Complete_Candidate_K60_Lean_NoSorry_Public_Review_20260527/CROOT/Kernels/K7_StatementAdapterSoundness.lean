import CROOT.Adapters.MathematicalStatementAdapter
import CROOT.Adapters.StatementEquivalenceBridge
import CROOT.Kernels.K6_ProblemSpecCoverage

namespace CROOT

structure K7StatementAdapterSoundness where
  preservesProblemId : forall input : StatementAdapterInput,
    (adaptStatement input).problem = input.problem
  directTargetBlocked : decideImport ImportClass.directTarget = ImportDecision.blocked
  solvedRouteBlocked : decideImport ImportClass.solvedRoute = ImportDecision.blocked
  knownEquivalentBlocked : decideImport ImportClass.knownEquivalent = ImportDecision.blocked
  unknownEquivalentEscalated : decideImport ImportClass.unknownEquivalent = ImportDecision.escalated
  safeBackgroundAllowed : decideImport ImportClass.safeBackground = ImportDecision.allowed
  statementContractCount : canonicalStatementContracts.length = 7
  pnpContract : contractShapeValid (canonicalStatementContract ProblemId.pnp)
  rhContract : contractShapeValid (canonicalStatementContract ProblemId.rh)
  bsdContract : contractShapeValid (canonicalStatementContract ProblemId.bsd)
  hodgeContract : contractShapeValid (canonicalStatementContract ProblemId.hodge)
  nsContract : contractShapeValid (canonicalStatementContract ProblemId.navierStokes)
  ymContract : contractShapeValid (canonicalStatementContract ProblemId.yangMills)
  pcContract : contractShapeValid (canonicalStatementContract ProblemId.poincare)

theorem k7_statement_adapter_soundness : K7StatementAdapterSoundness :=
{
  preservesProblemId := adapter_keeps_problem_id,
  directTargetBlocked := K2_direct_blocked,
  solvedRouteBlocked := K2_solved_blocked,
  knownEquivalentBlocked := K2_equivalent_blocked,
  unknownEquivalentEscalated := K2_unknown_escalates,
  safeBackgroundAllowed := K2_safe_background_allowed,
  statementContractCount := canonical_statement_contracts_length,
  pnpContract := canonical_statement_contract_shape_valid ProblemId.pnp,
  rhContract := canonical_statement_contract_shape_valid ProblemId.rh,
  bsdContract := canonical_statement_contract_shape_valid ProblemId.bsd,
  hodgeContract := canonical_statement_contract_shape_valid ProblemId.hodge,
  nsContract := canonical_statement_contract_shape_valid ProblemId.navierStokes,
  ymContract := canonical_statement_contract_shape_valid ProblemId.yangMills,
  pcContract := canonical_statement_contract_shape_valid ProblemId.poincare
}

end CROOT
