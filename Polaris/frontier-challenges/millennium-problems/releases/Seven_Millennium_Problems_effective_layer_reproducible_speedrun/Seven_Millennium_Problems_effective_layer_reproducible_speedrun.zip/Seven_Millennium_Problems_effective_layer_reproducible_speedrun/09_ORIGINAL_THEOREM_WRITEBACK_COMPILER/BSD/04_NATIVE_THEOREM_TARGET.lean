-- C03 native theorem target stub for Birch and Swinnerton-Dyer Conjecture
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.BSD

-- theorem target:
-- The rank of an elliptic curve over Q equals the order of vanishing of its L-function at s=1, with the leading coefficient governed by arithmetic invariants.

axiom native_theorem_target_BSD : Prop

end WFGY.C03.BSD
