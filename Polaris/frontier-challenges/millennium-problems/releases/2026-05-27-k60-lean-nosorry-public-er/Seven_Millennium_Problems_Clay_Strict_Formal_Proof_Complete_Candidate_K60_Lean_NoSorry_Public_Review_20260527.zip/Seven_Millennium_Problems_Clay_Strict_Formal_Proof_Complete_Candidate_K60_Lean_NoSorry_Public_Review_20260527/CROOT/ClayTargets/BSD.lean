import CROOT.ClayTargets.Common

namespace CROOT

def bsdDomainCore : DomainCoreSignature :=
  {
    objectTag := "elliptic-curve-l-function-pair"
    operationTag := "rank-regulator-selmer-map"
    invariantTag := "arithmetic-analytic-bridge-obligation"
  }

def bsdTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.bsd "official-clay-statement-boundary"

theorem bsd_target_problem :
    bsdTargetContract.problem = ProblemId.bsd := by
  rfl

theorem bsd_target_shape_valid :
    targetContractShapeValid bsdTargetContract := by
  constructor <;> decide

end CROOT
