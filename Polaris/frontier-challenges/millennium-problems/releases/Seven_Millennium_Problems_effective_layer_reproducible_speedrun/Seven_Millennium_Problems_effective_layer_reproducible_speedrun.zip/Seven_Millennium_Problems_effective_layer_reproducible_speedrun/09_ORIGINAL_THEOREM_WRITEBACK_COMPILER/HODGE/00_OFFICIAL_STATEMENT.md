# Hodge Conjecture · Official Statement Lock

## Problem ID

```text
HODGE
```

## Domain

```text
Algebraic geometry
```

## Official theorem target

```text
Every rational Hodge class on a smooth projective complex variety is a rational linear combination of algebraic cycle classes.
```

## Native target phrase

```text
rational Hodge classes are algebraic
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
