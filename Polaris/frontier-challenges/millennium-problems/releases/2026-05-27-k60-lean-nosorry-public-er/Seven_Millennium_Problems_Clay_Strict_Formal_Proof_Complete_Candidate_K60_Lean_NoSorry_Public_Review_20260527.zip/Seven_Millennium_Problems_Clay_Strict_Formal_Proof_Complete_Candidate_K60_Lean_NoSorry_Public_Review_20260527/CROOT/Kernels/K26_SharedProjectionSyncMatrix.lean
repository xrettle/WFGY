import CROOT.Kernels.K25_CompletionLaneProjectionClosure
import CROOT.Kernels.K16_RegistryProjectionClosure

namespace CROOT

theorem obligation_completion_projection_sync :
    generatedObligationProblemProjection = generatedCompletionLaneProblemProjection := by
  calc
    generatedObligationProblemProjection = canonicalProblemIds := generated_obligation_problem_projection_eq_canonical
    _ = generatedCompletionLaneProblemProjection := by
      symm
      exact generated_completion_lane_problem_projection_eq_canonical

theorem obligation_prototype_projection_sync :
    generatedObligationProblemProjection = generatedPrototypeProblemProjection := by
  calc
    generatedObligationProblemProjection = canonicalProblemIds := generated_obligation_problem_projection_eq_canonical
    _ = generatedPrototypeProblemProjection := by
      symm
      exact generated_prototype_problem_projection_eq_canonical

theorem obligation_refinement_projection_sync :
    generatedObligationProblemProjection = generatedRefinementProblemProjection := by
  calc
    generatedObligationProblemProjection = canonicalProblemIds := generated_obligation_problem_projection_eq_canonical
    _ = generatedRefinementProblemProjection := by
      symm
      exact generated_refinement_problem_projection_eq_canonical

theorem source_field_obligation_projection_sync :
    sourceFieldProblemProjection = generatedObligationProblemProjection := by
  calc
    sourceFieldProblemProjection = canonicalProblemIds := source_field_problem_projection_eq_canonical
    _ = generatedObligationProblemProjection := by
      symm
      exact generated_obligation_problem_projection_eq_canonical

theorem source_field_completion_projection_sync :
    sourceFieldProblemProjection = generatedCompletionLaneProblemProjection := by
  calc
    sourceFieldProblemProjection = canonicalProblemIds := source_field_problem_projection_eq_canonical
    _ = generatedCompletionLaneProblemProjection := by
      symm
      exact generated_completion_lane_problem_projection_eq_canonical

structure K26SharedProjectionSyncMatrix where
  obligationCompletionSync : generatedObligationProblemProjection = generatedCompletionLaneProblemProjection
  obligationPrototypeSync : generatedObligationProblemProjection = generatedPrototypeProblemProjection
  obligationRefinementSync : generatedObligationProblemProjection = generatedRefinementProblemProjection
  sourceFieldObligationSync : sourceFieldProblemProjection = generatedObligationProblemProjection
  sourceFieldCompletionSync : sourceFieldProblemProjection = generatedCompletionLaneProblemProjection

def k26_shared_projection_sync_matrix : K26SharedProjectionSyncMatrix :=
{
  obligationCompletionSync := obligation_completion_projection_sync,
  obligationPrototypeSync := obligation_prototype_projection_sync,
  obligationRefinementSync := obligation_refinement_projection_sync,
  sourceFieldObligationSync := source_field_obligation_projection_sync,
  sourceFieldCompletionSync := source_field_completion_projection_sync
}

end CROOT
