import CROOT.ClayTargets.PvsNP
import CROOT.ClayTargets.RiemannHypothesis
import CROOT.ClayTargets.BSD
import CROOT.ClayTargets.Hodge
import CROOT.ClayTargets.NavierStokes
import CROOT.ClayTargets.YangMills
import CROOT.ClayTargets.Poincare

namespace CROOT

def clayTargetRegistry : List FormalizationTargetContract :=
  [pnpTargetContract,
   rhTargetContract,
   bsdTargetContract,
   hodgeTargetContract,
   navierStokesTargetContract,
   yangMillsTargetContract,
   poincareTargetContract]

theorem clay_target_registry_length : clayTargetRegistry.length = 7 := by
  rfl

end CROOT
