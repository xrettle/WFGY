import CROOT.Kernels.K29_ControlSurfaceSyncMatrix
import CROOT.Kernels.K18_StatementEquivalenceHardLock

namespace CROOT

inductive ReturnLockProjectionLane where
  | statementContract
  | generatedObligation
deriving DecidableEq, Repr

def laneReturnLockProjection : ReturnLockProjectionLane → List ReturnLockStatus
  | .statementContract => statementContractReturnLockProjection
  | .generatedObligation => generatedObligationReturnLockProjection

theorem lane_return_lock_all_locked :
    ∀ lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  | .statementContract => statement_contract_return_lock_all_locked
  | .generatedObligation => generated_obligation_return_lock_all_locked

theorem lane_return_lock_count :
    ∀ lane, (laneReturnLockProjection lane).length = 7 := by
  intro lane
  simpa [lane_return_lock_all_locked lane]

inductive DecisionProjectionLane where
  | statementContract
  | generatedObligation
deriving DecidableEq, Repr

def laneDecisionProjection : DecisionProjectionLane → List ImportDecision
  | .statementContract => statementContractDecisionProjection
  | .generatedObligation => generatedObligationDecisionProjection

theorem lane_decision_all_allowed :
    ∀ lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  | .statementContract => statement_contract_decision_all_allowed
  | .generatedObligation => generated_obligation_decision_all_allowed

theorem lane_decision_count :
    ∀ lane, (laneDecisionProjection lane).length = 7 := by
  intro lane
  simpa [lane_decision_all_allowed lane]

inductive BoundaryProjectionLane where
  | manual
  | generated
deriving DecidableEq, Repr

def laneBoundaryProjection : BoundaryProjectionLane → List String
  | .manual => manualBoundaryProjection
  | .generated => generatedBoundaryProjection

theorem lane_boundary_all_official :
    ∀ lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  | .manual => manual_boundary_projection_official
  | .generated => generated_boundary_projection_official

theorem lane_boundary_count :
    ∀ lane, (laneBoundaryProjection lane).length = 7 := by
  intro lane
  simpa [lane_boundary_all_official lane]

theorem generated_obligation_debt_count :
    generatedObligationDebtProjection.length = 7 := by
  simpa [generated_obligation_debt_all_open]

structure K44UnifiedControlSurfaceKernel where
  returnLockAllLocked :
    ∀ lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  returnLockCountSeven :
    ∀ lane, (laneReturnLockProjection lane).length = 7
  decisionAllAllowed :
    ∀ lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  decisionCountSeven :
    ∀ lane, (laneDecisionProjection lane).length = 7
  boundaryAllOfficial :
    ∀ lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  boundaryCountSeven :
    ∀ lane, (laneBoundaryProjection lane).length = 7
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt
  debtCountSeven :
    generatedObligationDebtProjection.length = 7

def k44_unified_control_surface_kernel : K44UnifiedControlSurfaceKernel :=
{
  returnLockAllLocked := lane_return_lock_all_locked,
  returnLockCountSeven := lane_return_lock_count,
  decisionAllAllowed := lane_decision_all_allowed,
  decisionCountSeven := lane_decision_count,
  boundaryAllOfficial := lane_boundary_all_official,
  boundaryCountSeven := lane_boundary_count,
  debtAllOpen := generated_obligation_debt_all_open,
  debtCountSeven := generated_obligation_debt_count
}

end CROOT
