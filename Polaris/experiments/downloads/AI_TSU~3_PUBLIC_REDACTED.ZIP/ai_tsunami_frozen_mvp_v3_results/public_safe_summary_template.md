
# Public Safe Summary Template

Do not include packet schema, corruption manifest, judge rubric, or DDI repair details.

Trial: AI_TSUNAMI_FROZEN_MVP_PRIMARY
Version: v4_single_file_colab
Case count: 48
Arms: A/B/C/D
Models: gpt-4.1, gpt-4.1-mini
Global level: L5_FROZEN_MVP_PRIMARY_PASS

Safe metrics:
- C mean score
- Raw TokenRatio C/A
- Amortized TokenRatio C/A
- C minus D
- Failure signature match
- Leakage count

Claim boundary:
Scoped topology-conservation Frozen MVP Primary only.
