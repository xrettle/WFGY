#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
echo "Running Seven Millennium Problems RPG speedrun..."
python3 tools/run_public_rpg_speedrun.py --root . --summary-json PUBLIC_RPG_RUN_SUMMARY.json
echo "SPEEDRUN PASS."
