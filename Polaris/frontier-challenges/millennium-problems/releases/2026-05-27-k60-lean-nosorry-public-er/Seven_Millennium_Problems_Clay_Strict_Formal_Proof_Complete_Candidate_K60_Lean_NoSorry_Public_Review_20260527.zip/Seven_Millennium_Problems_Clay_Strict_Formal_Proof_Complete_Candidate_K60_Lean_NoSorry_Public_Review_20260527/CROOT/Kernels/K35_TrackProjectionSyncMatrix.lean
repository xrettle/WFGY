import CROOT.Kernels.K34_TrackEndpointLockMatrix
import CROOT.Kernels.K24_ObligationProjectionClosure
import CROOT.Kernels.K25_CompletionLaneProjectionClosure
import CROOT.Kernels.K16_RegistryProjectionClosure

namespace CROOT

def generatedObligationTrackProjection : List Track :=
  generatedObligationProblemProjection.map problemTrackOf

def generatedCompletionTrackProjection : List Track :=
  generatedCompletionLaneProblemProjection.map problemTrackOf

def generatedPrototypeTrackProjection : List Track :=
  generatedPrototypeProblemProjection.map problemTrackOf

def generatedRefinementTrackProjection : List Track :=
  generatedRefinementProblemProjection.map problemTrackOf

theorem generated_obligation_track_projection_eq_canonical :
    generatedObligationTrackProjection = canonicalTrackProjection := by
  simpa [generatedObligationTrackProjection, canonicalTrackProjection] using
    congrArg (fun xs => xs.map problemTrackOf) generated_obligation_problem_projection_eq_canonical

theorem generated_completion_track_projection_eq_canonical :
    generatedCompletionTrackProjection = canonicalTrackProjection := by
  simpa [generatedCompletionTrackProjection, canonicalTrackProjection] using
    congrArg (fun xs => xs.map problemTrackOf) generated_completion_lane_problem_projection_eq_canonical

theorem generated_prototype_track_projection_eq_canonical :
    generatedPrototypeTrackProjection = canonicalTrackProjection := by
  simpa [generatedPrototypeTrackProjection, canonicalTrackProjection] using
    congrArg (fun xs => xs.map problemTrackOf) generated_prototype_problem_projection_eq_canonical

theorem generated_refinement_track_projection_eq_canonical :
    generatedRefinementTrackProjection = canonicalTrackProjection := by
  simpa [generatedRefinementTrackProjection, canonicalTrackProjection] using
    congrArg (fun xs => xs.map problemTrackOf) generated_refinement_problem_projection_eq_canonical

theorem obligation_completion_track_projection_sync :
    generatedObligationTrackProjection = generatedCompletionTrackProjection := by
  calc
    generatedObligationTrackProjection = canonicalTrackProjection := generated_obligation_track_projection_eq_canonical
    _ = generatedCompletionTrackProjection := by
      symm
      exact generated_completion_track_projection_eq_canonical

theorem obligation_prototype_track_projection_sync :
    generatedObligationTrackProjection = generatedPrototypeTrackProjection := by
  calc
    generatedObligationTrackProjection = canonicalTrackProjection := generated_obligation_track_projection_eq_canonical
    _ = generatedPrototypeTrackProjection := by
      symm
      exact generated_prototype_track_projection_eq_canonical

theorem obligation_refinement_track_projection_sync :
    generatedObligationTrackProjection = generatedRefinementTrackProjection := by
  calc
    generatedObligationTrackProjection = canonicalTrackProjection := generated_obligation_track_projection_eq_canonical
    _ = generatedRefinementTrackProjection := by
      symm
      exact generated_refinement_track_projection_eq_canonical

structure K35TrackProjectionSyncMatrix where
  obligationEqCanonical : generatedObligationTrackProjection = canonicalTrackProjection
  completionEqCanonical : generatedCompletionTrackProjection = canonicalTrackProjection
  prototypeEqCanonical : generatedPrototypeTrackProjection = canonicalTrackProjection
  refinementEqCanonical : generatedRefinementTrackProjection = canonicalTrackProjection
  obligationCompletionSync : generatedObligationTrackProjection = generatedCompletionTrackProjection
  obligationPrototypeSync : generatedObligationTrackProjection = generatedPrototypeTrackProjection
  obligationRefinementSync : generatedObligationTrackProjection = generatedRefinementTrackProjection

def k35_track_projection_sync_matrix : K35TrackProjectionSyncMatrix :=
{
  obligationEqCanonical := generated_obligation_track_projection_eq_canonical,
  completionEqCanonical := generated_completion_track_projection_eq_canonical,
  prototypeEqCanonical := generated_prototype_track_projection_eq_canonical,
  refinementEqCanonical := generated_refinement_track_projection_eq_canonical,
  obligationCompletionSync := obligation_completion_track_projection_sync,
  obligationPrototypeSync := obligation_prototype_track_projection_sync,
  obligationRefinementSync := obligation_refinement_track_projection_sync
}

end CROOT
