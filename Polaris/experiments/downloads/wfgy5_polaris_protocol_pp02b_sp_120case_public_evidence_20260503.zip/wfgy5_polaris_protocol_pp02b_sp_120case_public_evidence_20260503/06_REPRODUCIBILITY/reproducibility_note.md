# Reproducibility Note

Branch: PP02B

This public evidence package is designed for transparent inspection and Colab based reproduction.

Execution notebooks are excluded from the package by design. The evidence package preserves raw outputs, parsed outputs, verdict tables, metrics, audit records, and regenerated integrity manifests.

Public Colab reproduction materials should be linked through the official WFGY GitHub repository when released:

https://github.com/onestardao/WFGY

This package should be treated as a public evidence release. It is not the unreleased internal execution source.
