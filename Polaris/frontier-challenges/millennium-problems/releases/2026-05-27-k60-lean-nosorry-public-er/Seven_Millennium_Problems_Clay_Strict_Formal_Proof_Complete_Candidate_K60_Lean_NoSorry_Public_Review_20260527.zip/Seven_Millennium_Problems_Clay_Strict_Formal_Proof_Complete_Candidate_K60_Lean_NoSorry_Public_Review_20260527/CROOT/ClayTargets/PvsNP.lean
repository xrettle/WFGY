import CROOT.ClayTargets.Common

namespace CROOT

def pnpDomainCore : DomainCoreSignature :=
  {
    objectTag := "turing-machine-language-pair"
    operationTag := "polynomial-time-verification-map"
    invariantTag := "class-separation-obligation"
  }

def pnpTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.pnp "official-clay-statement-boundary"

theorem pnp_target_problem :
    pnpTargetContract.problem = ProblemId.pnp := by
  rfl

theorem pnp_target_shape_valid :
    targetContractShapeValid pnpTargetContract := by
  constructor <;> decide

end CROOT
