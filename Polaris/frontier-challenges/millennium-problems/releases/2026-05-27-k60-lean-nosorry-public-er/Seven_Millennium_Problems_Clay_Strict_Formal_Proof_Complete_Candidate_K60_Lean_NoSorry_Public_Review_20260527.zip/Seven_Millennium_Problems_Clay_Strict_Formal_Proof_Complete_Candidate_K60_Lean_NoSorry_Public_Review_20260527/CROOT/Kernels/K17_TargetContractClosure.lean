import CROOT.ClayTargets.Registry
import CROOT.Generators.SameRootProjection

namespace CROOT

def officialBoundaryTag : String :=
  "official-clay-statement-boundary"

def manualBoundaryProjection : List String :=
  clayTargetRegistry.map (fun c => c.boundaryTag)

def generatedBoundaryProjection : List String :=
  generatedTargets.map (fun c => c.boundaryTag)

def allTargetShapeValid : List FormalizationTargetContract → Prop
  | [] => True
  | c :: cs => targetContractShapeValid c /\ allTargetShapeValid cs

theorem manual_boundary_projection_official :
    manualBoundaryProjection = List.replicate 7 officialBoundaryTag := by
  rfl

theorem generated_boundary_projection_official :
    generatedBoundaryProjection = List.replicate 7 officialBoundaryTag := by
  simp [generatedBoundaryProjection, generatedTargets, generatedTargetFromRoot,
    rootedSpecs, rootedSpec, officialBoundaryTag]

theorem manual_registry_shape_valid :
    allTargetShapeValid clayTargetRegistry := by
  simp [allTargetShapeValid, clayTargetRegistry,
    pnp_target_shape_valid,
    rh_target_shape_valid,
    bsd_target_shape_valid,
    hodge_target_shape_valid,
    navier_stokes_target_shape_valid,
    yang_mills_target_shape_valid,
    poincare_target_shape_valid]

theorem generated_targets_eq_registry :
    generatedTargets = clayTargetRegistry := by
  rfl

theorem generated_registry_shape_valid :
    allTargetShapeValid generatedTargets := by
  simpa [generated_targets_eq_registry] using manual_registry_shape_valid

structure K17TargetContractClosure where
  manualBoundaryOfficial : manualBoundaryProjection = List.replicate 7 officialBoundaryTag
  generatedBoundaryOfficial : generatedBoundaryProjection = List.replicate 7 officialBoundaryTag
  manualShapeValid : allTargetShapeValid clayTargetRegistry
  generatedShapeValid : allTargetShapeValid generatedTargets

def k17_target_contract_closure : K17TargetContractClosure :=
{
  manualBoundaryOfficial := manual_boundary_projection_official,
  generatedBoundaryOfficial := generated_boundary_projection_official,
  manualShapeValid := manual_registry_shape_valid,
  generatedShapeValid := generated_registry_shape_valid
}

end CROOT
