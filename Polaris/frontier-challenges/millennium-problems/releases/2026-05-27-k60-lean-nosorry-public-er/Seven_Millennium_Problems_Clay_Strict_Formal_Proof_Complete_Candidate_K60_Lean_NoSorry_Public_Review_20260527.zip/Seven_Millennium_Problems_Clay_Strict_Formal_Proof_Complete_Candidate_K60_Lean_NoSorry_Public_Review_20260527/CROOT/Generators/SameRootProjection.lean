import CROOT.Root.SameRootKernel
import CROOT.ClayTargets.Common
import CROOT.ClayTargets.ObligationChain
import CROOT.ClayTargets.CompletionLane
import CROOT.ClayTargets.PrototypeTheoremLane
import CROOT.ClayTargets.TheoremTermRefinement

namespace CROOT

def generatedTargetFromRoot (rp : RootedProblem) : FormalizationTargetContract :=
  {
    problem := rp.spec.id,
    statementTag := rp.spec.statementTag,
    domainTag := rp.spec.domainTag,
    boundaryTag := "official-clay-statement-boundary"
  }

def generatedObligationFromRoot (rp : RootedProblem) : TheoremObligation :=
  {
    problem := rp.spec.id,
    statementTag := rp.spec.statementTag,
    returnLock := ReturnLockStatus.locked,
    adapterDecision := ImportDecision.allowed,
    debtStatus := TheoremDebtStatus.openDebt
  }

def generatedCompletionLaneFromRoot (rp : RootedProblem) : ProblemCompletionLane :=
  {
    problem := rp.spec.id,
    milestones := canonicalMilestones
  }

def generatedTarget (p : ProblemId) : FormalizationTargetContract :=
  generatedTargetFromRoot (rootedSpec p)

def generatedObligation (p : ProblemId) : TheoremObligation :=
  generatedObligationFromRoot (rootedSpec p)

def generatedCompletionLane (p : ProblemId) : ProblemCompletionLane :=
  generatedCompletionLaneFromRoot (rootedSpec p)

def generatedTargets : List FormalizationTargetContract :=
  rootedSpecs.map generatedTargetFromRoot

def generatedObligations : List TheoremObligation :=
  rootedSpecs.map generatedObligationFromRoot

def generatedCompletionLanes : List ProblemCompletionLane :=
  rootedSpecs.map generatedCompletionLaneFromRoot

theorem generated_target_problem_alignment (p : ProblemId) :
    (generatedTarget p).problem = p := by
  cases p <;> rfl

theorem generated_obligation_problem_alignment (p : ProblemId) :
    (generatedObligation p).problem = p := by
  cases p <;> rfl

theorem generated_completion_lane_problem_alignment (p : ProblemId) :
    (generatedCompletionLane p).problem = p := by
  cases p <;> rfl

theorem generated_targets_length : generatedTargets.length = 7 := by
  simp [generatedTargets, rootedSpecs]

theorem generated_obligations_length : generatedObligations.length = 7 := by
  simp [generatedObligations, rootedSpecs]

theorem generated_completion_lanes_length : generatedCompletionLanes.length = 7 := by
  simp [generatedCompletionLanes, rootedSpecs]

def generatedPrototypePair : List PrototypeTheoremLane :=
  [ {
      problem := ProblemId.pnp,
      target := generatedTarget ProblemId.pnp,
      completionLane := generatedCompletionLane ProblemId.pnp,
      statusTrace := canonicalPrototypeStatuses
    },
    {
      problem := ProblemId.rh,
      target := generatedTarget ProblemId.rh,
      completionLane := generatedCompletionLane ProblemId.rh,
      statusTrace := canonicalPrototypeStatuses
    } ]

theorem generated_prototype_pair_length : generatedPrototypePair.length = 2 := by
  rfl

def generatedPrototypeLaneFromRoot (rp : RootedProblem) : PrototypeTheoremLane :=
  {
    problem := rp.spec.id,
    target := generatedTargetFromRoot rp,
    completionLane := generatedCompletionLaneFromRoot rp,
    statusTrace := canonicalPrototypeStatuses
  }

def generatedFullPrototypeLanes : List PrototypeTheoremLane :=
  rootedSpecs.map generatedPrototypeLaneFromRoot

theorem generated_full_prototype_lanes_length : generatedFullPrototypeLanes.length = 7 := by
  simp [generatedFullPrototypeLanes, rootedSpecs]

def generatedRefinementLaneFromRoot (rp : RootedProblem) : TheoremTermRefinementLane :=
  {
    problem := rp.spec.id,
    prototype := generatedPrototypeLaneFromRoot rp,
    steps := canonicalRefinementSteps
  }

def generatedFullRefinementLanes : List TheoremTermRefinementLane :=
  rootedSpecs.map generatedRefinementLaneFromRoot

theorem generated_full_refinement_lanes_length : generatedFullRefinementLanes.length = 7 := by
  simp [generatedFullRefinementLanes, rootedSpecs]

end CROOT
