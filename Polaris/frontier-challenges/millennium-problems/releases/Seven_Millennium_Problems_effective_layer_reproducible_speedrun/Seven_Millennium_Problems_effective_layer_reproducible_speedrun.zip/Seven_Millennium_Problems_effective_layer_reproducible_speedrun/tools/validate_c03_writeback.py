#!/usr/bin/env python3
"""
C03 Original Theorem Writeback Validator.

This validator checks that the package contains the C03 writeback compiler outputs
and that every Millennium Problem lane has both:
1) an effective-layer answer, and
2) an original-native writeback answer.

ASCII-safe source file.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Tuple

REQUIRED_PROBLEM_FILES = [
    "00_OFFICIAL_STATEMENT.md",
    "01_CLAUSE_MAP.tsv",
    "02_LEDGER_TO_PROOF_ROUTE_MAP.tsv",
    "03A_EFFECTIVE_LAYER_ANSWER.md",
    "03B_ORIGINAL_NATIVE_WRITEBACK_ANSWER.md",
    "04_NATIVE_THEOREM_TARGET.lean",
    "05_WRITEBACK_VALIDATOR_REPORT.json",
]

REQUIRED_GLOBAL_FILES = [
    "README.md",
    "C03_ORIGINAL_THEOREM_WRITEBACK_COMPILER_SPEC.md",
    "C03_WRITEBACK_VALIDATOR_SPEC.md",
    "ALL7_OFFICIAL_STATEMENT_CLAUSE_MAP.tsv",
    "ALL7_WRITEBACK_COVERAGE_MATRIX.tsv",
    "ALL7_WRITEBACK_VALIDATOR_REPORT.json",
    "ALL7_FINAL_ANSWER_INDEX.tsv",
]

EXPECTED_PROBLEMS = ["PNP", "RH", "BSD", "HODGE", "NS", "YM", "PC"]


def find_c03(root: Path) -> Path | None:
    direct = root / "09_ORIGINAL_THEOREM_WRITEBACK_COMPILER"
    if direct.exists():
        return direct
    for p in root.rglob("09_ORIGINAL_THEOREM_WRITEBACK_COMPILER"):
        if p.is_dir():
            return p
    return None


def load_json(path: Path) -> Dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def validate_problem(pdir: Path, pid: str) -> Tuple[bool, List[str]]:
    failures: List[str] = []
    for filename in REQUIRED_PROBLEM_FILES:
        if not (pdir / filename).exists():
            failures.append("missing_" + filename)
    report = load_json(pdir / "05_WRITEBACK_VALIDATOR_REPORT.json")
    checks = {
        "official_statement_locked": True,
        "unmapped_ledger_obligations": 0,
        "unmapped_official_statement_clauses": 0,
        "theorem_debt_after_writeback": 0,
        "effective_answer_rendered": True,
        "native_original_answer_rendered": True,
        "native_theorem_target_rendered": True,
        "no_theorem_drift_detected": True,
        "writeback_trace_complete": True,
        "writeback_status": "PASS",
    }
    for key, expected in checks.items():
        if report.get(key) != expected:
            failures.append(f"{key}_expected_{expected}_got_{report.get(key)}")
    if str(report.get("official_statement_clause_coverage")) != "100%":
        failures.append("official_statement_clause_coverage_not_100_percent")
    return (not failures), failures


def run(root: Path) -> int:
    c03 = find_c03(root)
    if c03 is None:
        print("C03_WRITEBACK_VALIDATOR_RESULT: CHECK_REQUIRED")
        print("reason: missing 09_ORIGINAL_THEOREM_WRITEBACK_COMPILER")
        return 1

    failures: List[str] = []
    for filename in REQUIRED_GLOBAL_FILES:
        if not (c03 / filename).exists():
            failures.append("missing_global_" + filename)

    problem_results = []
    for pid in EXPECTED_PROBLEMS:
        pdir = c03 / pid
        if not pdir.exists():
            problem_results.append((pid, False, ["missing_problem_folder"]))
            failures.append(pid + "_missing_problem_folder")
            continue
        ok, pfail = validate_problem(pdir, pid)
        problem_results.append((pid, ok, pfail))
        if not ok:
            failures.extend([pid + "_" + x for x in pfail])

    global_report = load_json(c03 / "ALL7_WRITEBACK_VALIDATOR_REPORT.json")
    if global_report.get("ALL7_C03_WRITEBACK_PASS") is not True:
        failures.append("ALL7_C03_WRITEBACK_PASS_not_true")
    if global_report.get("ALL7_original_theorem_writeback_debt") != 0:
        failures.append("ALL7_original_theorem_writeback_debt_not_zero")
    if global_report.get("ALL7_native_original_answer_rendered") is not True:
        failures.append("ALL7_native_original_answer_rendered_not_true")

    all_pass = not failures

    print("C03 Original Theorem Writeback Validator")
    print("C03 folder:", c03.relative_to(root) if c03.is_relative_to(root) else c03)
    for pid, ok, pfail in problem_results:
        status = "PASS" if ok else "CHECK_REQUIRED"
        print(f"{pid}: {status}" + ("" if ok else " | " + ",".join(pfail)))
    print("ALL7_C03_WRITEBACK_PASS:", str(all_pass).lower())
    print("ALL7_original_theorem_writeback_debt:", 0 if all_pass else "CHECK_REQUIRED")
    print("FINAL_STATUS:", "ORIGINAL_THEOREM_WRITEBACK_VALIDATED_ALL7_PASS" if all_pass else "CHECK_REQUIRED")
    return 0 if all_pass else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Package root directory after extraction.")
    args = parser.parse_args()
    return run(Path(args.root))


if __name__ == "__main__":
    raise SystemExit(main())
