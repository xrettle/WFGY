WFGY 5.0 Polaris Protocol

Repository: https://github.com/onestardao/WFGY

Branch: PP02C

Mini strict-schema preflight for Global Hard Veto Contract Matrix.
