import CROOT.Kernels.K1_ContentInvariance
import CROOT.Kernels.K2_NoConclusionImport
import CROOT.Kernels.K3_LedgerAdmissibility
import CROOT.Kernels.K4_ReturnExitDichotomy
import CROOT.Kernels.K5_SevenTrackInstantiation

namespace CROOT

structure KernelBundleVerified where
  k1_atom : ∀ a b : Atom, routeAtom a = Route.carrier b -> b = a
  k1_track : ∀ a b : Atom, routeAtom a = Route.carrier b -> b.track = a.track
  k1_boundary : ∀ a b : Atom, routeAtom a = Route.carrier b -> b.boundary = a.boundary
  k1_marker : ∀ a b : Atom, routeAtom a = Route.carrier b -> b.marker = a.marker
  k2_direct : decideImport ImportClass.directTarget = ImportDecision.blocked
  k2_solved : decideImport ImportClass.solvedRoute = ImportDecision.blocked
  k2_equiv : decideImport ImportClass.knownEquivalent = ImportDecision.blocked
  k2_unknown : decideImport ImportClass.unknownEquivalent = ImportDecision.escalated
  k3_merge : ∀ x y : LedgerEntry, mergeIfSameKey x y = x
  k4_unknown_exit : classifyBranch ResidualState.unknownEscalate = Branch.exitBranch
  k4_disjoint : Branch.returnBranch ≠ Branch.exitBranch
  k5_length : allTracks.length = 7
  k5_nodup : allTracks.Nodup
  k5_pnp : Track.PNP ∈ allTracks
  k5_rh : Track.RH ∈ allTracks
  k5_bsd : Track.BSD ∈ allTracks
  k5_hodge : Track.HODGE ∈ allTracks
  k5_ns : Track.NS ∈ allTracks
  k5_ym : Track.YM ∈ allTracks
  k5_pc : Track.PC ∈ allTracks

theorem kernel_bundle_verified : KernelBundleVerified :=
{
  k1_atom := K1_carrier_preserves_atom,
  k1_track := K1_carrier_preserves_track,
  k1_boundary := K1_carrier_preserves_boundary,
  k1_marker := K1_carrier_preserves_marker,
  k2_direct := K2_direct_blocked,
  k2_solved := K2_solved_blocked,
  k2_equiv := K2_equivalent_blocked,
  k2_unknown := K2_unknown_escalates,
  k3_merge := K3_merge_left,
  k4_unknown_exit := K4_unknown_exits,
  k4_disjoint := K4_return_exit_disjoint,
  k5_length := K5_allTracks_length,
  k5_nodup := K5_allTracks_nodup,
  k5_pnp := K5_PNP_mem,
  k5_rh := K5_RH_mem,
  k5_bsd := K5_BSD_mem,
  k5_hodge := K5_HODGE_mem,
  k5_ns := K5_NS_mem,
  k5_ym := K5_YM_mem,
  k5_pc := K5_PC_mem
}

end CROOT
