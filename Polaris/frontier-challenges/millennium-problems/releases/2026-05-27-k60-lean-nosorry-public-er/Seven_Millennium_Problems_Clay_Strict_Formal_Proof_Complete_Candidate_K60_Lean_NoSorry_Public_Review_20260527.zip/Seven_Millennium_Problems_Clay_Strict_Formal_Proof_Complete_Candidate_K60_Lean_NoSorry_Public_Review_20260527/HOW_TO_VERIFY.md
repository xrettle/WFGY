# How to Verify

Run these commands from the package root:

```bash
lake build
python3 scripts/no_sorry_scan.py
python3 scripts/check_verification_whitelist.py
python3 scripts/collect_build_report.py
```

Expected results:

- `lake build`: return code `0`.
- `no_sorry_scan.py`: `NO-SORRY SCAN PASS`.
- `check_verification_whitelist.py`: `cleanup_candidate_count = 0`.
- `collect_build_report.py`: build report includes K60 and creator-grade audit objects.

This environment may not include Lean/Lake. If Lean is unavailable, use the included build logs as supplied evidence and rerun the commands in a Lean-enabled environment.
