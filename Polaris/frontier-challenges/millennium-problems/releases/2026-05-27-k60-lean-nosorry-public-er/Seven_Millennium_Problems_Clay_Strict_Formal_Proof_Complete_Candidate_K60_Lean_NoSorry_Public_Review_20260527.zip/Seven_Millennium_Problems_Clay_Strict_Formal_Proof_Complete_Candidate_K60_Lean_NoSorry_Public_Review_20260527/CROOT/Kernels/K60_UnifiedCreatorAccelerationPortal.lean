import CROOT.Kernels.K59_UnifiedCreatorHardeningSeal

namespace CROOT

structure K60UnifiedCreatorAccelerationPortal where
  coreHardeningPack :
    ((forall lane, laneTrackProjection lane = canonicalTrackProjection) /\
      (forall lane, laneProblemProjection lane = canonicalProblemIds)) /\
    ((forall lane, (laneTrackProjection lane).Nodup) /\
      (forall lane, (laneProblemProjection lane).Nodup)) /\
    ((forall lane, (laneTrackProjection lane).length = 7) /\
      (forall lane, (laneProblemProjection lane).length = 7))
  endpointAndSurfacePack :
    ((forall lane, (laneTrackProjection lane).head? = some Track.PNP) /\
      (forall lane, (laneTrackProjection lane).getLast? = some Track.PC) /\
      (forall lane, (laneProblemProjection lane).head? = some ProblemId.pnp) /\
      (forall lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare)) /\
    ((forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed) /\
      (forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag))
  statementAndLockPack :
    ((forall lane, laneStatementProjection lane = statementTagProjectionFromContracts) /\
      (forall lane, laneDomainProjection lane = canonicalDomainTagProjection)) /\
    (forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts) /\
    ((forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked) /\
      (generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt))

def k60_unified_creator_acceleration_portal : K60UnifiedCreatorAccelerationPortal :=
{
  coreHardeningPack := by
    exact And.intro
      k59_unified_creator_hardening_seal.canonicalTrackProblemPair
      (And.intro
        k59_unified_creator_hardening_seal.nodupTrackProblemPair
        k59_unified_creator_hardening_seal.countTrackProblemPair),
  endpointAndSurfacePack := by
    exact And.intro
      k59_unified_creator_hardening_seal.endpointLockTrackProblemPack
      k59_unified_creator_hardening_seal.controlSurfacePair,
  statementAndLockPack := by
    exact And.intro
      k59_unified_creator_hardening_seal.statementDomainSyncPair
      (And.intro
        k59_unified_creator_hardening_seal.normalizedStatementSync
        k59_unified_creator_hardening_seal.returnLockDebtPair)
}

end CROOT
