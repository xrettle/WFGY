import CROOT.Core.Types

namespace CROOT

inductive ProblemId where
  | pnp
  | rh
  | bsd
  | hodge
  | navierStokes
  | yangMills
  | poincare
  deriving DecidableEq, Repr

def problemTrackOf (p : ProblemId) : Track :=
  match p with
  | ProblemId.pnp => Track.PNP
  | ProblemId.rh => Track.RH
  | ProblemId.bsd => Track.BSD
  | ProblemId.hodge => Track.HODGE
  | ProblemId.navierStokes => Track.NS
  | ProblemId.yangMills => Track.YM
  | ProblemId.poincare => Track.PC

structure ProblemSpec where
  id : ProblemId
  track : Track
  statementTag : String
  domainTag : String
  deriving DecidableEq, Repr

def canonicalProblemIds : List ProblemId :=
  [ProblemId.pnp, ProblemId.rh, ProblemId.bsd, ProblemId.hodge, ProblemId.navierStokes, ProblemId.yangMills, ProblemId.poincare]

def canonicalSpec (p : ProblemId) : ProblemSpec :=
  match p with
  | ProblemId.pnp =>
      { id := p, track := Track.PNP, statementTag := "P_vs_NP_statement", domainTag := "complexity_theory_domain" }
  | ProblemId.rh =>
      { id := p, track := Track.RH, statementTag := "Riemann_hypothesis_statement", domainTag := "zeta_analytic_domain" }
  | ProblemId.bsd =>
      { id := p, track := Track.BSD, statementTag := "BSD_statement", domainTag := "elliptic_curve_domain" }
  | ProblemId.hodge =>
      { id := p, track := Track.HODGE, statementTag := "Hodge_conjecture_statement", domainTag := "algebraic_geometry_domain" }
  | ProblemId.navierStokes =>
      { id := p, track := Track.NS, statementTag := "Navier_Stokes_statement", domainTag := "pde_solution_domain" }
  | ProblemId.yangMills =>
      { id := p, track := Track.YM, statementTag := "Yang_Mills_mass_gap_statement", domainTag := "quantum_field_domain" }
  | ProblemId.poincare =>
      { id := p, track := Track.PC, statementTag := "Poincare_conjecture_statement", domainTag := "three_manifold_domain" }

def canonicalSpecs : List ProblemSpec :=
  [canonicalSpec ProblemId.pnp,
   canonicalSpec ProblemId.rh,
   canonicalSpec ProblemId.bsd,
   canonicalSpec ProblemId.hodge,
   canonicalSpec ProblemId.navierStokes,
   canonicalSpec ProblemId.yangMills,
   canonicalSpec ProblemId.poincare]

theorem canonical_problem_ids_length : canonicalProblemIds.length = 7 := by
  rfl

theorem canonical_problem_ids_nodup : canonicalProblemIds.Nodup := by
  decide

theorem canonical_specs_length : canonicalSpecs.length = 7 := by
  rfl

theorem problem_track_alignment (p : ProblemId) :
    (canonicalSpec p).track = problemTrackOf p := by
  cases p <;> rfl

end CROOT
