import CROOT.Adapters.StatementEquivalenceBridge
import CROOT.Core.ProblemSpec

namespace CROOT

def statementContractProblemProjection : List ProblemId :=
  canonicalStatementContracts.map (fun c => c.problem)

def statementContractReturnLockProjection : List ReturnLockStatus :=
  canonicalStatementContracts.map (fun c => c.returnLockStatus)

def statementContractObligationProjection : List EquivalenceObligationStatus :=
  canonicalStatementContracts.map (fun c => c.obligationStatus)

def statementContractDecisionProjection : List ImportDecision :=
  canonicalStatementContracts.map (fun c => c.adapterDecision)

theorem statement_contract_problem_projection_eq_canonical :
    statementContractProblemProjection = canonicalProblemIds := by
  rfl

theorem statement_contract_return_lock_all_locked :
    statementContractReturnLockProjection = List.replicate 7 ReturnLockStatus.locked := by
  rfl

theorem statement_contract_obligation_all_pending :
    statementContractObligationProjection = List.replicate 7 EquivalenceObligationStatus.pendingProof := by
  rfl

theorem statement_contract_decision_all_allowed :
    statementContractDecisionProjection = List.replicate 7 ImportDecision.allowed := by
  rfl

structure K18StatementEquivalenceHardLock where
  contractCount : canonicalStatementContracts.length = 7
  problemProjection : statementContractProblemProjection = canonicalProblemIds
  returnLocks : statementContractReturnLockProjection = List.replicate 7 ReturnLockStatus.locked
  obligations : statementContractObligationProjection = List.replicate 7 EquivalenceObligationStatus.pendingProof
  adapterDecisions : statementContractDecisionProjection = List.replicate 7 ImportDecision.allowed

def k18_statement_equivalence_hard_lock : K18StatementEquivalenceHardLock :=
{
  contractCount := canonical_statement_contracts_length,
  problemProjection := statement_contract_problem_projection_eq_canonical,
  returnLocks := statement_contract_return_lock_all_locked,
  obligations := statement_contract_obligation_all_pending,
  adapterDecisions := statement_contract_decision_all_allowed
}

end CROOT
