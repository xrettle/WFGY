import CROOT.ClayTargets.TheoremTermRefinement

namespace CROOT

structure K15TheoremTermRefinementReadiness where
  refinementCount : fullRefinementLanes.length = 7
  pnpRefined : refinementLaneShapeValid (refinementLaneFromPrototype pnpPrototypeTheoremLane)
  rhRefined : refinementLaneShapeValid (refinementLaneFromPrototype rhPrototypeTheoremLane)
  bsdRefined : refinementLaneShapeValid (refinementLaneFromPrototype bsdPrototypeTheoremLane)
  hodgeRefined : refinementLaneShapeValid (refinementLaneFromPrototype hodgePrototypeTheoremLane)
  nsRefined : refinementLaneShapeValid (refinementLaneFromPrototype nsPrototypeTheoremLane)
  ymRefined : refinementLaneShapeValid (refinementLaneFromPrototype ymPrototypeTheoremLane)
  pcRefined : refinementLaneShapeValid (refinementLaneFromPrototype pcPrototypeTheoremLane)

theorem k15_theorem_term_refinement_readiness : K15TheoremTermRefinementReadiness :=
{
  refinementCount := full_refinement_lanes_length,
  pnpRefined := refinement_lane_shape_valid pnpPrototypeTheoremLane,
  rhRefined := refinement_lane_shape_valid rhPrototypeTheoremLane,
  bsdRefined := refinement_lane_shape_valid bsdPrototypeTheoremLane,
  hodgeRefined := refinement_lane_shape_valid hodgePrototypeTheoremLane,
  nsRefined := refinement_lane_shape_valid nsPrototypeTheoremLane,
  ymRefined := refinement_lane_shape_valid ymPrototypeTheoremLane,
  pcRefined := refinement_lane_shape_valid pcPrototypeTheoremLane
}

end CROOT
