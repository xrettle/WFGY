import CROOT.Core.ProblemSpec

namespace CROOT

structure K6ProblemSpecCoverage where
  exactSevenProblemIds : canonicalProblemIds.length = 7
  exactSevenSpecs : canonicalSpecs.length = 7
  nodupProblemIds : canonicalProblemIds.Nodup
  pnpAligned : problemTrackOf ProblemId.pnp = Track.PNP
  rhAligned : problemTrackOf ProblemId.rh = Track.RH
  bsdAligned : problemTrackOf ProblemId.bsd = Track.BSD
  hodgeAligned : problemTrackOf ProblemId.hodge = Track.HODGE
  nsAligned : problemTrackOf ProblemId.navierStokes = Track.NS
  ymAligned : problemTrackOf ProblemId.yangMills = Track.YM
  pcAligned : problemTrackOf ProblemId.poincare = Track.PC

theorem k6_problem_spec_coverage : K6ProblemSpecCoverage :=
{
  exactSevenProblemIds := canonical_problem_ids_length,
  exactSevenSpecs := canonical_specs_length,
  nodupProblemIds := canonical_problem_ids_nodup,
  pnpAligned := by rfl,
  rhAligned := by rfl,
  bsdAligned := by rfl,
  hodgeAligned := by rfl,
  nsAligned := by rfl,
  ymAligned := by rfl,
  pcAligned := by rfl
}

end CROOT
