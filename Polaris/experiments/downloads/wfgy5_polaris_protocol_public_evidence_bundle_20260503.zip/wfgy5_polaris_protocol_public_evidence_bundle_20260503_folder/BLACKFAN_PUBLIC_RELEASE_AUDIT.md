# Blackfan Public Release Audit

This audit checks the public evidence release boundary.

| Branch | Public files | Deleted notebook/core items | Nested zips expanded | Contains .ipynb | Contains nested .zip |
|---|---:|---:|---:|---|---|
| PP01 | 31 | 0 | 0 | False | False |
| PP02A | 48 | 2 | 3 | False | False |
| PP02B | 630 | 0 | 0 | False | False |
| PP02C | 105 | 5 | 6 | False | False |

Result: no public package contains execution notebooks. Nested zips were expanded or filtered. Raw outputs were preserved.
