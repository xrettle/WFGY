import CROOT.Kernels.K56_UnifiedDualProjectionBridge

namespace CROOT

structure K57UnifiedAuditFastpathSeal where
  trackCanonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection
  problemCanonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds
  trackNodup :
    forall lane, (laneTrackProjection lane).Nodup
  problemNodup :
    forall lane, (laneProblemProjection lane).Nodup
  trackCountSeven :
    forall lane, (laneTrackProjection lane).length = 7
  problemCountSeven :
    forall lane, (laneProblemProjection lane).length = 7
  statementSync :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  domainSync :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  normalizedStatementSync :
    forall lane, laneNormalizedStatementProjection lane = adapterTagProjectionFromContracts
  returnLockAllLocked :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  debtAllOpen :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k57_unified_audit_fastpath_seal : K57UnifiedAuditFastpathSeal :=
{
  trackCanonical := k56_unified_dual_projection_bridge.canonicalTrackProblemPair.left,
  problemCanonical := k56_unified_dual_projection_bridge.canonicalTrackProblemPair.right,
  trackNodup := k56_unified_dual_projection_bridge.dualNodup.left,
  problemNodup := k56_unified_dual_projection_bridge.dualNodup.right,
  trackCountSeven := k56_unified_dual_projection_bridge.dualCountSeven.left,
  problemCountSeven := k56_unified_dual_projection_bridge.dualCountSeven.right,
  statementSync := k56_unified_dual_projection_bridge.statementDomainSync.left,
  domainSync := k56_unified_dual_projection_bridge.statementDomainSync.right,
  normalizedStatementSync := k56_unified_dual_projection_bridge.normalizedStatementSync,
  returnLockAllLocked := k56_unified_dual_projection_bridge.returnLockAndDebt.left,
  debtAllOpen := k56_unified_dual_projection_bridge.returnLockAndDebt.right
}

end CROOT
