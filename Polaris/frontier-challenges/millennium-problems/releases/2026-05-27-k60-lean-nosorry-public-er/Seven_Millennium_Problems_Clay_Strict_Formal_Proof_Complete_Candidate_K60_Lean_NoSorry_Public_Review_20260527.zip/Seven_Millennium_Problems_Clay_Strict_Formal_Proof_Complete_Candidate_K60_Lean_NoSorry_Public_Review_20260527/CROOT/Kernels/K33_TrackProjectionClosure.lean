import CROOT.Kernels.K32_DomainProjectionClosure
import CROOT.Kernels.K5_SevenTrackInstantiation

namespace CROOT

def canonicalTrackProjection : List Track :=
  canonicalProblemIds.map problemTrackOf

def sourceFieldTrackProjection : List Track :=
  rootedSpecs.map (fun rp => rp.spec.track)

def manualTrackProjection : List Track :=
  clayTargetRegistry.map (fun c => problemTrackOf c.problem)

def generatedTrackProjection : List Track :=
  generatedTargets.map (fun c => problemTrackOf c.problem)

theorem canonical_track_projection_eq_all_tracks :
    canonicalTrackProjection = allTracks := by
  simpa [canonicalTrackProjection, canonicalProblemIds, problemTrackOf, allTracks]

theorem source_field_track_projection_eq_all_tracks :
    sourceFieldTrackProjection = allTracks := by
  simpa [sourceFieldTrackProjection, rootedSpecs, rootedSpec, canonicalSpec, allTracks]

theorem manual_track_projection_eq_all_tracks :
    manualTrackProjection = allTracks := by
  native_decide

theorem generated_track_projection_eq_all_tracks :
    generatedTrackProjection = allTracks := by
  native_decide

theorem source_field_track_projection_eq_canonical :
    sourceFieldTrackProjection = canonicalTrackProjection := by
  calc
    sourceFieldTrackProjection = allTracks := source_field_track_projection_eq_all_tracks
    _ = canonicalTrackProjection := by
      symm
      exact canonical_track_projection_eq_all_tracks

theorem manual_track_projection_eq_canonical :
    manualTrackProjection = canonicalTrackProjection := by
  calc
    manualTrackProjection = allTracks := manual_track_projection_eq_all_tracks
    _ = canonicalTrackProjection := by
      symm
      exact canonical_track_projection_eq_all_tracks

theorem generated_track_projection_eq_canonical :
    generatedTrackProjection = canonicalTrackProjection := by
  calc
    generatedTrackProjection = allTracks := generated_track_projection_eq_all_tracks
    _ = canonicalTrackProjection := by
      symm
      exact canonical_track_projection_eq_all_tracks

theorem canonical_track_projection_length :
    canonicalTrackProjection.length = 7 := by
  simpa [canonical_track_projection_eq_all_tracks] using K5_allTracks_length

theorem canonical_track_projection_nodup :
    canonicalTrackProjection.Nodup := by
  simpa [canonical_track_projection_eq_all_tracks] using K5_allTracks_nodup

structure K33TrackProjectionClosure where
  canonicalEqAllTracks : canonicalTrackProjection = allTracks
  sourceFieldEqAllTracks : sourceFieldTrackProjection = allTracks
  manualEqAllTracks : manualTrackProjection = allTracks
  generatedEqAllTracks : generatedTrackProjection = allTracks
  sourceFieldEqCanonical : sourceFieldTrackProjection = canonicalTrackProjection
  manualEqCanonical : manualTrackProjection = canonicalTrackProjection
  generatedEqCanonical : generatedTrackProjection = canonicalTrackProjection
  canonicalLength : canonicalTrackProjection.length = 7
  canonicalNodup : canonicalTrackProjection.Nodup

def k33_track_projection_closure : K33TrackProjectionClosure :=
{
  canonicalEqAllTracks := canonical_track_projection_eq_all_tracks,
  sourceFieldEqAllTracks := source_field_track_projection_eq_all_tracks,
  manualEqAllTracks := manual_track_projection_eq_all_tracks,
  generatedEqAllTracks := generated_track_projection_eq_all_tracks,
  sourceFieldEqCanonical := source_field_track_projection_eq_canonical,
  manualEqCanonical := manual_track_projection_eq_canonical,
  generatedEqCanonical := generated_track_projection_eq_canonical,
  canonicalLength := canonical_track_projection_length,
  canonicalNodup := canonical_track_projection_nodup
}

end CROOT
