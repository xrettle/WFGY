import CROOT.ClayTargets.PrototypeTheoremLane

namespace CROOT

inductive TheoremTermStep where
  | bindOfficialStatement
  | bindDomainCore
  | bindReductionBridge
  | bindCounterexampleFilter
  | bindReturnLock
  | bindFinalTermInterface
  deriving DecidableEq, Repr

structure TheoremTermRefinementLane where
  problem : ProblemId
  prototype : PrototypeTheoremLane
  steps : List TheoremTermStep
  deriving DecidableEq, Repr

def canonicalRefinementSteps : List TheoremTermStep :=
  [TheoremTermStep.bindOfficialStatement,
   TheoremTermStep.bindDomainCore,
   TheoremTermStep.bindReductionBridge,
   TheoremTermStep.bindCounterexampleFilter,
   TheoremTermStep.bindReturnLock,
   TheoremTermStep.bindFinalTermInterface]

def refinementLaneFromPrototype (lane : PrototypeTheoremLane) : TheoremTermRefinementLane :=
  {
    problem := lane.problem,
    prototype := lane,
    steps := canonicalRefinementSteps
  }

def fullRefinementLanes : List TheoremTermRefinementLane :=
  fullPrototypeLanes.map refinementLaneFromPrototype

def refinementLaneShapeValid (lane : TheoremTermRefinementLane) : Prop :=
  lane.steps.length = 6 /\
  lane.steps.Nodup

theorem canonical_refinement_steps_length : canonicalRefinementSteps.length = 6 := by
  rfl

theorem canonical_refinement_steps_nodup : canonicalRefinementSteps.Nodup := by
  decide

theorem refinement_lane_shape_valid (lane : PrototypeTheoremLane) :
    refinementLaneShapeValid (refinementLaneFromPrototype lane) := by
  constructor
  · exact canonical_refinement_steps_length
  · exact canonical_refinement_steps_nodup

theorem full_refinement_lanes_length : fullRefinementLanes.length = 7 := by
  simpa [fullRefinementLanes] using full_prototype_lanes_length

theorem refinement_lane_problem_alignment (lane : PrototypeTheoremLane) :
    (refinementLaneFromPrototype lane).problem = lane.problem := by
  rfl

end CROOT
