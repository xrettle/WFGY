# ZAI Alignment and Limits

## Short verdict

This PP02D_B v1.1 handoff is **highly aligned with ZAI's methodology concerns** and is stricter than the minimum he suggested in several audit dimensions.

It does **not** yet satisfy the separate external-benchmark suggestion of running Natural Questions or HotpotQA, because this package is a synthetic certificate-hardcase benchmark.

## Alignment table

| ZAI concern | What we did | Status |
|---|---|---|
| Do not only trust clean structure | We ran real API hardcases and kept raw outputs, parser records, scorer trace, hashes | PASS |
| Check whether the model actually answers wrong | V1 and V3 failures exposed concrete model failure modes before final | PASS |
| Try 20–30 cases before scaling | V5 ran 24 API calls before final 216 | PASS |
| Avoid JSON template echo / fake pass | Parser V6 allows only exact 3-field JSON, no rescue, no enum normalization, no fallback repair | PASS |
| Do not waste API before small pass | We escalated 8 → 24 → 216 only after GREEN gates | PASS |
| Final bounded evidence | Final 216 passed 216/216, 54/54, 108/108, 108/108 | PASS |
| Real QA datasets like NQ / HotpotQA | Not included in this B package | LIMIT |

## Are we stricter than ZAI expected?

In audit strictness: **yes**.

We add:
- exact certificate scoring,
- exact arena valid-set scoring,
- strict parser no-rescue,
- semantic fallback = 0,
- transport ledger,
- raw outputs,
- hash manifest,
- valid/invalid balance,
- bucket coverage,
- family coverage.

In dataset realism: **not yet**.

ZAI mentioned true QA datasets such as Natural Questions or HotpotQA. This package does not claim that. A future adapter could translate the same audit discipline to a real-QA benchmark, but that is a separate package.

## Recommended wording

Allowed:

> This is stronger than a simple 20–30-case smoke test in terms of audit controls and hardcase coverage, and it passed the bounded PP02D_B 216-call synthetic certificate benchmark.

Avoid:

> This proves performance on Natural Questions / HotpotQA.

