#!/usr/bin/env python3
from pathlib import Path
import json, re

ROOT = Path(__file__).resolve().parents[1]
logs = ROOT / "build_logs"

def read(name):
    p = logs / name
    return p.read_text(encoding="utf-8", errors="ignore") if p.exists() else ""

failed_at_raw = read("FAILED_AT.txt").strip() or "UNKNOWN"
failed_at = failed_at_raw.replace("FAILED_AT=", "")
combined = "\n".join([
    read("stage1_smoke.log"),
    read("stage2_seal.log"),
    read("stage3_buildfirst.log"),
    read("stage4_audit.log"),
    read("lake_build.log"),
    read("no_sorry_scan.log"),
])

patterns = [
    ("unknown_module", r"unknown module|unknown package|no such file|file .* not found"),
    ("unknown_identifier", r"unknown identifier|Unknown identifier"),
    ("type_mismatch", r"type mismatch|application type mismatch"),
    ("unsolved_goals", r"unsolved goals"),
    ("simp_fail", r"simp made no progress|simp failed"),
    ("decide_fail", r"failed to synthesize|Decidable|decide"),
    ("projection", r"invalid field|unknown field|projection"),
    ("forbidden_token", r"\b(sorry|admit|axiom|constant)\b"),
]

hits = []
if failed_at != "NONE":
    for label, pat in patterns:
        if re.search(pat, combined, re.IGNORECASE):
            hits.append(label)

router = {
    "stage1_smoke": "Repair Core Types/Guards/Ledger first.",
    "stage2_seal": "Repair KernelBundle/SevenTracks/Seal field names and imports.",
    "stage3_buildfirst": "Repair BuildFirst object projection/alias only.",
    "stage4_audit": "Repair Audit proof-object projections only.",
    "lake_build": "Repair lakefile/root imports/module names/toolchain.",
    "no_sorry_scan": "Remove forbidden token or scanner false positive.",
    "NONE": "Issue final machine-check step1 seal package.",
    "UNKNOWN": "Return complete logs; cannot safely infer."
}

report = {
    "failed_at": failed_at_raw,
    "detected_error_classes": hits,
    "recommended_action": router.get(failed_at, "Return logs."),
    "claim_ceiling": "K1-K5 framework + seven-track instantiation only"
}

out = ROOT / "TRIAGE_REPORT.json"
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
