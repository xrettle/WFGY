import CROOT.Kernels.K21_SourceFieldFirstPrincipleAlignment

namespace CROOT

def rootTokenProjection : List SameRootToken :=
  rootedSpecs.map (fun rp => rp.root)

theorem root_token_projection_uniform :
    rootTokenProjection = List.replicate 7 canonicalSameRootToken := by
  simp [rootTokenProjection, rootedSpecs, rootedSpec]

theorem root_token_projection_count :
    rootTokenProjection.length = 7 := by
  simp [rootTokenProjection, rootedSpecs]

structure K22RootTokenProjectionClosure where
  uniformRootToken : rootTokenProjection = List.replicate 7 canonicalSameRootToken
  projectionCount : rootTokenProjection.length = 7

def k22_root_token_projection_closure : K22RootTokenProjectionClosure :=
{
  uniformRootToken := root_token_projection_uniform,
  projectionCount := root_token_projection_count
}

end CROOT
