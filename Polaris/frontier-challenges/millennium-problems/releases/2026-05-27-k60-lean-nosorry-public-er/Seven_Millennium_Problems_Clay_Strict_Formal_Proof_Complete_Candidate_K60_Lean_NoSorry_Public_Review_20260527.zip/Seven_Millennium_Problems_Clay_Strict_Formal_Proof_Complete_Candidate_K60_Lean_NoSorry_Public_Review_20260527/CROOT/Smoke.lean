import CROOT.Core.Types
import CROOT.Core.Guards
import CROOT.Core.Ledger
import CROOT.Kernels.K2_NoConclusionImport
import CROOT.Kernels.K5_SevenTrackInstantiation

namespace CROOT

theorem smoke_tracks_length : allTracks.length = 7 := by
  rfl

theorem smoke_import_decision :
    isConclusionMarker Marker.conclusionLike = true := by
  rfl

theorem smoke_nodup : allTracks.Nodup := by
  decide

theorem smoke_k2 : decideImport ImportClass.directTarget = ImportDecision.blocked := by
  rfl

end CROOT
