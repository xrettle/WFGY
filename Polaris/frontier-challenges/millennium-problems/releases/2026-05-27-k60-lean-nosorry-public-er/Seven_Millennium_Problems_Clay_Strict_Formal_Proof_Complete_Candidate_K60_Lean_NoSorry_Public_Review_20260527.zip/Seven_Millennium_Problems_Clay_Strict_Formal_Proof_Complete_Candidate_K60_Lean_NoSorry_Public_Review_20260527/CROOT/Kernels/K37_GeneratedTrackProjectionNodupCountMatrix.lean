import CROOT.Kernels.K36_GeneratedTrackEndpointLockMatrix

namespace CROOT

theorem generated_obligation_track_projection_length :
    generatedObligationTrackProjection.length = 7 := by
  calc
    generatedObligationTrackProjection.length = canonicalTrackProjection.length := by
      simpa [generated_obligation_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem generated_completion_track_projection_length :
    generatedCompletionTrackProjection.length = 7 := by
  calc
    generatedCompletionTrackProjection.length = canonicalTrackProjection.length := by
      simpa [generated_completion_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem generated_prototype_track_projection_length :
    generatedPrototypeTrackProjection.length = 7 := by
  calc
    generatedPrototypeTrackProjection.length = canonicalTrackProjection.length := by
      simpa [generated_prototype_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem generated_refinement_track_projection_length :
    generatedRefinementTrackProjection.length = 7 := by
  calc
    generatedRefinementTrackProjection.length = canonicalTrackProjection.length := by
      simpa [generated_refinement_track_projection_eq_canonical]
    _ = 7 := canonical_track_projection_length

theorem generated_obligation_track_projection_nodup :
    generatedObligationTrackProjection.Nodup := by
  simpa [generated_obligation_track_projection_eq_canonical] using canonical_track_projection_nodup

theorem generated_completion_track_projection_nodup :
    generatedCompletionTrackProjection.Nodup := by
  simpa [generated_completion_track_projection_eq_canonical] using canonical_track_projection_nodup

theorem generated_prototype_track_projection_nodup :
    generatedPrototypeTrackProjection.Nodup := by
  simpa [generated_prototype_track_projection_eq_canonical] using canonical_track_projection_nodup

theorem generated_refinement_track_projection_nodup :
    generatedRefinementTrackProjection.Nodup := by
  simpa [generated_refinement_track_projection_eq_canonical] using canonical_track_projection_nodup

structure K37GeneratedTrackProjectionNodupCountMatrix where
  obligationCount : generatedObligationTrackProjection.length = 7
  completionCount : generatedCompletionTrackProjection.length = 7
  prototypeCount : generatedPrototypeTrackProjection.length = 7
  refinementCount : generatedRefinementTrackProjection.length = 7
  obligationNodup : generatedObligationTrackProjection.Nodup
  completionNodup : generatedCompletionTrackProjection.Nodup
  prototypeNodup : generatedPrototypeTrackProjection.Nodup
  refinementNodup : generatedRefinementTrackProjection.Nodup

def k37_generated_track_projection_nodup_count_matrix :
    K37GeneratedTrackProjectionNodupCountMatrix :=
{
  obligationCount := generated_obligation_track_projection_length,
  completionCount := generated_completion_track_projection_length,
  prototypeCount := generated_prototype_track_projection_length,
  refinementCount := generated_refinement_track_projection_length,
  obligationNodup := generated_obligation_track_projection_nodup,
  completionNodup := generated_completion_track_projection_nodup,
  prototypeNodup := generated_prototype_track_projection_nodup,
  refinementNodup := generated_refinement_track_projection_nodup
}

end CROOT
