# WFGY 5.0 Polaris Protocol
## PP02A T4 120 Case Public Evidence Package

Repository:
https://github.com/onestardao/WFGY

License:
MIT License, unless a specific file states otherwise.

## Experiment overview

Branch: PP02A

Experiment type: T4 evidence branch with universe champagne review criteria

Case count: 120

PP02A focuses on a 120 case T4 evidence branch with strict public evidence review. It preserves raw outputs, parsed outputs, judge rows, case level signals, domain summaries, parser failure tables, public summaries, and prior near pass reference artifacts.

## What this public package includes

This public evidence package preserves the result artifacts needed for inspection and review:

1. raw model outputs
2. parsed outputs
3. case level verdicts
4. family, layer, or stage level verdicts where available
5. token accounting
6. audit tables
7. leakage or warning checks where available
8. final result summaries
9. SHA256 manifests
10. reproducibility notes

## What this public package excludes

Execution notebooks and unreleased core mathematical source files are intentionally excluded from this public evidence package.

The purpose of this release is to provide public evidence, result transparency, and reproducibility context without exposing unreleased implementation internals.

## Reproducibility

The experiment is designed for Colab based reproduction.

Execution notebooks are intentionally not embedded in this public evidence package. Public Colab reproduction materials will be referenced through the official WFGY GitHub repository when released:

https://github.com/onestardao/WFGY

The files in this package are sufficient for result inspection, audit review, hash verification, and public evidence checking.

## Claim boundary

This package is an evidence release, not a full implementation release.

It shows what was tested, what was produced, how outputs were parsed, how verdicts were assigned, and how the result artifacts can be inspected.

## Folder map

```text
00_README/
01_EXPERIMENT_OVERVIEW/
02_RAW_OUTPUTS/
03_PARSED_OUTPUTS/
04_VERDICTS_AND_METRICS/
05_AUDITS/
06_REPRODUCIBILITY/
07_HASHES_AND_MANIFEST/
08_REFERENCE_RESULTS/
```

## Integrity

Every public package includes a regenerated SHA256 manifest for file integrity verification.
