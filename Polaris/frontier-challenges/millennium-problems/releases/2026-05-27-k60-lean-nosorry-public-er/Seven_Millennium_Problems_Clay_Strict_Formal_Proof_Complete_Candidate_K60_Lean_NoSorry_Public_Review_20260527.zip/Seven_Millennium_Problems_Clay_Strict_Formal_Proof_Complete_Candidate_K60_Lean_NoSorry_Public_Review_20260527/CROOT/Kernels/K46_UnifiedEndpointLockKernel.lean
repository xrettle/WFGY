import CROOT.Kernels.K45_UnifiedSevenCountKernel

namespace CROOT

structure K46UnifiedEndpointLockKernel where
  trackLaneHeadLock :
    ∀ lane, (laneTrackProjection lane).head? = some Track.PNP
  trackLaneTailLock :
    ∀ lane, (laneTrackProjection lane).getLast? = some Track.PC
  problemLaneHeadLock :
    ∀ lane, (laneProblemProjection lane).head? = some ProblemId.pnp
  problemLaneTailLock :
    ∀ lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare

def k46_unified_endpoint_lock_kernel : K46UnifiedEndpointLockKernel :=
{
  trackLaneHeadLock := lane_track_projection_head_lock,
  trackLaneTailLock := lane_track_projection_tail_lock,
  problemLaneHeadLock := lane_problem_projection_head_lock,
  problemLaneTailLock := lane_problem_projection_tail_lock
}

end CROOT
