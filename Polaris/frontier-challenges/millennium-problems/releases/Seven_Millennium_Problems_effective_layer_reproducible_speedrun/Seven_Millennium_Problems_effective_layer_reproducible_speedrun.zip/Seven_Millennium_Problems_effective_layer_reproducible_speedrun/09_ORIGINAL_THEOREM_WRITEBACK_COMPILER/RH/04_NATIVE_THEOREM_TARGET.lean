-- C03 native theorem target stub for Riemann Hypothesis
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.RH

-- theorem target:
-- Every nontrivial zero of the Riemann zeta function has real part 1/2.

axiom native_theorem_target_RH : Prop

end WFGY.C03.RH
