import CROOT.Core.Types
import CROOT.Core.Guards

namespace CROOT

theorem K1_carrier_preserves_atom (a b : Atom) :
    routeAtom a = Route.carrier b -> b = a :=
  carrier_preserves_atom a b

theorem K1_carrier_preserves_boundary (a b : Atom) :
    routeAtom a = Route.carrier b -> b.boundary = a.boundary :=
  carrier_preserves_boundary a b

theorem K1_carrier_preserves_track (a b : Atom) :
    routeAtom a = Route.carrier b -> b.track = a.track :=
  carrier_preserves_track a b

theorem K1_carrier_preserves_marker (a b : Atom) :
    routeAtom a = Route.carrier b -> b.marker = a.marker :=
  carrier_preserves_marker a b

end CROOT
