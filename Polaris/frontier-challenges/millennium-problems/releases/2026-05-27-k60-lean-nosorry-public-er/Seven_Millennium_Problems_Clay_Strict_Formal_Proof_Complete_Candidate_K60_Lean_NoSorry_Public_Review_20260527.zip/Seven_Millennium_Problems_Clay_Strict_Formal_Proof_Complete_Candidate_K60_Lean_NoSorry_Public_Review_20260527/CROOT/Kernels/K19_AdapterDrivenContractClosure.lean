import CROOT.Kernels.K18_StatementEquivalenceHardLock

namespace CROOT

def adapterInputFromSpec (p : ProblemId) : StatementAdapterInput :=
  {
    problem := p
    sourceText := (canonicalSpec p).statementTag
    claimClass := ImportClass.safeBackground
  }

def adapterOutputFromSpec (p : ProblemId) : StatementAdapterOutput :=
  adaptStatement (adapterInputFromSpec p)

def adapterDrivenContract (p : ProblemId) : StatementEquivalenceContract :=
  {
    problem := p
    officialStatementTag := (canonicalSpec p).statementTag
    adapterStatementTag := (adapterOutputFromSpec p).normalizedText
    returnLockStatus := ReturnLockStatus.locked
    obligationStatus := EquivalenceObligationStatus.pendingProof
    adapterDecision := (adapterOutputFromSpec p).importDecision
  }

theorem adapter_output_problem_alignment (p : ProblemId) :
    (adapterOutputFromSpec p).problem = p := by
  simp [adapterOutputFromSpec, adapterInputFromSpec, adaptStatement]

theorem adapter_output_decision_allowed (p : ProblemId) :
    (adapterOutputFromSpec p).importDecision = ImportDecision.allowed := by
  simp [adapterOutputFromSpec, adapterInputFromSpec, adaptStatement, K2_safe_background_allowed]

theorem adapter_output_normalization_alignment (p : ProblemId) :
    (adapterOutputFromSpec p).normalizedText = normalizeStatementText (canonicalSpec p).statementTag := by
  simp [adapterOutputFromSpec, adapterInputFromSpec, adaptStatement]

theorem adapter_driven_contract_eq_canonical (p : ProblemId) :
    adapterDrivenContract p = canonicalStatementContract p := by
  simp [adapterDrivenContract, canonicalStatementContract, adapter_output_decision_allowed,
    adapter_output_normalization_alignment]

def adapterDrivenContracts : List StatementEquivalenceContract :=
  [adapterDrivenContract ProblemId.pnp,
   adapterDrivenContract ProblemId.rh,
   adapterDrivenContract ProblemId.bsd,
   adapterDrivenContract ProblemId.hodge,
   adapterDrivenContract ProblemId.navierStokes,
   adapterDrivenContract ProblemId.yangMills,
   adapterDrivenContract ProblemId.poincare]

theorem adapter_driven_contracts_length : adapterDrivenContracts.length = 7 := by
  rfl

theorem adapter_driven_contracts_eq_canonical :
    adapterDrivenContracts = canonicalStatementContracts := by
  simp [adapterDrivenContracts, canonicalStatementContracts, adapter_driven_contract_eq_canonical]

structure K19AdapterDrivenContractClosure where
  contractCount : adapterDrivenContracts.length = 7
  equalsCanonical : adapterDrivenContracts = canonicalStatementContracts
  canonicalProjection : statementContractProblemProjection = canonicalProblemIds

def k19_adapter_driven_contract_closure : K19AdapterDrivenContractClosure :=
{
  contractCount := adapter_driven_contracts_length,
  equalsCanonical := adapter_driven_contracts_eq_canonical,
  canonicalProjection := statement_contract_problem_projection_eq_canonical
}

end CROOT
