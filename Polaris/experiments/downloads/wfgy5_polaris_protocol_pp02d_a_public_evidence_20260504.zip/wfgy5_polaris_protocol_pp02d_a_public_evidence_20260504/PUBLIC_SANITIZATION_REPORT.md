# Public Sanitization Report

Removed from the public package:
- Colab / notebook files
- `notebooks/`
- internal prompt handoff files
- private hash manifest
- compiler-spec artifact
- original nested handoff ZIP
- stale original manifests that referenced removed files

Retained:
- result summaries
- raw API records
- parsed outputs
- score summaries
- sandbox A/B and poison-rejection result tables
- regenerated public hash manifest
