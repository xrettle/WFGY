import CROOT.Core.ProblemSpec
import CROOT.Kernels.K2_NoConclusionImport

namespace CROOT

structure StatementAdapterInput where
  problem : ProblemId
  sourceText : String
  claimClass : ImportClass
  deriving DecidableEq, Repr

structure StatementAdapterOutput where
  problem : ProblemId
  normalizedText : String
  importDecision : ImportDecision
  deriving DecidableEq, Repr

def normalizeStatementText (s : String) : String :=
  s

def adaptStatement (input : StatementAdapterInput) : StatementAdapterOutput :=
  {
    problem := input.problem
    normalizedText := normalizeStatementText input.sourceText
    importDecision := decideImport input.claimClass
  }

theorem adapter_keeps_problem_id (input : StatementAdapterInput) :
    (adaptStatement input).problem = input.problem := by
  rfl

theorem adapter_decision_follows_k2 (input : StatementAdapterInput) :
    (adaptStatement input).importDecision = decideImport input.claimClass := by
  rfl

theorem adapter_blocks_direct_target (p : ProblemId) (text : String) :
    (adaptStatement { problem := p, sourceText := text, claimClass := ImportClass.directTarget }).importDecision =
      ImportDecision.blocked := by
  rfl

theorem adapter_blocks_solved_route (p : ProblemId) (text : String) :
    (adaptStatement { problem := p, sourceText := text, claimClass := ImportClass.solvedRoute }).importDecision =
      ImportDecision.blocked := by
  rfl

theorem adapter_escalates_unknown_equivalent (p : ProblemId) (text : String) :
    (adaptStatement { problem := p, sourceText := text, claimClass := ImportClass.unknownEquivalent }).importDecision =
      ImportDecision.escalated := by
  rfl

end CROOT
