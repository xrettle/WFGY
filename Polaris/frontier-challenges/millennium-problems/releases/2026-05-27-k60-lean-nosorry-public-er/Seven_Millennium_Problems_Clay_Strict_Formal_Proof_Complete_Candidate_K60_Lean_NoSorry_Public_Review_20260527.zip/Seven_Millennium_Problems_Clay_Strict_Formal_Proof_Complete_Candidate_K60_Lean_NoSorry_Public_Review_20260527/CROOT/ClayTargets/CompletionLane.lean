import CROOT.ClayTargets.ObligationChain

namespace CROOT

inductive CompletionMilestone where
  | statementFormalized
  | domainCoreFormalized
  | reductionChainClosed
  | contradictionRouteClosed
  | finalTheoremTermClosed
  deriving DecidableEq, Repr

structure ProblemCompletionLane where
  problem : ProblemId
  milestones : List CompletionMilestone
  deriving DecidableEq, Repr

def canonicalMilestones : List CompletionMilestone :=
  [CompletionMilestone.statementFormalized,
   CompletionMilestone.domainCoreFormalized,
   CompletionMilestone.reductionChainClosed,
   CompletionMilestone.contradictionRouteClosed,
   CompletionMilestone.finalTheoremTermClosed]

def completionLaneOf (p : ProblemId) : ProblemCompletionLane :=
  {
    problem := p,
    milestones := canonicalMilestones
  }

def allCompletionLanes : List ProblemCompletionLane :=
  [completionLaneOf ProblemId.pnp,
   completionLaneOf ProblemId.rh,
   completionLaneOf ProblemId.bsd,
   completionLaneOf ProblemId.hodge,
   completionLaneOf ProblemId.navierStokes,
   completionLaneOf ProblemId.yangMills,
   completionLaneOf ProblemId.poincare]

def laneShapeValid (lane : ProblemCompletionLane) : Prop :=
  lane.milestones.length = 5 /\
  lane.milestones.Nodup

theorem canonical_milestones_length : canonicalMilestones.length = 5 := by
  rfl

theorem canonical_milestones_nodup : canonicalMilestones.Nodup := by
  decide

theorem completion_lane_shape_valid (p : ProblemId) :
    laneShapeValid (completionLaneOf p) := by
  constructor
  · exact canonical_milestones_length
  · exact canonical_milestones_nodup

theorem all_completion_lanes_length : allCompletionLanes.length = 7 := by
  rfl

theorem completion_lane_preserves_problem (p : ProblemId) :
    (completionLaneOf p).problem = p := by
  rfl

end CROOT
