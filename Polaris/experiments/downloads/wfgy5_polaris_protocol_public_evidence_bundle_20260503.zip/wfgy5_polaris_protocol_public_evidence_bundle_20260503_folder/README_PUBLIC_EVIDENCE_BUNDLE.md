# WFGY 5.0 Polaris Protocol
## Public Evidence Bundle

Repository:
https://github.com/onestardao/WFGY

License:
MIT License, unless a specific file states otherwise.

This release contains standardized public evidence packages for four experiment branches:

1. PP01
2. PP02A
3. PP02B
4. PP02C

These packages preserve raw outputs, parsed outputs, case verdicts, metrics, audits, token accounting, result summaries, reference artifacts, and regenerated SHA256 manifests.

Execution notebooks and unreleased core mathematical source files are intentionally excluded from this public evidence bundle.

The goal of this release is to provide transparent experimental evidence while keeping unreleased implementation internals out of the public evidence package.

Colab based reproduction materials will be linked through the official WFGY GitHub repository when released.
