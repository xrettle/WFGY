import CROOT.Kernels.K51_UnifiedFastpathCertificate

namespace CROOT

structure K52UnifiedInvariantPack where
  trackInvariant :
    forall lane,
      laneTrackProjection lane = canonicalTrackProjection /\
      (laneTrackProjection lane).Nodup /\
      (laneTrackProjection lane).head? = some Track.PNP /\
      (laneTrackProjection lane).getLast? = some Track.PC
  problemInvariant :
    forall lane,
      laneProblemProjection lane = canonicalProblemIds /\
      (laneProblemProjection lane).Nodup /\
      (laneProblemProjection lane).head? = some ProblemId.pnp /\
      (laneProblemProjection lane).getLast? = some ProblemId.poincare
  statementInvariant :
    forall lane, laneStatementProjection lane = statementTagProjectionFromContracts
  domainInvariant :
    forall lane, laneDomainProjection lane = canonicalDomainTagProjection
  returnLockInvariant :
    forall lane, laneReturnLockProjection lane = List.replicate 7 ReturnLockStatus.locked
  decisionInvariant :
    forall lane, laneDecisionProjection lane = List.replicate 7 ImportDecision.allowed
  boundaryInvariant :
    forall lane, laneBoundaryProjection lane = List.replicate 7 officialBoundaryTag
  debtInvariant :
    generatedObligationDebtProjection = List.replicate 7 TheoremDebtStatus.openDebt

def k52_unified_invariant_pack : K52UnifiedInvariantPack :=
{
  trackInvariant := by
    intro lane
    refine And.intro (k51_unified_fastpath_certificate.trackEqCanonical lane) ?_
    refine And.intro (k51_unified_fastpath_certificate.trackNodup lane) ?_
    refine And.intro (k51_unified_fastpath_certificate.trackHeadLock lane) ?_
    exact k51_unified_fastpath_certificate.trackTailLock lane,
  problemInvariant := by
    intro lane
    refine And.intro (k51_unified_fastpath_certificate.problemEqCanonical lane) ?_
    refine And.intro (k51_unified_fastpath_certificate.problemNodup lane) ?_
    refine And.intro (k51_unified_fastpath_certificate.problemHeadLock lane) ?_
    exact k51_unified_fastpath_certificate.problemTailLock lane,
  statementInvariant := k51_unified_fastpath_certificate.statementEqContracts,
  domainInvariant := k51_unified_fastpath_certificate.domainEqCanonical,
  returnLockInvariant := k51_unified_fastpath_certificate.returnLockAllLocked,
  decisionInvariant := k51_unified_fastpath_certificate.decisionAllAllowed,
  boundaryInvariant := k51_unified_fastpath_certificate.boundaryAllOfficial,
  debtInvariant := k51_unified_fastpath_certificate.debtAllOpen
}

theorem k52_track_eq_canonical :
    forall lane, laneTrackProjection lane = canonicalTrackProjection := by
  intro lane
  exact (k52_unified_invariant_pack.trackInvariant lane).left

theorem k52_track_nodup :
    forall lane, (laneTrackProjection lane).Nodup := by
  intro lane
  exact (k52_unified_invariant_pack.trackInvariant lane).right.left

theorem k52_track_head_lock :
    forall lane, (laneTrackProjection lane).head? = some Track.PNP := by
  intro lane
  exact (k52_unified_invariant_pack.trackInvariant lane).right.right.left

theorem k52_track_tail_lock :
    forall lane, (laneTrackProjection lane).getLast? = some Track.PC := by
  intro lane
  exact (k52_unified_invariant_pack.trackInvariant lane).right.right.right

theorem k52_problem_eq_canonical :
    forall lane, laneProblemProjection lane = canonicalProblemIds := by
  intro lane
  exact (k52_unified_invariant_pack.problemInvariant lane).left

theorem k52_problem_nodup :
    forall lane, (laneProblemProjection lane).Nodup := by
  intro lane
  exact (k52_unified_invariant_pack.problemInvariant lane).right.left

theorem k52_problem_head_lock :
    forall lane, (laneProblemProjection lane).head? = some ProblemId.pnp := by
  intro lane
  exact (k52_unified_invariant_pack.problemInvariant lane).right.right.left

theorem k52_problem_tail_lock :
    forall lane, (laneProblemProjection lane).getLast? = some ProblemId.poincare := by
  intro lane
  exact (k52_unified_invariant_pack.problemInvariant lane).right.right.right

end CROOT
