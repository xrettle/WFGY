README FOR REVIEWERS

This pack is intended for topic-specific review.
Proof Obligations and Open Debt are topic-specific.

Review priorities:
1. Check whether the answer candidate preserves the original problem.
2. Check whether candidate lemmas are topic-specific.
3. Check whether Proof Obligations are not generic.
4. Check whether Open Debt is not generic.
5. Check whether the route returns to the native problem.
6. Check whether the output avoids claiming final proof closure.

Valid attack:
- topic mismatch
- generic lemma
- generic proof obligation
- hidden hard part
- false closure
- missing counterexample
- weak return to original problem
