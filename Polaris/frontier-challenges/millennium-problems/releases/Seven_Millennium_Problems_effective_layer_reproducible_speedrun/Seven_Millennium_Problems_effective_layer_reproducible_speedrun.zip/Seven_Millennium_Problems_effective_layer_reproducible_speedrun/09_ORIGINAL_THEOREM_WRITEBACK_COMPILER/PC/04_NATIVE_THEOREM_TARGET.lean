-- C03 native theorem target stub for Poincare Conjecture
-- This file records the native statement target exposed by the writeback layer.

namespace WFGY.C03.PC

-- theorem target:
-- Every closed simply connected three-dimensional manifold is homeomorphic to the three-sphere.

axiom native_theorem_target_PC : Prop

end WFGY.C03.PC
