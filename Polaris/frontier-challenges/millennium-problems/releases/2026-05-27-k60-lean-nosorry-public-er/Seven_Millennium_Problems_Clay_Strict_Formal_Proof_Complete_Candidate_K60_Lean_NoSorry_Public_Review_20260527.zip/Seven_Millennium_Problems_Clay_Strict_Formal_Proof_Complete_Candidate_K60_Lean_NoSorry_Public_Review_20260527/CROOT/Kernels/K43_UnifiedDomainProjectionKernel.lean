import CROOT.Kernels.K32_DomainProjectionClosure

namespace CROOT

inductive DomainProjectionLane where
  | canonical
  | sourceField
  | manual
  | generated
deriving DecidableEq, Repr

def laneDomainProjection : DomainProjectionLane → List String
  | .canonical => canonicalDomainTagProjection
  | .sourceField => sourceFieldDomainTagProjection
  | .manual => manualDomainTagProjection
  | .generated => generatedDomainTagProjection

theorem lane_domain_projection_eq_canonical :
    ∀ lane, laneDomainProjection lane = canonicalDomainTagProjection
  | .canonical => rfl
  | .sourceField => source_field_domain_projection_eq_canonical
  | .manual => manual_domain_projection_eq_canonical
  | .generated => generated_domain_projection_eq_canonical

theorem lane_domain_projection_length :
    ∀ lane, (laneDomainProjection lane).length = 7 := by
  intro lane
  calc
    (laneDomainProjection lane).length = canonicalDomainTagProjection.length := by
      simpa [lane_domain_projection_eq_canonical lane]
    _ = 7 := by
      simpa [canonicalDomainTagProjection] using canonical_problem_ids_length

structure K43UnifiedDomainProjectionKernel where
  laneEqCanonical : ∀ lane, laneDomainProjection lane = canonicalDomainTagProjection
  laneCountSeven : ∀ lane, (laneDomainProjection lane).length = 7

def k43_unified_domain_projection_kernel : K43UnifiedDomainProjectionKernel :=
{
  laneEqCanonical := lane_domain_projection_eq_canonical,
  laneCountSeven := lane_domain_projection_length
}

end CROOT
