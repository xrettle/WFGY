import CROOT.ClayTargets.Common

namespace CROOT

def navierStokesDomainCore : DomainCoreSignature :=
  {
    objectTag := "incompressible-flow-solution-space"
    operationTag := "energy-estimate-evolution-map"
    invariantTag := "global-regularity-obligation"
  }

def navierStokesTargetContract : FormalizationTargetContract :=
  contractFromSpec ProblemId.navierStokes "official-clay-statement-boundary"

theorem navier_stokes_target_problem :
    navierStokesTargetContract.problem = ProblemId.navierStokes := by
  rfl

theorem navier_stokes_target_shape_valid :
    targetContractShapeValid navierStokesTargetContract := by
  constructor <;> decide

end CROOT
