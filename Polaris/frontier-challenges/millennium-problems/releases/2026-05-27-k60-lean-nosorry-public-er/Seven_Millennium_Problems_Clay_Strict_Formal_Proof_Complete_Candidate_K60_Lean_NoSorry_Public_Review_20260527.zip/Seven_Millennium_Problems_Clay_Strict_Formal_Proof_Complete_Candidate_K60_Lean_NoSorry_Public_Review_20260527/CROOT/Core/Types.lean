namespace CROOT

/-
P79 Decidable Kernel V5.
Target: K1-K5 framework + seven-track instantiation only.
No native Clay theorem proof is claimed here.
-/

inductive Track where
  | PNP
  | RH
  | BSD
  | HODGE
  | NS
  | YM
  | PC
  deriving DecidableEq, Repr

inductive Boundary where
  | official
  | outside
  deriving DecidableEq, Repr

inductive Marker where
  | neutral
  | conclusionLike
  | successLike
  deriving DecidableEq, Repr

inductive ObstructionClass where
  | content
  | vocabulary
  | conclusionImport
  | successMarker
  | targetMismatch
  | crossTrackLeak
  | unknown
  deriving DecidableEq, Repr

structure ResidualId where
  val : Nat
  deriving DecidableEq, Repr

structure Atom where
  track : Track
  boundary : Boundary
  marker : Marker
  residualId : ResidualId
  obstructionClass : ObstructionClass
  deriving DecidableEq, Repr

inductive Route where
  | carrier (a : Atom)
  | blocker (a : Atom) (reason : ObstructionClass)
  deriving DecidableEq, Repr

inductive ImportClass where
  | directTarget
  | solvedRoute
  | knownEquivalent
  | unknownEquivalent
  | safeBackground
  deriving DecidableEq, Repr

inductive ImportDecision where
  | blocked
  | escalated
  | allowed
  deriving DecidableEq, Repr

inductive ResidualState where
  | admissible
  | failure
  | laneExit
  | unknownEscalate
  deriving DecidableEq, Repr

inductive Branch where
  | returnBranch
  | exitBranch
  deriving DecidableEq, Repr

def allTracks : List Track :=
  [Track.PNP, Track.RH, Track.BSD, Track.HODGE, Track.NS, Track.YM, Track.PC]

end CROOT
