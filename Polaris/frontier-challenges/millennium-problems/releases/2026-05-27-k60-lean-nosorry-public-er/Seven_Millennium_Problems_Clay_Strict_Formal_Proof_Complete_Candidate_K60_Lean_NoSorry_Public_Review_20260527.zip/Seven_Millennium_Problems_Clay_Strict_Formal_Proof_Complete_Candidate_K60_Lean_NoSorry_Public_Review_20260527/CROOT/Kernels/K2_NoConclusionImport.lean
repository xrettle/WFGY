import CROOT.Core.Types

namespace CROOT

def decideImport (c : ImportClass) : ImportDecision :=
  match c with
  | ImportClass.directTarget => ImportDecision.blocked
  | ImportClass.solvedRoute => ImportDecision.blocked
  | ImportClass.knownEquivalent => ImportDecision.blocked
  | ImportClass.unknownEquivalent => ImportDecision.escalated
  | ImportClass.safeBackground => ImportDecision.allowed

theorem K2_direct_blocked :
    decideImport ImportClass.directTarget = ImportDecision.blocked := by
  rfl

theorem K2_solved_blocked :
    decideImport ImportClass.solvedRoute = ImportDecision.blocked := by
  rfl

theorem K2_equivalent_blocked :
    decideImport ImportClass.knownEquivalent = ImportDecision.blocked := by
  rfl

theorem K2_unknown_escalates :
    decideImport ImportClass.unknownEquivalent = ImportDecision.escalated := by
  rfl

theorem K2_safe_background_allowed :
    decideImport ImportClass.safeBackground = ImportDecision.allowed := by
  rfl

end CROOT
