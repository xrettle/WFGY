README FOR REVIEWERS

This is a known-answer calibration pack.

Review:
- direct answer accuracy
- scope condition accuracy
- truth anchor quality
- misconception quality
- alignment verdict justification

Valid objections:
wrong answer, incomplete answer, missing scope condition, vague truth anchor, inaccurate misconception.
