import CROOT.Kernels.K7_StatementAdapterSoundness

namespace CROOT

inductive AssumptionKind where
  | directTargetConclusion
  | importedSolvedRoute
  | knownEquivalentConclusion
  | unknownEquivalentConclusion
  | safeBackgroundFact
  deriving DecidableEq, Repr

def firewallDecision (k : AssumptionKind) : ImportDecision :=
  match k with
  | AssumptionKind.directTargetConclusion => ImportDecision.blocked
  | AssumptionKind.importedSolvedRoute => ImportDecision.blocked
  | AssumptionKind.knownEquivalentConclusion => ImportDecision.blocked
  | AssumptionKind.unknownEquivalentConclusion => ImportDecision.escalated
  | AssumptionKind.safeBackgroundFact => ImportDecision.allowed

theorem k8_direct_target_blocked :
    firewallDecision AssumptionKind.directTargetConclusion = ImportDecision.blocked := by
  rfl

theorem k8_solved_route_blocked :
    firewallDecision AssumptionKind.importedSolvedRoute = ImportDecision.blocked := by
  rfl

theorem k8_known_equivalent_blocked :
    firewallDecision AssumptionKind.knownEquivalentConclusion = ImportDecision.blocked := by
  rfl

theorem k8_unknown_equivalent_escalated :
    firewallDecision AssumptionKind.unknownEquivalentConclusion = ImportDecision.escalated := by
  rfl

theorem k8_safe_background_allowed :
    firewallDecision AssumptionKind.safeBackgroundFact = ImportDecision.allowed := by
  rfl

structure K8AssumptionFirewall where
  directBlocked : firewallDecision AssumptionKind.directTargetConclusion = ImportDecision.blocked
  solvedBlocked : firewallDecision AssumptionKind.importedSolvedRoute = ImportDecision.blocked
  knownBlocked : firewallDecision AssumptionKind.knownEquivalentConclusion = ImportDecision.blocked
  unknownEscalated : firewallDecision AssumptionKind.unknownEquivalentConclusion = ImportDecision.escalated
  safeAllowed : firewallDecision AssumptionKind.safeBackgroundFact = ImportDecision.allowed

theorem k8_assumption_firewall : K8AssumptionFirewall :=
{
  directBlocked := k8_direct_target_blocked,
  solvedBlocked := k8_solved_route_blocked,
  knownBlocked := k8_known_equivalent_blocked,
  unknownEscalated := k8_unknown_equivalent_escalated,
  safeAllowed := k8_safe_background_allowed
}

end CROOT
