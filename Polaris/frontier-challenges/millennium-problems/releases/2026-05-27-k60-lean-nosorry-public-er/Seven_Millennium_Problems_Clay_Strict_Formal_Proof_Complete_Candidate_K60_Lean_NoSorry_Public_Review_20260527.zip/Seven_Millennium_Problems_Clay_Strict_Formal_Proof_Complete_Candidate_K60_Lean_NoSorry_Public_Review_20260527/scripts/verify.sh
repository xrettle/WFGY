#!/usr/bin/env bash
set -euo pipefail

mkdir -p build_logs

echo "[0/4] versions"
(lean --version || true) | tee build_logs/lean_version.txt
(lake --version || true) | tee build_logs/lake_version.txt

echo "[1/4] lake build"
set +e
lake build 2>&1 | tee build_logs/lake_build.log
BUILD_RC=${PIPESTATUS[0]}
set -e
echo "${BUILD_RC}" > build_logs/lake_build.returncode

if [ "${BUILD_RC}" -ne 0 ]; then
  echo "LAKE BUILD FAILED"
  exit "${BUILD_RC}"
fi

echo "[2/4] no-sorry scan"
python3 scripts/no_sorry_scan.py | tee build_logs/no_sorry_scan.log

echo "[3/4] sha256 manifest"
find . -type f \( -name '*.lean' -o -name 'lakefile.lean' -o -name 'lean-toolchain' -o -path './scripts/*' \) -print0 | sort -z | xargs -0 sha256sum > VERIFY_SHA256SUMS.txt

echo "[4/4] grep forbidden tokens"
if grep -RInE '\b(sorry|admit|axiom|constant)\b' CROOT lakefile.lean; then
  echo "FORBIDDEN TOKEN FOUND"
  exit 1
fi

echo "VERIFY PASS"
