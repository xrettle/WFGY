#!/usr/bin/env python3
from pathlib import Path
import fnmatch
import json

ROOT = Path(__file__).resolve().parents[1]

KEEP_EXACT = {
    "CROOT.lean",
    "lakefile.lean",
    "lake-manifest.json",
    "lean-toolchain",
    "BUILD_REPORT.json",
    "TRIAGE_REPORT.json",
    "README.md",
    "STATUS.md",
    "HOW_TO_VERIFY.md",
    "RUN_THIS_FIRST.md",
    "HONEST_ENDORSEMENT_STATEMENT.md",
    "PUBLIC_ER_CLAY_STRICT_FORMAL_PROOF_COMPLETE_DOSSIER_20260527.md",
    "CLAIM_CEILING_MACHINE_CHECK_STEP1.txt",
    "PUBLIC_TERMINOLOGY_MAP.txt",
    "NEXT_STAGE_NATIVE_CLOSURE_ROADMAP.txt",
    "PUBLIC_RELEASE_CERTIFICATE_K60.txt",
}

KEEP_GLOBS = [
    "CROOT/**",
    ".github/workflows/**",
    "scripts/no_sorry_scan.py",
    "scripts/collect_build_report.py",
    "scripts/triage_build_log.py",
    "scripts/assert_pass.py",
    "scripts/check_verification_whitelist.py",
    "scripts/verify.sh",
    "scripts/verify_buildfirst.sh",
    "scripts/verify_staged.sh",
    "build_logs/**",
]

OPTIONAL_GLOBS = [
    "Dockerfile",
    "docker-compose.yml",
    "Makefile",
    "evidence/**",
]

def matches_any(path: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(path, pattern) for pattern in patterns)

all_files: list[str] = []
for p in ROOT.rglob("*"):
    if p.is_file() and ".lake" not in p.parts:
        all_files.append(str(p.relative_to(ROOT)).replace("\\", "/"))

keep_required: list[str] = []
keep_optional: list[str] = []
cleanup_candidates: list[str] = []

for rel in sorted(all_files):
    if rel in KEEP_EXACT or matches_any(rel, KEEP_GLOBS):
        keep_required.append(rel)
    elif matches_any(rel, OPTIONAL_GLOBS):
        keep_optional.append(rel)
    else:
        cleanup_candidates.append(rel)

report = {
    "required_keep_count": len(keep_required),
    "optional_keep_count": len(keep_optional),
    "cleanup_candidate_count": len(cleanup_candidates),
    "required_keep": keep_required,
    "optional_keep": keep_optional,
    "cleanup_candidates": cleanup_candidates,
}

out = ROOT / "build_logs" / "verification_whitelist_report.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
