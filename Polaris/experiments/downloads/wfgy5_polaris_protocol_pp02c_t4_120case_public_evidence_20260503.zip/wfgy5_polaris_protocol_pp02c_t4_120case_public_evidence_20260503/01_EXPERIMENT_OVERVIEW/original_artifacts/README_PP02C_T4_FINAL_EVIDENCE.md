# WFGY 5.0 Polaris Protocol

Repository: https://github.com/onestardao/WFGY

Branch: PP02C

# PP02C T4 Final Evidence Package

This package preserves the final PP02C 120-case T4 coding repair experiment notebook, the final actual result package, the two sandbox packages, and the focused stress-test artifacts that were used to stabilize the final run.

## Final result

The final public evidence branch is:

`internal_execution_notebook_excluded_from_public_release`

The final actual result package is:

`PP02C_FINAL_CANONICAL_FROM_V3_results_20260503_075841.zip`

The final run is based on the v3 Synthetic Distractor Lock internal execution source excluded from public release:

`internal_execution_notebook_excluded_from_public_release`

## Final metrics

| Metric | Value |
|---|---:|
| dry_run_with_mock_outputs | False |
| case_count | 120 |
| arms_per_case | 6 |
| expected_outputs | 720 |
| actual_outputs | 720 |
| parse_pass_rate | 1.0 |
| hard_veto_count | 0 |
| warning_count | 0 |
| repo_hallucination_count | 0 |
| metadata_as_evidence_count | 0 |
| synthetic_distractor_as_source_count | 0 |
| source_priority_ignored_count | 0 |
| exact_patch_without_source_count | 0 |
| contract_missing_field_count | 0 |
| contract_enum_invalid_count | 0 |
| contract_value_mismatch_count | 0 |
| model_contract_used_for_hard_gate | True |
| evaluator_generated_pass_contract | False |
| claim_ceiling_pass_rate | 1.0 |
| OverpassScore | 120 |
| T4 confidence | 1.0 |
| final_branch_verdict | FULL_SANDBOX_STRONG_PASS |
| normalization_applied | 0 / 720 |

## Family-level result

| family_id | case_verdict | total |
| --- | --- | --- |
| BF01 | 90 | 90 |
| BF02 | 90 | 90 |
| BF03 | 90 | 90 |
| BF04 | 90 | 90 |
| BF05 | 90 | 90 |
| BF06 | 90 | 90 |
| BF07 | 90 | 90 |
| BF08 | 90 | 90 |

## Stage-level result

| stage_id | case_verdict | total |
| --- | --- | --- |
| S0 | 72 | 72 |
| S1 | 216 | 216 |
| S2 | 216 | 216 |
| S3 | 216 | 216 |

## Arm-level result

| arm | case_verdict | total |
| --- | --- | --- |
| A | 120 | 120 |
| B | 120 | 120 |
| C | 120 | 120 |
| D | 120 | 120 |
| E | 120 | 120 |
| F | 120 | 120 |

## Important interpretation note

The final verdict string inside the generated JSON still says `FULL_SANDBOX_STRONG_PASS`, but the final manifest clearly records:

`dry_run_with_mock_outputs = false`

Therefore this evidence package treats the final result as an actual run pass, not as a sandbox pass. In later public reporting, this should be described as `ACTUAL_STRONG_PASS` to avoid confusion.

## What went wrong during the experiment

The final result was not reached in one step. Several failure modes appeared and were intentionally fixed before the final package was accepted.

### 1. Synthetic distractor wording poisoned the cases

Earlier 120-case versions included distractor wording that was too close to real repository language, such as commit-like, documentation-like, config-like, and wrong-source bait. The model sometimes converted synthetic distractors into claims about repository contents. This triggered repo-hypothesis hard veto failures.

The fix was to build a focused Synthetic Distractor and Repo Hypothesis matrix. It forced all distractors to remain synthetic labels and verified that non-controlling evidence was not treated as repository evidence.

### 2. Hard veto was too close to a raw word scanner

A major failure was that generic English phrases such as `boundary issues` were interpreted as repository issue references. That showed the old hard veto layer was too coarse. It was strict in the wrong way: it punished normal language instead of only punishing true evidence overreach.

The fix was to design and test a Global Hard Veto Contract Matrix. This matrix separated safe generic wording from true repo-world references and tested false positives and false negatives across all eight BF families.

### 3. Contract schema drift appeared in an early contract attempt

One contract attempt failed because the model wrote invalid enum values such as `1.0`, blank fields, `UNKNOWN`, `LOW`, or `NEUTRAL`. That proved that a plain instruction to output a JSON contract was not enough.

The fix was the strict-schema contract version and then the final canonical-contract version. The final accepted version requires the model to output a contract, lets the verifier perform only conservative canonical normalization, and fails missing fields, invalid enums, schema drift, or contract-value mismatch.

### 4. A locked evaluator-generated contract was rejected

A later version removed enum drift by generating the hard-gate contract inside the evaluator. This was rejected because it changed the experiment meaning. It could be attacked as evaluator self-pass.

The final accepted version does not use evaluator-generated pass contracts. It records:

`model_contract_used_for_hard_gate = true`

`evaluator_generated_pass_contract = false`

This preserved credibility while still preventing the old natural-language hard-veto failures.

### 5. File-size and mother-file integrity mattered

A 167KB to 170KB rebuilt final file was rejected because it was much smaller than the recent 214KB v3 internal execution source excluded from public release and could have lost important case detail. The final public evidence branch was rebuilt from:

`internal_execution_notebook_excluded_from_public_release`

The resulting final notebook is about 216KB, which is close to the 214KB internal execution source excluded from public release. This avoided the smaller skeleton-file problem.

## Final lesson learned

The main lesson is that the experiment should not be stabilized by repeatedly patching single families. The stable path was:

1. Identify the family-level failure.
2. Pull the failure into a focused matrix.
3. Prove the matrix passes.
4. Promote the fix to the full 120-case benchmark.
5. Reject any fix that changes the experiment meaning.
6. Preserve the correct internal execution source excluded from public release instead of replacing it with a smaller skeleton.

## Files included in this evidence package

- `internal_execution_notebook_excluded_from_public_release`
- `PP02C_FINAL_CANONICAL_FROM_V3_sandbox_run1.zip`
- `PP02C_FINAL_CANONICAL_FROM_V3_sandbox_run2.zip`
- `PP02C_FINAL_CANONICAL_FROM_V3_results_20260503_075841.zip`
- `internal_execution_notebook_excluded_from_public_release`
- `internal_execution_notebook_excluded_from_public_release`
- `PP02C_GlobalHardVeto_ContractMatrix_v3_results_20260503_070628.zip`
- `internal_execution_notebook_excluded_from_public_release`
- `PP02C_GlobalHardVeto_MiniPreflight_results_20260503_062307.zip`
- `internal_execution_notebook_excluded_from_public_release`
- `PP02C_SyntheticDistractor_Matrix_results_20260503_041247.zip`

## Missing expected files

No expected files were missing.
