# PP02D_C Public QA Noninferiority Evidence Package

Public branch: `PP02D_C`

Source artifact note: the uploaded source ZIP used the older internal label `DD02C` and reused several `full_30` filenames. This cleaned public package normalizes the external branch name to `PP02D_C` and renames the public data files to `full100` where appropriate.

## What this package contains

This is a public evidence package for a 100-case HotpotQA validation pilot with a model-ladder comparison.

Dataset:
- `hotpotqa/hotpot_qa`
- config: `distractor`
- split: `validation`
- public sample count: 100

Models:
- `gpt-4.1-mini` as the primary small model
- `gpt-4.1` as the larger comparison model

Arms:
- `A_BASELINE_RAW_CONTEXT`
- `B_POLARIS_COMPACT_CONTEXT`

Public record counts:
- case manifest rows: 100
- leakage audit rows: 200
- raw model output rows: 400
- parser record rows: 400
- scorer trace rows: 400
- model-arm summary rows: 4

## Public files

| File | Role |
| --- | --- |
| `case_manifest.jsonl` | Public case manifest with hashed gold labels |
| `raw_outputs_full100.jsonl` | Raw model outputs for the 100-case × 2-arm × 2-model run |
| `parser_records_full100.jsonl` | Parsed output records and parse status |
| `scorer_trace_full100.csv` | Per-output scoring and token/cost records |
| `summary_table_full100_model_ladder.csv` | Model-arm aggregate summary |
| `leakage_audit.jsonl` | Leakage and self-grading audit records |
| `verdict_full100.json` | Normalized public verdict metadata |
| `hash_manifest_public.csv` | SHA256 manifest for this cleaned package |
| `PUBLIC_NORMALIZATION_NOTES.md` | Notes about source-label normalization and removals |

## Public-safe exclusions

The following source artifacts are intentionally excluded from this public evidence package:

- prompt bodies
- compact-selection trace internals
- notebooks
- Colab files
- smoke placeholder files with no API outputs
- stale source hash manifests that referenced removed files
- method-internal or core-math material

This package publishes evidence records, not the unreleased core mathematics or full execution notebook.

## Key public summary

| Metric | Value |
| --- | ---: |
| Public QA cases | 100 |
| Model-arm output records | 400 |
| Parse pass records | 400/400 |
| Metadata leakage fail count | 0 |
| Self-grading fail count | 0 |
| API key pattern in prompts count | 0 |
| Baseline answer F1 mean, both models | 0.7884761905 |
| Compact-context answer F1 mean, both models | 0.7941428571 |
| Baseline support-title F1 mean, both models | 0.8966666667 |
| Compact-context support-title F1 mean, both models | 0.8453333333 |
| Token reduction, compact vs baseline | 0.3704355582 |
| Estimated cost reduction, compact vs baseline | 0.3124261543 |
| Baseline wrong-source total, both models | 2 |
| Compact-context wrong-source total, both models | 5 |
| Baseline hallucinated-detail total, both models | 0 |
| Compact-context hallucinated-detail total, both models | 1 |
| Final result | `GREEN` |
| Claim ceiling | `100_CASE_PUBLIC_HOTPOTQA_MODEL_LADDER_EVIDENCE_ONLY` |

## Claim boundary

This package supports only a scoped public QA pilot claim:

- It shows a 100-case public HotpotQA validation evidence record under the specified model, arm, parser, scorer, and cost-accounting setup.
- It does not claim universal QA superiority.
- It does not claim that compact context is always better.
- It does not include unreleased core mathematics.
- It does not include Colab or full execution reproduction material.

Internal `DD02C_*` case IDs may still appear inside raw outputs and parser records because the raw model JSON bodies are left intact to preserve `raw_output_sha256` integrity.
