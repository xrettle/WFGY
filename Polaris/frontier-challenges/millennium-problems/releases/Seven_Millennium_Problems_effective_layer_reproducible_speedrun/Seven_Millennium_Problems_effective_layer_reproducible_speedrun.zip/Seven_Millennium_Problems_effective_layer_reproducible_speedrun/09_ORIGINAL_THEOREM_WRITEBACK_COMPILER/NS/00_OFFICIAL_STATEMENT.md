# Navier-Stokes Existence and Smoothness · Official Statement Lock

## Problem ID

```text
NS
```

## Domain

```text
PDE / fluid mechanics
```

## Official theorem target

```text
For smooth divergence-free initial data in three dimensions, decide global existence and smoothness of incompressible Navier-Stokes solutions, or exhibit breakdown.
```

## Native target phrase

```text
global regularity or finite-time singularity statement
```

## C03 lock

This statement is the source target used by the writeback compiler. The writeback validator checks that every C03 answer returns to this statement rather than remaining only inside the effective-layer ledger.
