import CROOT.Integration.KernelBundle

namespace CROOT

structure SevenTrackInstantiationVerified where
  bundle : KernelBundleVerified
  exactSeven : allTracks.length = 7
  nodupSeven : allTracks.Nodup
  pnp : Track.PNP ∈ allTracks
  rh : Track.RH ∈ allTracks
  bsd : Track.BSD ∈ allTracks
  hodge : Track.HODGE ∈ allTracks
  ns : Track.NS ∈ allTracks
  ym : Track.YM ∈ allTracks
  pc : Track.PC ∈ allTracks

theorem seven_track_instantiation_verified : SevenTrackInstantiationVerified :=
{
  bundle := kernel_bundle_verified,
  exactSeven := K5_allTracks_length,
  nodupSeven := K5_allTracks_nodup,
  pnp := K5_PNP_mem,
  rh := K5_RH_mem,
  bsd := K5_BSD_mem,
  hodge := K5_HODGE_mem,
  ns := K5_NS_mem,
  ym := K5_YM_mem,
  pc := K5_PC_mem
}

theorem seven_track_exact_length :
    seven_track_instantiation_verified.exactSeven = K5_allTracks_length := by
  rfl

end CROOT
