import CROOT.Kernels.K9_DependencyTraceability
import CROOT.ClayTargets.Registry

namespace CROOT

structure ProofCapsuleContract where
  problem : ProblemId
  hasStatementLayer : Bool
  hasDomainLayer : Bool
  hasDependencyTraceLayer : Bool
  hasReplayLayer : Bool
  deriving DecidableEq, Repr

def capsuleReady (c : ProofCapsuleContract) : Prop :=
  c.hasStatementLayer = true
    /\ c.hasDomainLayer = true
    /\ c.hasDependencyTraceLayer = true
    /\ c.hasReplayLayer = true

def canonicalCapsule (p : ProblemId) : ProofCapsuleContract :=
  {
    problem := p,
    hasStatementLayer := true,
    hasDomainLayer := true,
    hasDependencyTraceLayer := true,
    hasReplayLayer := true
  }

def canonicalCapsules : List ProofCapsuleContract :=
  [canonicalCapsule ProblemId.pnp,
   canonicalCapsule ProblemId.rh,
   canonicalCapsule ProblemId.bsd,
   canonicalCapsule ProblemId.hodge,
   canonicalCapsule ProblemId.navierStokes,
   canonicalCapsule ProblemId.yangMills,
   canonicalCapsule ProblemId.poincare]

theorem canonical_capsules_length : canonicalCapsules.length = 7 := by
  rfl

theorem canonical_capsule_ready (p : ProblemId) :
    capsuleReady (canonicalCapsule p) := by
  cases p <;> simp [capsuleReady, canonicalCapsule]

structure K10ProofCapsuleContract where
  capsuleCount : canonicalCapsules.length = 7
  targetRegistryCount : clayTargetRegistry.length = 7
  pnpReady : capsuleReady (canonicalCapsule ProblemId.pnp)
  rhReady : capsuleReady (canonicalCapsule ProblemId.rh)
  bsdReady : capsuleReady (canonicalCapsule ProblemId.bsd)
  hodgeReady : capsuleReady (canonicalCapsule ProblemId.hodge)
  nsReady : capsuleReady (canonicalCapsule ProblemId.navierStokes)
  ymReady : capsuleReady (canonicalCapsule ProblemId.yangMills)
  pcReady : capsuleReady (canonicalCapsule ProblemId.poincare)

theorem k10_proof_capsule_contract : K10ProofCapsuleContract :=
{
  capsuleCount := canonical_capsules_length,
  targetRegistryCount := clay_target_registry_length,
  pnpReady := canonical_capsule_ready ProblemId.pnp,
  rhReady := canonical_capsule_ready ProblemId.rh,
  bsdReady := canonical_capsule_ready ProblemId.bsd,
  hodgeReady := canonical_capsule_ready ProblemId.hodge,
  nsReady := canonical_capsule_ready ProblemId.navierStokes,
  ymReady := canonical_capsule_ready ProblemId.yangMills,
  pcReady := canonical_capsule_ready ProblemId.poincare
}

end CROOT
